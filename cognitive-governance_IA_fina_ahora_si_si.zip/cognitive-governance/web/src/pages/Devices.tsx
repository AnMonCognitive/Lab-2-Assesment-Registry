import { useMemo, useState } from "react";
import { api, fmtDate } from "../api";
import { ErrorBox, Loading, PageHeader, useLoad } from "../components/ui";

const AGENT: Record<string, [string, string]> = {
  activo: ["Activo", "bg-data-tint text-data"],
  sin_reportar: ["Sin reportar", "bg-accent-tint text-accent-dark"],
  pendiente: ["Pendiente de instalar", "bg-white border border-cream-line text-ink-2"],
};

export default function Devices() {
  const { data, error } = useLoad<any[]>(() => api("/api/devices"), []);
  const [q, setQ] = useState("");
  const [onlyRisk, setOnlyRisk] = useState(false);
  const rows = useMemo(() => (data ?? []).filter((d) =>
    (!onlyRisk || d.unapproved > 0) && `${d.hostname} ${d.person} ${d.area} ${d.tools.join(" ")}`.toLowerCase().includes(q.toLowerCase())),
  [data, q, onlyRisk]);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const pending = data.filter((d) => d.agent_status === "pendiente").length;

  return (
    <>
      <PageHeader eyebrow="Registry · Inventario" title="Dispositivos" />
      {pending > 0 && (
        <div className="card p-4 mb-4 text-sm border-data bg-data-tint/60">
          {pending} equipos esperan el agente. Genera un token en <b>Operación → Agente de inventario</b> e instala el agente
          (<span className="font-mono">agent/windows/install.ps1</span>); los equipos y sus herramientas aparecerán aquí.
        </div>
      )}
      <div className="flex items-center gap-3 mb-4">
        <input className="input max-w-sm" placeholder="Buscar equipo, persona, área o herramienta" value={q} onChange={(e) => setQ(e.target.value)} />
        <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={onlyRisk} onChange={(e) => setOnlyRisk(e.target.checked)} /> Solo con IA no aprobada</label>
        <span className="ml-auto text-sm text-ink-3">{rows.length} de {data.length} equipos</span>
      </div>
      <div className="card overflow-x-auto">
        <table className="tbl">
          <thead><tr><th>Equipo</th><th>Persona</th><th>Área</th><th>Sistema</th><th>Agente</th><th>Última conexión</th><th>Herramientas de IA</th></tr></thead>
          <tbody>
            {rows.map((d) => {
              const [label, cls] = AGENT[d.agent_status] ?? [d.agent_status, ""];
              return (
                <tr key={d.id}>
                  <td className="font-mono text-xs whitespace-nowrap">{d.hostname}</td>
                  <td>{d.person}</td>
                  <td className="text-ink-2">{d.area}</td>
                  <td className="text-ink-2">{d.os}</td>
                  <td><span className={`rounded-full px-2 py-0.5 text-xs ${cls}`}>{label}</span></td>
                  <td className="text-xs text-ink-3">{fmtDate(d.last_seen)}</td>
                  <td className="text-xs">
                    {d.tools.length ? d.tools.join(", ") : <span className="text-ink-3">—</span>}
                    {d.unapproved > 0 && <span className="block text-accent-dark font-semibold">{d.unapproved} no aprobada(s)</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
