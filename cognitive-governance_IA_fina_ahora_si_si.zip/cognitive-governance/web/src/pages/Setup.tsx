import { FormEvent, useState } from "react";
import { api, fmtDate } from "../api";
import { useSession } from "../App";
import { Card, useLoad } from "../components/ui";

const ROLES: [string, string, boolean][] = [
  ["admin_cognitive", "Admin Cognitive", true], ["consultor", "Consultor Cognitive", true],
  ["analista_catalogo", "Analista de catálogo", true], ["cliente_admin_ti", "Admin TI del cliente", false],
  ["cliente_seguridad", "Seguridad del cliente", false], ["cliente_direccion", "Dirección del cliente", false],
];

/** Tokens de inscripción del agente para la organización seleccionada. */
export function AgentCard() {
  const { org } = useSession();
  const { data, reload } = useLoad<any>(() => api("/api/agent/tokens"), []);
  const [label, setLabel] = useState("");
  const [token, setToken] = useState("");
  const [err, setErr] = useState("");

  const create = (e: FormEvent) => {
    e.preventDefault();
    api("/api/agent/tokens", { method: "POST", json: { label } })
      .then((r) => { setToken(r.token); setLabel(""); reload(); }).catch((x) => setErr(x.message));
  };
  const revoke = (id: number) => window.confirm("Los equipos con este token dejarán de reportar. ¿Revocar?") &&
    api(`/api/agent/tokens/${id}`, { method: "DELETE" }).then(reload);
  const cmd = `powershell -ExecutionPolicy Bypass -File install.ps1 -ServerUrl ${window.location.origin} -Token ${token || "<token>"} -Area "<área>"`;

  return (
    <Card title={`Agente de inventario · ${org?.name ?? ""}`} className="mb-5">
      <p className="text-sm text-ink-2 mb-3">
        Instala el agente (carpeta <span className="font-mono">agent/windows</span>) en cada equipo, con el consentimiento
        de la persona. Reporta cada hora el software instalado; los equipos aparecen en <b>Dispositivos</b>.
        {data && <> Equipos reportando a esta organización: <b>{data.devices}</b>.</>}
      </p>
      <form onSubmit={create} className="flex gap-2 mb-3">
        <input className="input max-w-xs" placeholder="Nombre del token (ej. Equipos de TI)" value={label}
          onChange={(e) => setLabel(e.target.value)} required />
        <button className="btn-primary">Generar token</button>
      </form>
      {err && <p className="text-sm text-accent-dark mb-3">{err}</p>}
      {token && (
        <div className="card p-3 mb-3 bg-data-tint/60 border-data text-sm">
          <p className="font-semibold">Copia el token ahora: no se volverá a mostrar.</p>
          <p className="font-mono text-xs break-all my-2 select-all">{token}</p>
          <p className="text-xs text-ink-3 mb-1">Comando de instalación (en el equipo, desde la carpeta del agente):</p>
          <p className="font-mono text-xs break-all select-all">{cmd}</p>
        </div>
      )}
      <table className="tbl">
        <thead><tr><th>Token</th><th>Creado por</th><th>Creado</th><th>Último reporte</th><th>Estado</th><th></th></tr></thead>
        <tbody>
          {(data?.tokens ?? []).map((t: any) => (
            <tr key={t.id}>
              <td>{t.label}</td><td className="text-xs">{t.created_by}</td><td className="text-xs">{fmtDate(t.created_at)}</td>
              <td className="text-xs">{fmtDate(t.last_used_at)}</td><td className="text-xs">{t.revoked ? "Revocado" : "Activo"}</td>
              <td>{!t.revoked && <button className="text-xs text-accent-dark hover:underline" onClick={() => revoke(t.id)}>Revocar</button>}</td>
            </tr>
          ))}
          {data?.tokens.length === 0 && <tr><td colSpan={6} className="text-ink-3 text-center py-4">Aún no hay tokens para esta organización.</td></tr>}
        </tbody>
      </table>
    </Card>
  );
}

/** Alta de clientes y de usuarios de la consola (solo Admin Cognitive). */
export function AccessCard() {
  const { orgs } = useSession();
  const users = useLoad<any[]>(() => api("/api/admin/users"), []);
  const [orgName, setOrgName] = useState("");
  const [u, setU] = useState({ email: "", name: "", role: "consultor", org_id: "" });
  const [msg, setMsg] = useState("");
  const isCognitiveRole = ROLES.find((r) => r[0] === u.role)?.[2] ?? true;

  const createOrg = (e: FormEvent) => {
    e.preventDefault();
    api("/api/admin/orgs", { method: "POST", json: { name: orgName } })
      .then(() => window.location.reload()).catch((x) => setMsg(x.message));
  };
  const createUser = (e: FormEvent) => {
    e.preventDefault();
    api("/api/admin/users", { method: "POST", json: { ...u, org_id: isCognitiveRole ? null : Number(u.org_id) } })
      .then(() => { setMsg(`Usuario ${u.email} creado`); setU({ ...u, email: "", name: "" }); users.reload(); })
      .catch((x) => setMsg(x.message));
  };

  return (
    <Card title="Organizaciones y usuarios" className="mb-5">
      <div className="grid lg:grid-cols-2 gap-6">
        <form onSubmit={createOrg} className="space-y-2">
          <p className="eyebrow">Nuevo cliente</p>
          <input className="input" placeholder="Nombre de la organización" value={orgName} onChange={(e) => setOrgName(e.target.value)} required />
          <button className="btn-primary">Crear organización</button>
          <p className="text-xs text-ink-3">Se crea vacía, con su assessment por responder. Después genera su token del agente.</p>
        </form>
        <form onSubmit={createUser} className="space-y-2">
          <p className="eyebrow">Nuevo usuario de la consola</p>
          <input className="input" type="email" placeholder="Correo" value={u.email} onChange={(e) => setU({ ...u, email: e.target.value })} required />
          <input className="input" placeholder="Nombre" value={u.name} onChange={(e) => setU({ ...u, name: e.target.value })} required />
          <div className="flex gap-2">
            <select className="input" value={u.role} onChange={(e) => setU({ ...u, role: e.target.value })}>
              {ROLES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
            {!isCognitiveRole && (
              <select className="input" value={u.org_id} onChange={(e) => setU({ ...u, org_id: e.target.value })} required>
                <option value="">Organización…</option>
                {orgs.filter((o) => o.kind === "cliente").map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            )}
          </div>
          <button className="btn-primary">Crear usuario</button>
        </form>
      </div>
      {msg && <p className="text-sm mt-3">{msg}</p>}
      <table className="tbl mt-4">
        <thead><tr><th>Correo</th><th>Nombre</th><th>Rol</th><th>Organización</th></tr></thead>
        <tbody>
          {(users.data ?? []).map((x) => (
            <tr key={x.id}><td className="text-xs">{x.email}</td><td>{x.name}</td><td>{x.role_label}</td><td>{x.org}</td></tr>
          ))}
        </tbody>
      </table>
    </Card>
  );
}
