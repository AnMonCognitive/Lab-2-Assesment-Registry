import { api, fmtDate } from "../api";
import { useSession } from "../App";
import { ErrorBox, Loading, PageHeader, useLoad } from "../components/ui";

const TYPE: Record<string, string> = {
  ia_no_aprobada: "IA no aprobada", extension_nueva: "Extensión nueva", sistema_sin_dueno: "Sistema sin dueño", oauth_amplio: "Permisos OAuth amplios", ia_riesgo_alto: "IA de riesgo alto",
};
const SEV: Record<string, string> = { alta: "bg-accent text-navy", media: "bg-[#FBF1D0] text-[#7A5C00]", baja: "bg-data-tint text-data" };
const CAN_ACT = ["admin_cognitive", "consultor", "cliente_seguridad"];

export default function Alerts() {
  const { user } = useSession();
  const { data, error, reload } = useLoad<any[]>(() => api("/api/alerts"), []);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const act = (id: number, status: string) => api(`/api/alerts/${id}`, { method: "PATCH", json: { status } }).then(reload);
  const canAct = CAN_ACT.includes(user.role);

  return (
    <>
      <PageHeader eyebrow="Gobierno" title="Alertas" />
      <p className="text-sm text-ink-3 -mt-3 mb-5">La plataforma avisa y recomienda; el bloqueo lo hace TI con las herramientas que la empresa ya tiene.</p>
      <div className="space-y-3">
        {data.map((a) => (
          <div key={a.id} className={`card p-4 flex gap-4 items-start ${a.status !== "abierta" ? "opacity-60" : ""}`}>
            <span className={`rounded-md px-2 py-1 text-xs font-semibold uppercase shrink-0 ${SEV[a.severity]}`}>{a.severity}</span>
            <div className="flex-1">
              <p className="font-semibold">{a.title}</p>
              <p className="text-sm text-ink-2 mt-0.5">{a.detail}</p>
              <p className="text-xs text-ink-3 mt-1">{TYPE[a.type] ?? a.type} · {fmtDate(a.created_at)} · {a.status}</p>
            </div>
            {canAct && a.status === "abierta" && (
              <div className="flex gap-2 shrink-0">
                <button className="btn-primary" onClick={() => act(a.id, "atendida")}>Atendida</button>
                <button className="btn-ghost" onClick={() => act(a.id, "descartada")}>Descartar</button>
              </div>
            )}
            {canAct && a.status !== "abierta" && <button className="btn-ghost shrink-0" onClick={() => act(a.id, "abierta")}>Reabrir</button>}
          </div>
        ))}
      </div>
    </>
  );
}
