import { FormEvent, useEffect, useState } from "react";
import { api, User } from "../api";

type Mode = { auth_mode: string; data_mode: string };

export default function Login({ onLogin }: { onLogin: (u: User) => void }) {
  const [mode, setMode] = useState<Mode | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api<Mode>("/api/auth/mode").then(setMode).catch(() => setError("No se pudo conectar con la API"));
  }, []);

  const real = mode?.data_mode === "real";

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="bg-navy text-cream p-12 flex flex-col justify-between relative overflow-hidden">
        <div>
          <p className="font-mono text-xs tracking-[0.14em] text-accent">COGNITIVE AI LAB · LAB 2</p>
          <h1 className="font-display text-5xl font-bold mt-6 leading-tight">Readiness Assessment<br />+ Registry</h1>
          <p className="text-data-soft text-lg mt-4 max-w-md">Qué IA se usa en la empresa, quién la usa, con qué riesgo, y qué tan lista está la organización.</p>
        </div>
        <div className="absolute right-16 bottom-16 w-16 h-16 rounded-full bg-accent" />
        <p className="text-xs text-data-soft">{real ? "Versión preliminar · datos reales" : "Versión preliminar · todos los datos son ficticios"}</p>
      </div>
      <div className="p-12 flex flex-col justify-center max-w-xl w-full">
        <p className="eyebrow">Iniciar sesión</p>
        {mode?.auth_mode === "password"
          ? <PasswordLogin onLogin={onLogin} error={error} setError={setError} />
          : mode?.auth_mode === "dev"
            ? <DevLogin onLogin={onLogin} real={real} error={error} setError={setError} />
            : mode?.auth_mode === "entra"
              ? <EntraLogin />
              : <p className="text-sm text-ink-3 mt-4">{error || "Cargando…"}</p>}
      </div>
    </div>
  );
}

// -------------------------------------------------- correo + contraseña (producción autoalojada)
function PasswordLogin({ onLogin, error, setError }:
  { onLogin: (u: User) => void; error: string; setError: (s: string) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setError(""); setBusy(true);
    api<User>("/api/auth/login", { method: "POST", json: { email: email.trim(), password } })
      .then(onLogin)
      .catch((err) => setError(err.message))
      .finally(() => setBusy(false));
  };

  return (
    <form onSubmit={submit}>
      <h2 className="font-display text-2xl font-bold mt-1">Entra a la consola</h2>
      <p className="text-sm text-ink-3 mt-2 mb-6">Usa tu correo corporativo y tu contraseña. Si es tu primer ingreso, usa la contraseña temporal que te dio el administrador y cámbiala después.</p>
      <label className="block text-sm font-medium mb-1">Correo</label>
      <input type="email" autoFocus required value={email} onChange={(e) => setEmail(e.target.value)}
        className="input w-full mb-4" placeholder="tu.correo@empresa.mx" autoComplete="username" />
      <label className="block text-sm font-medium mb-1">Contraseña</label>
      <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
        className="input w-full mb-6" placeholder="••••••••" autoComplete="current-password" />
      <button type="submit" disabled={busy} className="btn-primary w-full justify-center">
        {busy ? "Entrando…" : "Entrar"}
      </button>
      {error && <p className="text-accent-dark text-sm mt-4">{error}</p>}
    </form>
  );
}

// -------------------------------------------------- selector de roles (solo desarrollo/demo)
function DevLogin({ onLogin, real, error, setError }:
  { onLogin: (u: User) => void; real: boolean; error: string; setError: (s: string) => void }) {
  const [users, setUsers] = useState<User[]>([]);
  useEffect(() => {
    api<User[]>("/api/auth/dev-users").then(setUsers).catch(() => setError("No se pudo conectar con la API"));
  }, []);

  const login = (email: string) =>
    api<User>("/api/auth/login", { method: "POST", json: { email } }).then(onLogin).catch((e) => setError(e.message));

  return (
    <>
      <h2 className="font-display text-2xl font-bold mt-1">{real ? "Elige tu usuario" : "Elige un usuario de prueba"}</h2>
      <p className="text-sm text-ink-3 mt-2 mb-6">
        Modo desarrollo: cada usuario representa un rol, para mostrar qué ve cada quién. En producción el acceso es con correo y contraseña (o Microsoft Entra ID).
      </p>
      <div className="space-y-2">
        {users.map((u) => (
          <button key={u.id} onClick={() => login(u.email)}
            className="w-full text-left card px-4 py-3 hover:border-navy transition flex items-center justify-between">
            <span>
              <span className="font-semibold block">{u.role_label}</span>
              <span className="text-xs text-ink-3">{u.email} · {u.org_name}</span>
            </span>
            <span className="text-accent-dark text-sm">Entrar →</span>
          </button>
        ))}
      </div>
      {error && <p className="text-accent-dark text-sm mt-4">{error}</p>}
    </>
  );
}

// -------------------------------------------------- Entra ID (pendiente)
function EntraLogin() {
  return (
    <>
      <h2 className="font-display text-2xl font-bold mt-1">Entra con Microsoft</h2>
      <p className="text-sm text-ink-3 mt-2 mb-6">El acceso de esta organización es con su cuenta de Microsoft (Entra ID + MFA).</p>
      <button disabled className="btn-ghost justify-center opacity-60 cursor-not-allowed w-full">Entrar con Microsoft (pendiente)</button>
    </>
  );
}
