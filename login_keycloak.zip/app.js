const express = require('express');
const session = require('express-session');
const { Issuer, generators } = require('openid-client');

(async () => {
  const issuer = await Issuer.discover('http://localhost:8080/realms/demo');
  const client = new issuer.Client({
    client_id: 'ia-monitor',
    client_secret: 'INSERTA EL SECRET AQUI',
    redirect_uris: ['http://localhost:3000/callback'],
    response_types: ['code'],
  });

  const app = express();
  app.use(session({
    secret: 'cambiar-en-produccion',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax' },
  }));

  app.get('/', (req, res) => {
    if (!req.session.user) return res.send('<a href="/login">Entrar con SSO</a>');
    res.send('<a href="/me">Ver mis claims</a> | <a href="/admin">Zona admin</a> | <a href="/logout">Salir</a>');
  });

  app.get('/login', (req, res) => {
    const verifier = generators.codeVerifier();
    req.session.verifier = verifier;
    req.session.state = generators.state();
    res.redirect(client.authorizationUrl({
      scope: 'openid profile email',
      code_challenge: generators.codeChallenge(verifier),
      code_challenge_method: 'S256',
      state: req.session.state,
    }));
  });

  app.get('/callback', async (req, res) => {
    const tokenSet = await client.callback(
      'http://localhost:3000/callback',
      client.callbackParams(req),
      { code_verifier: req.session.verifier, state: req.session.state }
    );
    req.session.user = tokenSet.claims();
    // Para ver roles, ver el access_token en jwt.io (realm_access.roles)
    req.session.access = tokenSet.access_token;
    res.redirect('/');
  });

  app.get('/me', (req, res) => {
    if (!req.session.user) return res.redirect('/login');
    res.json(req.session.user);
  });

  app.get('/admin', (req, res) => {
    if (!req.session.user) return res.redirect('/login');
    const payload = JSON.parse(Buffer.from(req.session.access.split('.')[1], 'base64url'));
    const roles = payload.realm_access?.roles || [];
    if (!roles.includes('admin-plataforma')) return res.status(403).send('Acceso denegado: falta el rol admin-plataforma');
    res.send('Bienvenido, administrador');
  });

  app.get('/logout', (req, res) => req.session.destroy(() => res.redirect('/')));

  app.listen(3000, () => console.log('http://localhost:3000'));
})();