# Login con Keycloak

## ¿Por qué?

Keycloack es una de las opciones que tenemos para el login del proyecto de gobernanza IA, la necesidad de este proyecto es clara, se requiere autenticación real, también tenemos a microsoft 365 que se puede conectar con la app directamente, ambos protegen los datos y guardan las contraseñas de forma segura, la ventaja está en que keycloak es self hosted por lo que no depende de terceros. Aún así vale la pena revisar y considerar todas las opciones a nuestro alcance.

## Demostración

### Comando para correr keycloak con docker

En el cmd o powershell ingresa:

```cmd
docker run -p 8080:8080 -e KC_BOOTSTRAP_ADMIN_USERNAME=admin -e KC_BOOTSTRAP_ADMIN_PASSWORD=admin quay.io/keycloak/keycloak:latest start-dev
```

Se descargará lo necesario para su funcionamiento, es requisito tener docker ya instalado. 

### Configuración

1. Entrar a http://localhost:8080 con admin/admin.
2. Configurar el realm, usuario y cliente
- Crear realm: demo.
- Crear usuario: nombre, con un correo y en credentials añade contraseña (desactiva “Temporary”).
- Crear roles de realm: administrador (prueba) y admin-plataforma, y asignen uno a ana. Servirá para demostrar RBAC.
- Crear cliente (Clients → Create):
- Client ID: ia-monitor
- Client authentication: On
- Standard flow: activado
- Valid redirect URIs: http://localhost:3000/callback
- Después, en la pestaña Credentials, copien el Client secret.
3. Activar MFA con passkeys / FIDO2 y TOTP
- Authentication → Flows: dupliquen el flujo browser y llámenlo browser-mfa. En el subflujo Browser - Conditional 2FA, pongan OTP Form y WebAuthn Authenticator como Alternative, de modo que el usuario elija su llave o el código TOTP.
- En Flow bindings o  Action dentro del flow asignen browser-mfa como flujo de navegador.
Para forzar el registro: en el usuario creado, en Required user actions agreguen Webauthn Register y Configure OTP.

En el primer login, este usuario registrará su passkey (Windows Hello, Touch ID, llave USB o su teléfono) y, si quieren, el TOTP en Google Authenticator o similar. En los siguientes tendrá que usarlos.

## La aplicación

Con node.js instalado, escribir en la terminal los comandos:
```vs
mkdir demo-sso     (crea la carpeta demo-sso)
cd demo-sso 
npm init -y     (en caso de error, correr: "Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned" y despues intenta de nuevo )
npm install express express-session openid-client@5
```

El archivo `app.js` debe estar dentro de la carpeta `demo-sso`, antes, se tiene que pegar el client secret dentro del campo indicado en el codigo.

Finalmente ejecuta en la terminal el comando `node app.js  `.

## Prueba

- Abrir http://localhost:3000 y pulsar Entrar con SSO: se redirige a Keycloak, la app nunca ve la contraseña.
- Iniciar sesión con usuario y contraseña.
- Mostrar la pantalla de MFA: registrar la passkey (y el TOTP como respaldo).
- Volver a la app y abrir /me: se ven los claims del usuario.
- Abrir /admin con el ususario siendo administrador (el rol de prueba): 403. Cambiarle el rol a admin-plataforma en Keycloak, cerrar sesión, volver a entrar: acceso permitido. Esto demuestra el RBAC.
- Cerrar sesión, volver a entrar con el TOTP en lugar de la passkey, para mostrar el respaldo.
- En Keycloak, Sessions muestra la sesión activa y permite revocarla. En Events (actívenlo en Realm settings → Events) se ve la bitácora de inicios de sesión.