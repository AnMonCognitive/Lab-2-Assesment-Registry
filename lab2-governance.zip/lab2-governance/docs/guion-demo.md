# Guion de la demo · 15 minutos

Antes de empezar: **Operación → Reiniciar datos de demo** (deja todo como la primera vez).

| Minuto | Usuario | Qué se muestra | Mensaje |
| --- | --- | --- | --- |
| 0–2 | — | Pantalla de login | Cada rol ve algo distinto; en producción se entra con Microsoft. |
| 2–5 | seguridad@empresademo.mx | Resumen | En minutos sabemos qué IA se usa: 26 herramientas, 42 personas con IA no aprobada. |
| 5–7 | seguridad@ | Herramientas → DeepSeek → "No aprobar" | La empresa decide; nosotros recomendamos con la ficha de Labs. |
| 7–8 | seguridad@ | Alertas | Sistema sin dueño y grabadores de reuniones: lo que hay que atender primero. |
| 8–9 | seguridad@ | Sistemas de IA propios | El Registry ve lo que ningún sensor ve: agentes, automatizaciones, costos. |
| 9–10 | direccion@empresademo.mx | Resumen y Áreas | Dirección ve el panorama sin nombres de personas. |
| 10–13 | consultor@cognitive.demo | Assessment → Generar reporte con IA → Imprimir | El diagnóstico de 9 dimensiones y el reporte, redactado por Claude y revisado por el consultor. |
| 13–14 | consultor@ | Catálogo → Clasificar con IA | Lo desconocido lo clasifica Claude y lo confirma un analista: el catálogo crece con cada cliente. |
| 14–15 | admin@cognitive.demo | Operación | Medimos nuestra propia IA: tokens, costo, latencia. Esto será el Agent Monitor. |

Plan B: video grabado de este mismo guion.
