"""Datos de demo con semilla fija: la demo se ve igual cada vez.

Organizaciones:
  - Empresa Demo (120 equipos, assessment completo)            -> la historia principal
  - Distribuidora Norte (45 equipos, assessment sin responder) -> muestra el multi-cliente
  - Cognitive (interno) (5 equipos esperando el agente real)   -> se llena con Fleet

TODOS los nombres de personas y empresas son ficticios.

Uso:  python -m seed.generate_demo            (desde la raíz; borra y vuelve a generar)
"""
import random
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "api"))

from sqlalchemy import select  # noqa: E402

from app.db import Base, SessionLocal, engine  # noqa: E402
from app.models import (AISystem, AITool, Alert, Area, Assessment, AssessmentAnswer, ConsoleUser, Detection,  # noqa: E402
                        Device, Organization, OrgToolStatus, Person, UnknownSignature, WeeklySnapshot)
from app.services.catalog import sync_catalog  # noqa: E402

SEED = 42
FIRST = ["Ana", "Luis", "María", "José", "Fernanda", "Carlos", "Daniela", "Jorge", "Sofía", "Miguel", "Valeria",
         "Ricardo", "Paola", "Andrés", "Mariana", "Diego", "Gabriela", "Eduardo", "Lucía", "Roberto", "Camila",
         "Alejandro", "Regina", "Héctor", "Natalia", "Óscar", "Ximena", "Raúl", "Elena", "Iván"]
LAST = ["García", "Hernández", "Martínez", "López", "González", "Rodríguez", "Pérez", "Sánchez", "Ramírez",
        "Cruz", "Flores", "Gómez", "Morales", "Vázquez", "Jiménez", "Reyes", "Díaz", "Torres", "Ruiz", "Mendoza",
        "Aguilar", "Ortiz", "Castillo", "Romero", "Navarro"]

# Probabilidad base de que una persona use cada herramienta (solo herramientas que el agente puede ver).
BASE_USE = {"chatgpt": .50, "claude": .16, "gemini": .14, "microsoft-copilot": .16, "perplexity": .08,
            "deepseek": .03, "grammarly": .13, "deepl": .12, "quillbot": .04, "notion-ai": .08, "otter": .04,
            "fireflies": .03, "read-ai": .02, "monica": .02, "merlin": .015, "tldv": .02}
AREA_EXTRA = {
    "TI": {"github-copilot": .60, "cursor": .25, "claude-code": .22, "continue": .08, "cline": .07, "ollama": .18,
           "lm-studio": .08, "openai-sdk": .30, "anthropic-sdk": .22, "langchain": .12, "n8n": .20, "windsurf": .06},
    "Ventas": {"otter": .14, "fireflies": .10, "grammarly": .20, "monica": .06, "tldv": .06},
    "Finanzas": {"deepseek": .14, "chatgpt": .60},
    "Dirección": {"read-ai": .20, "otter": .10, "perplexity": .25},
    "Recursos Humanos": {"grammarly": .30, "deepl": .25, "quillbot": .10},
    "Operaciones": {"microsoft-copilot": .25},
    "Compras": {"chatgpt": .55},
    "Logística": {"microsoft-copilot": .20},
}
STATUS_EMPRESA = {
    "aprobada": ["claude", "m365-copilot", "github-copilot", "deepl", "claude-code", "anthropic-sdk"],
    "no_aprobada": ["deepseek", "otter", "fireflies", "monica", "merlin", "ollama", "lm-studio", "read-ai",
                    "quillbot", "microsoft-copilot", "cline", "tldv"],
}  # el resto queda "en_revision"
OWNERS = {"claude": "TI · Mesa de servicio", "m365-copilot": "TI · Mesa de servicio", "github-copilot": "TI · Desarrollo"}


def _person_name(rng: random.Random, used: set) -> str:
    while True:
        n = f"{rng.choice(FIRST)} {rng.choice(LAST)} {rng.choice(LAST)}"
        if n not in used:
            used.add(n)
            return n


def _email(name: str, domain: str) -> str:
    import unicodedata
    base = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower().split()
    return f"{base[0]}.{base[1]}@{domain}"


def _signature(tool: AITool, os_name: str) -> str:
    sig = tool.signatures or {}
    for key, prefix in (("vscode", "vscode"), ("apps", "app"), ("extensions", "extension"),
                        ("processes", "process"), ("packages", "package")):
        if sig.get(key):
            return f"{prefix}:{sig[key][0]}"
    return f"m365:licencia {tool.name}"


def _org(db, rng, name, domain, areas_spec, now, statuses, extra_noise=1.0):
    org = Organization(name=name, kind="cliente", is_demo=True)
    db.add(org)
    db.flush()
    tools = {t.slug: t for t in db.scalars(select(AITool))}
    used = set()
    people, devices = [], []
    for area_name, count in areas_spec:
        area = Area(org_id=org.id, name=area_name)
        db.add(area)
        db.flush()
        code = "".join(w[0] for w in area_name.split()).upper()[:3]
        for i in range(count):
            pname = _person_name(rng, used)
            p = Person(org_id=org.id, area_id=area.id, name=pname, email=_email(pname, domain))
            db.add(p)
            db.flush()
            mac = rng.random() < 0.3
            active = rng.random() < 0.94
            d = Device(org_id=org.id, person_id=p.id,
                       hostname=f"{domain.split('.')[0][:2].upper()}-{code}-{len(devices) + 1:03d}",
                       os=rng.choice(["macOS 15", "macOS 14"]) if mac else "Windows 11",
                       agent_status="activo" if active else "sin_reportar",
                       last_seen=now - (timedelta(minutes=rng.randint(5, 110)) if active
                                        else timedelta(days=rng.randint(3, 12))),
                       source="simulado")
            db.add(d)
            db.flush()
            people.append((p, area_name))
            devices.append(d)
            probs = dict(BASE_USE)
            probs.update(AREA_EXTRA.get(area_name, {}))
            if rng.random() < 0.55:  # licencias de Microsoft 365 Copilot (fuente M365, simulada)
                probs["m365-copilot"] = 0.5 if area_name in {"Dirección", "Finanzas"} else 0.2
            for slug, prob in probs.items():
                if slug in tools and rng.random() < prob * extra_noise:
                    first = now - timedelta(days=int(rng.triangular(1, 84, 70)))
                    db.add(Detection(org_id=org.id, device_id=d.id, tool_id=tools[slug].id,
                                     source="m365" if slug == "m365-copilot" else "agente",
                                     raw_signature=_signature(tools[slug], d.os), first_seen=first,
                                     last_seen=d.last_seen or now))
    db.flush()
    detected = {det.tool_id for det in db.scalars(select(Detection).where(Detection.org_id == org.id))}
    for slug, t in tools.items():
        if t.id not in detected:
            continue
        status = next((s for s, slugs in statuses.items() if slug in slugs), "en_revision")
        db.add(OrgToolStatus(org_id=org.id, tool_id=t.id, status=status, owner=OWNERS.get(slug)))
    db.flush()
    return org, tools


def _snapshots(db, org_id, now, rng):
    """12 semanas de tendencia que terminan en los valores actuales."""
    from app.services import metrics
    s = metrics.summary(db, org_id)["status_counts"]
    pu = metrics.summary(db, org_id)["kpis"]["people_unapproved"]
    monday = (now - timedelta(days=now.weekday())).date()
    for i in range(12):
        f = 0.45 + 0.55 * (i / 11)
        db.add(WeeklySnapshot(org_id=org_id, week_start=monday - timedelta(weeks=11 - i),
                              approved=max(1, round(s["aprobada"] * min(1, 0.6 + 0.4 * i / 11))),
                              in_review=round(s["en_revision"] * f), not_approved=round(s["no_aprobada"] * f),
                              people_unapproved=round(pu * f) if i < 11 else pu))


QUESTIONS = {
    "Datos": ["¿Existen fuentes de datos únicas y confiables para los procesos clave?",
              "¿Los datos están clasificados por nivel de sensibilidad?",
              "¿Hay dueños de datos definidos por área?"],
    "Seguridad": ["¿Las herramientas de IA usan inicio de sesión único y MFA?",
                  "¿Se controla qué software y extensiones se pueden instalar?",
                  "¿Se evalúa la seguridad de un proveedor de IA antes de contratarlo?"],
    "Permisos": ["¿Los agentes y automatizaciones tienen permisos mínimos?",
                 "¿Se revisan periódicamente las apps de terceros con acceso OAuth?",
                 "¿Hay aprobación humana en acciones sensibles de la IA?"],
    "Privacidad": ["¿El aviso de privacidad contempla el uso de IA?",
                   "¿Está prohibido ingresar datos personales sensibles en IA no aprobada?",
                   "¿Hay un proceso para solicitudes de derechos ARCO que involucren IA?"],
    "Procesos": ["¿Los procesos candidatos a automatizar están documentados?",
                 "¿Se mide tiempo, volumen y errores de esos procesos?",
                 "¿Hay un responsable de mejora de procesos?"],
    "Madurez": ["¿Existe una política de uso aceptable de IA?",
                "¿El personal recibe capacitación en IA?",
                "¿Existe un comité o responsable de IA?"],
    "Casos de uso": ["¿Hay un inventario de casos de uso de IA priorizados?",
                     "¿Cada caso de uso tiene un patrocinador de negocio?",
                     "¿Se evalúa la viabilidad técnica antes de iniciar?"],
    "Riesgo": ["¿Se clasifica el riesgo de cada sistema de IA?",
               "¿Hay un plan de respuesta ante fallas de la IA?",
               "¿Se revisa el cumplimiento regulatorio de los usos de IA?"],
    "ROI": ["¿Se mide la línea base antes de implementar IA?",
            "¿Se da seguimiento al costo de operación de la IA?",
            "¿Se reporta a Dirección el valor generado por la IA?"],
}
EMPRESA_ANSWERS = {
    "Datos": [(3, "El ERP es la fuente principal, pero ventas y finanzas mantienen Excel paralelos."),
              (2, "Solo nómina está clasificada como confidencial."), (2, "Dueños informales; no documentados.")],
    "Seguridad": [(3, "MFA en Microsoft 365; herramientas de IA externas sin SSO."),
                  (2, "Los usuarios pueden instalar extensiones de navegador libremente."),
                  (1, "No hay evaluación de proveedores de IA.")],
    "Permisos": [(2, "La automatización de reportes usa una cuenta con acceso total al ERP."),
                 (1, "Nunca se han revisado las apps OAuth conectadas al correo."),
                 (3, "El cotizador requiere aprobación antes de enviar.")],
    "Privacidad": [(2, "Aviso de privacidad de 2023, sin mención de IA."),
                   (1, "No existe la prohibición por escrito."), (1, "Sin proceso definido.")],
    "Procesos": [(3, "Procesos de ventas y compras documentados en SharePoint."),
                 (2, "Se mide volumen, no tiempos ni errores."), (3, "Gerencia de Operaciones lidera mejora continua.")],
    "Madurez": [(1, "No hay política de uso de IA."), (1, "Sin capacitación formal."),
                (2, "TI atiende temas de IA sin mandato formal.")],
    "Casos de uso": [(2, "Lista informal de ideas en Dirección."), (3, "Los casos actuales tienen patrocinador."),
                     (2, "Se valida solo con pruebas rápidas.")],
    "Riesgo": [(1, "No se clasifica el riesgo de los sistemas de IA."), (1, "Sin plan de respuesta."),
               (1, "No se ha revisado.")],
    "ROI": [(1, "No se midió la línea base antes del cotizador."), (2, "Se conoce el costo de licencias, no de uso."),
            (1, "No se reporta.")],
}


def _assessment(db, org_id, answers: dict | None):
    a = Assessment(org_id=org_id, status="completo" if answers else "en_curso")
    db.add(a)
    db.flush()
    for dim, qs in QUESTIONS.items():
        for i, q in enumerate(qs):
            score, ev = (answers[dim][i] if answers else (None, None))
            db.add(AssessmentAnswer(assessment_id=a.id, dimension=dim, question=q, score=score, evidence=ev))


def seed(db) -> None:
    rng = random.Random(SEED)
    now = datetime.utcnow().replace(second=0, microsecond=0)
    sync_catalog(db)

    # ---------------- Empresa Demo
    empresa, tools = _org(db, rng, "Empresa Demo", "empresademo.mx",
                          [("Dirección", 8), ("Ventas", 30), ("Finanzas", 18), ("Operaciones", 32), ("TI", 14),
                           ("Recursos Humanos", 18)], now, STATUS_EMPRESA)
    _assessment(db, empresa.id, EMPRESA_ANSWERS)
    systems = [
        dict(name="Cotizador de ventas", owner="Laura Méndez (Ventas)", area="Ventas", model="Claude Sonnet",
             provider="Anthropic vía Amazon Bedrock", platform="n8n",
             purpose="Arma cotizaciones a partir de correos de clientes.",
             data_sources="Lista de precios del ERP, correos de clientes", permissions="Lectura del ERP; envío de correo",
             monthly_cost_usd=420, risk="medio", failure_impact="Cotización con precio o descuento incorrecto",
             human_approval=True, status="produccion"),
        dict(name="Bot de preguntas de RH", owner="Patricia Ruiz (RH)", area="Recursos Humanos", model="Claude Haiku",
             provider="Anthropic vía Amazon Bedrock", platform="Microsoft Teams",
             purpose="Responde dudas sobre políticas internas.", data_sources="Políticas de RH en SharePoint",
             permissions="Lectura de una biblioteca de SharePoint", monthly_cost_usd=90, risk="bajo",
             failure_impact="Respuesta incorrecta sobre una política", human_approval=False, status="produccion"),
        dict(name="Reportes semanales del ERP", owner="Jorge Castillo (Finanzas)", area="Finanzas",
             model="Claude Sonnet", provider="Anthropic vía Amazon Bedrock", platform="Python programado",
             purpose="Resume ventas y cartera para Dirección.", data_sources="ERP completo",
             permissions="Cuenta de servicio con acceso total al ERP", monthly_cost_usd=310, risk="alto",
             failure_impact="Dirección decide con cifras equivocadas", human_approval=False, status="produccion"),
        dict(name="Clasificador de facturas", owner="Elena Torres (Finanzas)", area="Finanzas", model="GPT",
             provider="OpenAI", platform="Power Automate", purpose="Clasifica facturas de proveedores por centro de costo.",
             data_sources="Buzón de facturas", permissions="Lectura del buzón; escritura en carpeta contable",
             monthly_cost_usd=150, risk="medio", failure_impact="Gasto asignado al centro de costo equivocado",
             human_approval=True, status="produccion"),
        dict(name="Asistente de soporte TI", owner="Mesa de servicio (TI)", area="TI", model="Copilot Studio",
             provider="Microsoft", platform="Copilot Studio", purpose="Primer nivel de soporte técnico.",
             data_sources="Base de conocimiento de TI", permissions="Creación de tickets", monthly_cost_usd=200,
             risk="bajo", failure_impact="Ticket mal clasificado", human_approval=False, status="produccion"),
        dict(name="Bot en Excel de pronósticos", owner=None, area="Ventas", model=None, provider=None,
             platform="Macro de Excel con API externa", purpose="Pronóstico de ventas por cliente.",
             data_sources="Excel compartido de ventas", permissions=None, monthly_cost_usd=None, risk="alto",
             failure_impact=None, human_approval=False, status="piloto"),
        dict(name="Resumen de juntas de Dirección", owner="Asistente de Dirección", area="Dirección",
             model="Read AI", provider="Read AI", platform="Extensión de navegador",
             purpose="Minutas automáticas de juntas.", data_sources="Audio y video de reuniones",
             permissions="Acceso al calendario y a las grabaciones", monthly_cost_usd=40, risk="alto",
             failure_impact="Filtración de información estratégica", human_approval=False, status="produccion"),
        dict(name="Conciliación bancaria (piloto)", owner="Elena Torres (Finanzas)", area="Finanzas",
             model="Claude Sonnet", provider="Anthropic vía Amazon Bedrock", platform="n8n",
             purpose="Propone conciliaciones entre banco y ERP.", data_sources="Estados de cuenta, ERP",
             permissions="Lectura de estados de cuenta y del ERP", monthly_cost_usd=60, risk="alto",
             failure_impact="Conciliación errónea", human_approval=True, status="piloto"),
    ]
    for s in systems:
        db.add(AISystem(org_id=empresa.id, **s))

    def count_devices(org_id, slug, area=None):
        q = select(Detection).join(Device).join(Person).join(Area).where(
            Detection.org_id == org_id, Detection.tool_id == tools[slug].id)
        if area:
            q = q.where(Area.name == area)
        return len(list(db.scalars(q)))

    alerts = [
        ("ia_no_aprobada", "alta", f"DeepSeek en {count_devices(empresa.id, 'deepseek', 'Finanzas')} equipos de Finanzas",
         "Herramienta no aprobada en un área que maneja información financiera. Sugerencia: sustituir por el "
         "asistente aprobado y comunicar la política.", "deepseek"),
        ("sistema_sin_dueno", "alta", "Sistema de IA sin dueño: Bot en Excel de pronósticos",
         "No tiene dueño, modelo ni permisos documentados y usa un Excel compartido de ventas.", "bot-excel"),
        ("ia_no_aprobada", "media", f"Grabador de reuniones no aprobado (Otter.ai) en {count_devices(empresa.id, 'otter')} equipos",
         "Graba y transcribe reuniones con clientes. Sugerencia: usar la transcripción de Microsoft 365.", "otter"),
        ("extension_nueva", "media", "Extensión nueva en Ventas: Monica",
         "Extensión de navegador que lee el contenido de las páginas visitadas.", "monica"),
        ("oauth_amplio", "media", "App con acceso a todo el correo: Fireflies.ai",
         "Consentimiento OAuth con permiso de lectura de correo y calendario (fuente Microsoft 365, simulada).",
         "fireflies"),
    ]
    for t, sev, title, detail, ref in alerts:
        db.add(Alert(org_id=empresa.id, type=t, severity=sev, title=title, detail=detail, ref=ref,
                     created_at=now - timedelta(hours=rng.randint(2, 96))))
    for kind, name, ident, n in [("extension", "AI Summary Helper", None, 3), ("app", "Notta", None, 2),
                                 ("process", "koboldcpp", None, 1), ("vscode", "Supermaven", "supermaven.supermaven", 1)]:
        db.add(UnknownSignature(org_id=empresa.id, kind=kind, name=name, identifier=ident, devices_count=n))
    db.flush()
    _snapshots(db, empresa.id, now, rng)

    # ---------------- Distribuidora Norte
    norte, _ = _org(db, rng, "Distribuidora Norte", "distnorte.mx",
                    [("Dirección", 4), ("Compras", 12), ("Logística", 19), ("Finanzas", 10)], now,
                    {"aprobada": ["m365-copilot"], "no_aprobada": ["deepseek"]}, extra_noise=0.8)
    _assessment(db, norte.id, None)
    db.add(AISystem(org_id=norte.id, name="Rutas de reparto con IA", owner=None, area="Logística", risk="medio",
                    status="piloto", platform="Hoja de cálculo + API"))
    db.flush()
    _snapshots(db, norte.id, now, rng)

    # ---------------- Cognitive (interno): equipos reales, pendientes de conectar Fleet
    cog = Organization(name="Cognitive (interno)", kind="cognitive", is_demo=False)
    db.add(cog)
    db.flush()
    area = Area(org_id=cog.id, name="Desarrollo & Automatización")
    db.add(area)
    db.flush()
    for i in range(1, 6):
        p = Person(org_id=cog.id, area_id=area.id, name=f"[Integrante {i}]", email=f"integrante{i}@cognitive")
        db.add(p)
        db.flush()
        db.add(Device(org_id=cog.id, person_id=p.id, hostname=f"COG-DA-{i:02d}",
                      os="macOS 15" if i == 5 else "Windows 11", agent_status="pendiente", source="fleet"))

    # ---------------- Usuarios de la consola (uno por rol)
    users = [
        ("admin@cognitive.demo", "Admin Cognitive", "admin_cognitive", None),
        ("consultor@cognitive.demo", "Consultor Cognitive", "consultor", None),
        ("analista@cognitive.demo", "Analista de Cognitive Labs", "analista_catalogo", None),
        ("ti@empresademo.mx", "TI · Empresa Demo", "cliente_admin_ti", empresa.id),
        ("seguridad@empresademo.mx", "Seguridad · Empresa Demo", "cliente_seguridad", empresa.id),
        ("direccion@empresademo.mx", "Dirección · Empresa Demo", "cliente_direccion", empresa.id),
    ]
    for email, name, role, org_id in users:
        db.add(ConsoleUser(email=email, name=name, role=role, org_id=org_id))
    db.commit()


def seed_if_empty() -> bool:
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if db.scalars(select(Organization)).first():
            sync_catalog(db)  # mantiene el catálogo al día con el YAML
            return False
        seed(db)
        return True


def reset_and_seed() -> None:
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed(db)


if __name__ == "__main__":
    reset_and_seed()
    print("Datos de demo generados.")
