#!/usr/bin/env bash
# Respaldo nocturno: volcado de PostgreSQL (y de MySQL de Fleet si existe) a S3, 14 días de retención
# (la retención se configura como regla de ciclo de vida en el bucket).
# Programar en el servidor:  0 3 * * *  /opt/lab2/ops/backup.sh >> /var/log/lab2-backup.log 2>&1
set -euo pipefail
cd "$(dirname "$0")/.."
source .env
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
mkdir -p /tmp/lab2-backup

docker compose exec -T postgres pg_dump -U "$POSTGRES_USER" "$POSTGRES_DB" | gzip > "/tmp/lab2-backup/postgres-$STAMP.sql.gz"
if docker compose ps --services --status running | grep -q '^mysql$'; then
  docker compose exec -T mysql sh -c 'mysqldump -u root -p"$MYSQL_ROOT_PASSWORD" fleet' | gzip > "/tmp/lab2-backup/fleet-mysql-$STAMP.sql.gz"
fi

aws s3 cp /tmp/lab2-backup/ "s3://$BACKUP_BUCKET/lab2/$STAMP/" --recursive --only-show-errors
rm -rf /tmp/lab2-backup
echo "$(date -u) respaldo $STAMP listo"
