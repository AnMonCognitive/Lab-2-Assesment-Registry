"""Pruebas de humo de la API. Requieren PostgreSQL (DATABASE_URL). Ejecutar desde api/:  pytest -q"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
os.environ.setdefault("BEDROCK_MODE", "simulado")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from seed.generate_demo import reset_and_seed  # noqa: E402


@pytest.fixture(scope="module")
def client():
    reset_and_seed()
    with TestClient(app) as c:
        yield c


def login(c, email):
    r = c.post("/api/auth/login", json={"email": email})
    assert r.status_code == 200, r.text
    return r.json()


def test_requires_login(client):
    client.post("/api/auth/logout")
    assert client.get("/api/summary").status_code == 401


def test_summary_for_security(client):
    login(client, "seguridad@empresademo.mx")
    s = client.get("/api/summary").json()
    assert s["kpis"]["devices"] == 120
    assert s["kpis"]["tools_detected"] > 10
    assert len(s["trend"]) == 12
    assert s["kpis"]["maturity"] is not None


def test_direction_sees_no_people(client):
    login(client, "direccion@empresademo.mx")
    assert client.get("/api/devices").status_code == 403
    tools = client.get("/api/tools").json()
    detail = client.get(f"/api/tools/{tools[0]['id']}").json()
    assert all("person" not in u and "hostname" not in u for u in detail["usage"])


def test_client_cannot_switch_org(client):
    me = login(client, "seguridad@empresademo.mx")
    other = client.get("/api/summary", params={"org": 999}).json()
    # Un usuario de cliente siempre queda en su organización, ignore el parámetro.
    assert other["kpis"]["devices"] == 120
    assert me["org_name"] == "Empresa Demo"


def test_change_tool_status_and_audit(client):
    login(client, "seguridad@empresademo.mx")
    tool = client.get("/api/tools").json()[0]
    assert client.patch(f"/api/tools/{tool['id']}/status", json={"status": "aprobada"}).status_code == 200
    login(client, "admin@cognitive.demo")
    log = client.get("/api/admin/audit").json()
    assert any(r["action"] == "cambiar_estado_herramienta" for r in log)


def test_direction_cannot_change_status(client):
    login(client, "direccion@empresademo.mx")
    tool = client.get("/api/tools").json()[0]
    assert client.patch(f"/api/tools/{tool['id']}/status", json={"status": "aprobada"}).status_code == 403


def test_classify_and_confirm_unknown(client):
    login(client, "analista@cognitive.demo")
    unknowns = client.get("/api/catalog/unknowns").json()
    assert unknowns and unknowns[0]["org"] is None  # el analista no ve la organización
    uid = next(u["id"] for u in unknowns if u["name"] == "Notta")
    sug = client.post(f"/api/catalog/unknowns/{uid}/classify").json()
    assert sug["category"] == "notas de reuniones"
    assert client.post(f"/api/catalog/unknowns/{uid}/confirm", json={"action": "agregar"}).json()["ok"]
    assert any(t["name"] == "Notta" for t in client.get("/api/catalog").json())


def test_assessment_report_simulated(client):
    login(client, "consultor@cognitive.demo")
    orgs = client.get("/api/orgs").json()
    empresa = next(o["id"] for o in orgs if o["name"] == "Empresa Demo")
    a = client.get("/api/assessment", params={"org": empresa}).json()
    assert len(a["dimensions"]) == 9
    r = client.post("/api/assessment/report", params={"org": empresa})
    assert r.json()["mode"] == "simulado"
    md = client.get("/api/assessment/report", params={"org": empresa}).json()["markdown"]
    assert "Empresa Demo" in md and "Cliente (alias)" not in md
    usage = client.get("/api/admin/llm-usage").json()
    assert usage["calls"]


def test_systems_crud(client):
    login(client, "ti@empresademo.mx")
    r = client.post("/api/systems", json={"name": "Agente de prueba", "risk": "bajo"})
    assert r.status_code == 200 and "dueño" in r.json()["missing"]


def test_matcher():
    from app.models import AITool
    from app.services.catalog import match_signature
    tools = [AITool(slug="gh", name="GitHub Copilot", signatures={"vscode": ["github.copilot"]}),
             AITool(slug="ollama", name="Ollama", signatures={"apps": ["Ollama"], "processes": ["ollama"]})]
    assert match_signature(tools, "vscode", "GitHub Copilot", "github.copilot").slug == "gh"
    assert match_signature(tools, "app", "Ollama 0.5.1").slug == "ollama"
    assert match_signature(tools, "app", "Microsoft Excel") is None
