"""Cálculos de los tableros (Resumen, áreas, herramientas)."""
from collections import Counter, defaultdict

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from ..models import (AISystem, Alert, Area, Assessment, Detection, Device, OrgToolStatus, Person,
                      WeeklySnapshot)

DIMENSIONS = ["Datos", "Seguridad", "Permisos", "Privacidad", "Procesos", "Madurez", "Casos de uso", "Riesgo", "ROI"]
SEVERITY_ORDER = {"alta": 0, "media": 1, "baja": 2}


def tool_statuses(db: Session, org_id: int) -> dict[int, OrgToolStatus]:
    return {s.tool_id: s for s in db.scalars(select(OrgToolStatus).where(OrgToolStatus.org_id == org_id))}


def detections(db: Session, org_id: int) -> list[Detection]:
    q = (select(Detection).where(Detection.org_id == org_id)
         .options(selectinload(Detection.tool),
                  selectinload(Detection.device).selectinload(Device.person).selectinload(Person.area)))
    return list(db.scalars(q))


def tool_rows(db: Session, org_id: int) -> list[dict]:
    """Una fila por herramienta detectada en la organización."""
    statuses = tool_statuses(db, org_id)
    people, devices, areas = defaultdict(set), defaultdict(set), defaultdict(set)
    first_seen, tools = {}, {}
    for d in detections(db, org_id):
        tools[d.tool_id] = d.tool
        devices[d.tool_id].add(d.device_id)
        if d.device.person_id:
            people[d.tool_id].add(d.device.person_id)
            areas[d.tool_id].add(d.device.person.area.name)
        first_seen[d.tool_id] = min(first_seen.get(d.tool_id, d.first_seen), d.first_seen)
    rows = []
    for tid, t in tools.items():
        st = statuses.get(tid)
        rows.append({
            "id": t.id, "slug": t.slug, "name": t.name, "vendor": t.vendor, "category": t.category,
            "risk": t.risk, "verdict": t.verdict, "enterprise_plan": t.enterprise_plan,
            "alternative": t.alternative, "reviewed": t.reviewed,
            "status": st.status if st else "en_revision", "owner": st.owner if st else None,
            "people": len(people[tid]), "devices": len(devices[tid]), "areas": sorted(areas[tid]),
            "first_seen": first_seen[tid].isoformat(),
        })
    rows.sort(key=lambda r: (-r["people"], r["name"]))
    return rows


def people_using(db: Session, org_id: int, statuses_filter: set[str] | None = None) -> set[int]:
    statuses = tool_statuses(db, org_id)
    result = set()
    for d in detections(db, org_id):
        st = statuses.get(d.tool_id)
        status = st.status if st else "en_revision"
        if d.device.person_id and (statuses_filter is None or status in statuses_filter):
            result.add(d.device.person_id)
    return result


def latest_assessment(db: Session, org_id: int) -> Assessment | None:
    return db.scalars(select(Assessment).where(Assessment.org_id == org_id).order_by(Assessment.id.desc())).first()


def dimension_scores(a: Assessment | None) -> list[dict]:
    if not a:
        return [{"dimension": d, "promedio": None, "respondidas": 0} for d in DIMENSIONS]
    by_dim = defaultdict(list)
    for ans in a.answers:
        if ans.score is not None:
            by_dim[ans.dimension].append(ans.score)
    return [{"dimension": d, "promedio": round(sum(v) / len(v), 2) if (v := by_dim.get(d)) else None,
             "respondidas": len(by_dim.get(d, []))} for d in DIMENSIONS]


def maturity(a: Assessment | None) -> float | None:
    vals = [d["promedio"] for d in dimension_scores(a) if d["promedio"] is not None]
    return round(sum(vals) / len(vals), 2) if vals else None


def summary(db: Session, org_id: int) -> dict:
    devices = list(db.scalars(select(Device).where(Device.org_id == org_id)))
    active = [d for d in devices if d.agent_status == "activo"]
    rows = tool_rows(db, org_id)
    total_people = len(list(db.scalars(select(Person.id).where(Person.org_id == org_id))))
    unapproved_people = people_using(db, org_id, {"no_aprobada"})
    using_people = people_using(db, org_id)
    a = latest_assessment(db, org_id)

    by_status = Counter(r["status"] for r in rows)
    trend = [{"week": s.week_start.isoformat(), "aprobadas": s.approved, "en_revision": s.in_review,
              "no_aprobadas": s.not_approved, "personas_no_aprobada": s.people_unapproved}
             for s in db.scalars(select(WeeklySnapshot).where(WeeklySnapshot.org_id == org_id)
                                 .order_by(WeeklySnapshot.week_start))]

    alerts = sorted(db.scalars(select(Alert).where(Alert.org_id == org_id, Alert.status == "abierta")),
                    key=lambda x: (SEVERITY_ORDER.get(x.severity, 9), -x.id))
    return {
        "kpis": {
            "devices": len(devices),
            "coverage_pct": round(100 * len(active) / len(devices)) if devices else 0,
            "tools_detected": len(rows),
            "approved_pct": round(100 * by_status.get("aprobada", 0) / len(rows)) if rows else 0,
            "people_total": total_people,
            "people_using_ai": len(using_people),
            "people_unapproved": len(unapproved_people),
            "high_risk_tools": sum(1 for r in rows if r["risk"] == "alto"),
            "maturity": maturity(a),
            "systems": len(list(db.scalars(select(AISystem.id).where(AISystem.org_id == org_id)))),
        },
        "status_counts": {"aprobada": by_status.get("aprobada", 0), "en_revision": by_status.get("en_revision", 0),
                          "no_aprobada": by_status.get("no_aprobada", 0)},
        "trend": trend,
        "by_area": area_rows(db, org_id),
        "top_tools": rows[:8],
        "attention": [{"id": x.id, "title": x.title, "severity": x.severity, "type": x.type} for x in alerts[:5]],
        "dimensions": dimension_scores(a),
    }


def area_rows(db: Session, org_id: int) -> list[dict]:
    statuses = tool_statuses(db, org_id)
    areas = {a.id: a.name for a in db.scalars(select(Area).where(Area.org_id == org_id))}
    headcount = Counter(p.area_id for p in db.scalars(select(Person).where(Person.org_id == org_id)))
    using, unapproved, tools = defaultdict(set), defaultdict(set), defaultdict(Counter)
    for d in detections(db, org_id):
        p = d.device.person
        if not p:
            continue
        using[p.area_id].add(p.id)
        tools[p.area_id][d.tool.name] += 1
        st = statuses.get(d.tool_id)
        if st and st.status == "no_aprobada":
            unapproved[p.area_id].add(p.id)
    rows = [{"area": name, "people": headcount.get(aid, 0), "using_ai": len(using[aid]),
             "unapproved": len(unapproved[aid]),
             "top_tool": tools[aid].most_common(1)[0][0] if tools[aid] else None}
            for aid, name in areas.items()]
    return sorted(rows, key=lambda r: -r["using_ai"])
