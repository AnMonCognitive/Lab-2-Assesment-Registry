"""Lectura de Fleet por su API REST (el worker la llama cada 15 minutos en producción).

Estado: implementado contra la documentación de la API de Fleet, NO probado aún con un servidor real.
Validar en la semana 2 del plan (rutas, paginación y forma de la respuesta de software).
"""
import re
from datetime import datetime

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..models import AITool, Detection, Device, Organization, UnknownSignature
from .catalog import match_signature

# Fuentes de software de Fleet -> tipo de firma del catálogo
SOURCE_TO_KIND = {
    "programs": "app", "apps": "app", "deb_packages": "app", "rpm_packages": "app",
    "chrome_extensions": "extension", "firefox_addons": "extension", "safari_extensions": "extension",
    "vscode_extensions": "vscode", "python_packages": "package", "npm_packages": "package",
}


AI_HINT = re.compile(r"\b(ai|a\.i\.|gpt|llm|copilot|assistant|asistente|chatbot|genai|transcri\w*)\b", re.I)


class FleetNotConfigured(Exception):
    pass


def _client() -> httpx.Client:
    if not config.FLEET_URL or not config.FLEET_API_TOKEN:
        raise FleetNotConfigured("Configura FLEET_URL y FLEET_API_TOKEN en el .env")
    return httpx.Client(base_url=config.FLEET_URL.rstrip("/"), timeout=30,
                        headers={"Authorization": f"Bearer {config.FLEET_API_TOKEN}"})


def sync_from_fleet(db: Session) -> dict:
    org = db.scalars(select(Organization).where(Organization.name == config.FLEET_ORG_NAME)).first()
    if not org:
        raise FleetNotConfigured(f"No existe la organización '{config.FLEET_ORG_NAME}'")
    tools = list(db.scalars(select(AITool)))
    stats = {"equipos": 0, "detecciones": 0, "desconocidos": 0}
    with _client() as http:
        page = 0
        while True:
            hosts = http.get("/api/v1/fleet/hosts", params={"page": page, "per_page": 100}).json().get("hosts", [])
            if not hosts:
                break
            for h in hosts:
                stats["equipos"] += 1
                dev = db.scalars(select(Device).where(Device.org_id == org.id, Device.fleet_host_id == h["id"])).first()
                if not dev:
                    dev = Device(org_id=org.id, fleet_host_id=h["id"], source="fleet", hostname=h.get("hostname", "?"),
                                 os=h.get("os_version", h.get("platform", "?")))
                    db.add(dev)
                    db.flush()
                dev.agent_status = "activo" if h.get("status") == "online" else "sin_reportar"
                dev.last_seen = datetime.utcnow()
                detail = http.get(f"/api/v1/fleet/hosts/{h['id']}").json().get("host", {})
                for sw in detail.get("software", []) or []:
                    kind = SOURCE_TO_KIND.get(sw.get("source", ""))
                    if not kind:
                        continue
                    name, ident = sw.get("name", ""), sw.get("bundle_identifier") or sw.get("extension_id")
                    tool = match_signature(tools, kind, name, ident)
                    if tool:
                        _upsert_detection(db, org.id, dev.id, tool.id, f"{kind}:{name}")
                        stats["detecciones"] += 1
                    elif AI_HINT.search(f"{name} {ident or ''}"):
                        # Solo lo que "parece IA" va a la cola de desconocidos; el resto del software se ignora.
                        record_unknown(db, org.id, kind, name, ident)
                        stats["desconocidos"] += 1
            page += 1
    db.commit()
    return stats


def _upsert_detection(db: Session, org_id: int, device_id: int, tool_id: int, raw: str) -> None:
    det = db.scalars(select(Detection).where(Detection.device_id == device_id, Detection.tool_id == tool_id)).first()
    if det:
        det.last_seen = datetime.utcnow()
    else:
        db.add(Detection(org_id=org_id, device_id=device_id, tool_id=tool_id, source="agente", raw_signature=raw))


def record_unknown(db: Session, org_id: int, kind: str, name: str, identifier: str | None) -> None:
    u = db.scalars(select(UnknownSignature).where(UnknownSignature.org_id == org_id, UnknownSignature.name == name,
                                                  UnknownSignature.kind == kind)).first()
    if u:
        u.devices_count += 1
    else:
        db.add(UnknownSignature(org_id=org_id, kind=kind, name=name, identifier=identifier))
