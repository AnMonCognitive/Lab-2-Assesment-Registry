"""Catálogo de IA: carga del YAML y reconocimiento de firmas.

Una firma es lo que reporta el agente: {"kind": "app"|"extension"|"vscode"|"process"|"package"|"domain",
"name": "...", "identifier": "..."}. El catálogo define, por herramienta, patrones por tipo.
"""
import re

import yaml
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..models import AITool

KINDS = ("apps", "extensions", "vscode", "processes", "packages", "domains")
KIND_MAP = {"app": "apps", "extension": "extensions", "vscode": "vscode", "process": "processes",
            "package": "packages", "domain": "domains"}


def load_catalog_file() -> list[dict]:
    with open(config.CATALOG_PATH, encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    return data["tools"]


def sync_catalog(db: Session) -> int:
    """Inserta o actualiza el catálogo desde el YAML. Devuelve cuántas herramientas hay."""
    existing = {t.slug: t for t in db.scalars(select(AITool))}
    tools = load_catalog_file()
    for item in tools:
        t = existing.get(item["slug"]) or AITool(slug=item["slug"])
        t.name = item["name"]
        t.vendor = item["vendor"]
        t.category = item["category"]
        t.risk = item["risk"]
        t.verdict = item["verdict"]
        t.enterprise_plan = bool(item.get("enterprise_plan", False))
        t.trains_on_data = item.get("trains_on_data", "por validar")
        t.alternative = item.get("alternative")
        t.notes = item.get("notes")
        t.reviewed = bool(item.get("reviewed", False))
        t.signatures = item.get("signatures", {})
        db.add(t)
    db.commit()
    return len(tools)


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip().lower())


def match_signature(tools: list[AITool], kind: str, name: str, identifier: str | None = None) -> AITool | None:
    """Devuelve la herramienta del catálogo que corresponde a la firma, o None si es desconocida.

    Regla: coincidencia exacta de identificador (ID de extensión, bundle id, paquete) primero;
    después, el nombre reportado contiene alguno de los patrones de nombre.
    """
    key = KIND_MAP.get(kind)
    if not key:
        return None
    n, ident = _norm(name), _norm(identifier or "")
    for t in tools:
        patterns = (t.signatures or {}).get(key, [])
        for p in patterns:
            p = _norm(p)
            if ident and p == ident:
                return t
    for t in tools:
        patterns = (t.signatures or {}).get(key, [])
        for p in patterns:
            p = _norm(p)
            if p and (p == n or (len(p) >= 4 and p in n)):
                return t
    return None
