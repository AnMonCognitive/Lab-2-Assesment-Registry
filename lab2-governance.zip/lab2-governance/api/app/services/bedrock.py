"""Única puerta de la plataforma hacia la IA (Amazon Bedrock).

Reglas que este módulo hace cumplir:
- Nunca se envían datos personales: solo nombres de herramientas, firmas técnicas y respuestas
  del assessment con la organización reemplazada por un alias.
- Topes de tokens por tarea, tiempo límite y presupuesto diario (DAILY_LLM_BUDGET_USD).
- Todo llamado queda registrado en llm_usage (tokens, costo, latencia, modo).
- BEDROCK_MODE=simulado responde con reglas locales, sin llamar a AWS.
"""
import json
import re
import time
from datetime import datetime, timedelta

from pydantic import BaseModel, Field, ValidationError
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import config
from ..models import LLMUsage

CATEGORIES = ["asistente general", "programación", "notas de reuniones", "escritura", "imagen y video",
              "búsqueda", "modelo local", "automatización", "presentaciones", "traducción", "otro"]


class ClassificationSuggestion(BaseModel):
    is_ai_tool: bool
    tool_name: str
    vendor: str
    category: str
    risk: str = Field(pattern="^(bajo|medio|alto)$")
    rationale: str
    confidence: float = Field(ge=0, le=1)


class BudgetExceeded(Exception):
    pass


def _spent_today(db: Session) -> float:
    since = datetime.utcnow() - timedelta(days=1)
    return float(db.scalar(select(func.coalesce(func.sum(LLMUsage.cost_usd), 0.0)).where(LLMUsage.created_at >= since)) or 0)


def _record(db: Session, task: str, model: str, mode: str, tin: int, tout: int, pin: float, pout: float,
            latency_ms: int, ok: bool) -> None:
    cost = tin / 1_000_000 * pin + tout / 1_000_000 * pout
    db.add(LLMUsage(task=task, model=model, mode=mode, input_tokens=tin, output_tokens=tout,
                    cost_usd=round(cost, 6), latency_ms=latency_ms, ok=ok))
    db.commit()


def _converse(model_id: str, system: str, prompt: str, max_tokens: int) -> tuple[str, int, int]:
    import boto3
    from botocore.config import Config

    client = boto3.client("bedrock-runtime", region_name=config.AWS_REGION,
                          config=Config(read_timeout=60, retries={"max_attempts": 3}))
    resp = client.converse(
        modelId=model_id,
        system=[{"text": system}],
        messages=[{"role": "user", "content": [{"text": prompt}]}],
        inferenceConfig={"maxTokens": max_tokens, "temperature": 0},
    )
    text = "".join(block.get("text", "") for block in resp["output"]["message"]["content"])
    usage = resp.get("usage", {})
    return text, int(usage.get("inputTokens", 0)), int(usage.get("outputTokens", 0))


# ---------------------------------------------------------------- clasificación

CLASSIFY_SYSTEM = (
    "Eres analista de gobierno de IA en Cognitive. Recibes una firma técnica detectada por un agente de "
    "inventario (app, extensión, proceso o paquete). Decide si es una herramienta de IA y sugiere categoría "
    "y riesgo base para una empresa. Responde SOLO con un objeto JSON con las llaves: is_ai_tool (bool), "
    "tool_name, vendor, category (una de: " + ", ".join(CATEGORIES) + "), risk (bajo|medio|alto), "
    "rationale (máx. 2 frases en español), confidence (0 a 1). Si no sabes, dilo con confidence baja."
)


def _simulated_classification(kind: str, name: str, identifier: str | None) -> ClassificationSuggestion:
    text = f"{name} {identifier or ''}".lower()
    rules = [
        (r"lm ?studio|ollama|gpt4all|llama", "modelo local", "alto",
         "Ejecuta modelos en el equipo; difícil de auditar y puede procesar datos sin controles."),
        (r"code|copilot|codeium|tabnine|cursor|continue", "programación", "medio",
         "Asistente de código; riesgo depende del plan y de si comparte código con el proveedor."),
        (r"meet|notta|otter|fireflies|transcri|record|fathom", "notas de reuniones", "alto",
         "Graba o transcribe reuniones; suele pedir acceso a calendario y audio."),
        (r"summar|gpt|ai|chat|assistant|claude|gemini", "asistente general", "medio",
         "Asistente de IA general; revisar plan empresarial y retención de datos."),
    ]
    for pattern, cat, risk, why in rules:
        if re.search(pattern, text):
            return ClassificationSuggestion(is_ai_tool=True, tool_name=name, vendor="por identificar",
                                            category=cat, risk=risk, rationale=why, confidence=0.55)
    return ClassificationSuggestion(is_ai_tool=False, tool_name=name, vendor="por identificar", category="otro",
                                    risk="bajo", rationale="No se encontraron indicios de IA en el nombre.",
                                    confidence=0.3)


def classify_signature(db: Session, kind: str, name: str, identifier: str | None) -> tuple[ClassificationSuggestion, str]:
    """Devuelve (sugerencia, modo). La sugerencia SIEMPRE la confirma un analista."""
    if config.BEDROCK_MODE != "bedrock":
        t0 = time.time()
        s = _simulated_classification(kind, name, identifier)
        _record(db, "clasificar", "reglas-locales", "simulado", 0, 0, 0, 0, int((time.time() - t0) * 1000), True)
        return s, "simulado"

    if _spent_today(db) >= config.DAILY_LLM_BUDGET_USD:
        raise BudgetExceeded("Se alcanzó el presupuesto diario de IA")
    prompt = json.dumps({"tipo": kind, "nombre": name, "identificador": identifier}, ensure_ascii=False)
    t0 = time.time()
    try:
        text, tin, tout = _converse(config.BEDROCK_MODEL_CLASSIFY, CLASSIFY_SYSTEM, prompt, max_tokens=400)
        raw = text[text.find("{"): text.rfind("}") + 1]
        s = ClassificationSuggestion.model_validate_json(raw)
        _record(db, "clasificar", config.BEDROCK_MODEL_CLASSIFY, "bedrock", tin, tout,
                config.PRICE_CLASSIFY_IN, config.PRICE_CLASSIFY_OUT, int((time.time() - t0) * 1000), True)
        return s, "bedrock"
    except (ValidationError, ValueError) as exc:
        _record(db, "clasificar", config.BEDROCK_MODEL_CLASSIFY, "bedrock", 0, 0, 0, 0,
                int((time.time() - t0) * 1000), False)
        raise RuntimeError(f"La respuesta del modelo no fue JSON válido: {exc}") from exc


# ---------------------------------------------------------------- reporte del assessment

REPORT_SYSTEM = (
    "Eres consultor senior de gobierno de IA en Cognitive. Redacta en español, en Markdown, el reporte "
    "ejecutivo de un AI Readiness Assessment. Estructura: 1) Resumen ejecutivo (3 a 4 frases con el nivel "
    "de madurez), 2) Fortalezas, 3) Brechas prioritarias (las 3 dimensiones más bajas, con por qué importan), "
    "4) Hallazgos del inventario de IA, 5) Recomendaciones a 90 días (máx. 6, accionables, con responsable "
    "sugerido por rol), 6) Casos de uso sugeridos. No inventes cifras: usa solo los datos recibidos. "
    "El consultor revisará el texto antes de entregarlo."
)


def _simulated_report(payload: dict) -> str:
    dims = sorted(payload["dimensiones"], key=lambda d: d["promedio"])
    avg = payload["madurez_global"]
    low, high = dims[:3], dims[-3:][::-1]
    inv = payload["inventario"]
    lines = [
        f"# AI Readiness Assessment · {payload['organizacion']}",
        "",
        "_Borrador generado en modo simulado (sin Bedrock). Revisar antes de entregar._",
        "",
        "## 1. Resumen ejecutivo",
        f"La organización tiene una madurez global de **{avg:.1f} de 5**. "
        f"Se detectaron **{inv['herramientas_detectadas']} herramientas de IA** en {inv['equipos']} equipos; "
        f"**{inv['personas_con_ia_no_aprobada']} personas** usan al menos una herramienta no aprobada. "
        f"Las brechas más urgentes están en {', '.join(d['dimension'] for d in low)}.",
        "",
        "## 2. Fortalezas",
        *[f"- **{d['dimension']}** ({d['promedio']:.1f}/5)" for d in high],
        "",
        "## 3. Brechas prioritarias",
        *[f"- **{d['dimension']}** ({d['promedio']:.1f}/5): {d['evidencia_clave'] or 'sin evidencia registrada'}" for d in low],
        "",
        "## 4. Hallazgos del inventario de IA",
        f"- Herramientas aprobadas: {inv['aprobadas']} · en revisión: {inv['en_revision']} · no aprobadas: {inv['no_aprobadas']}.",
        f"- Herramientas de riesgo alto en uso: {', '.join(inv['riesgo_alto']) or 'ninguna'}.",
        f"- Sistemas de IA propios registrados: {inv['sistemas_propios']} ({inv['sistemas_sin_dueno']} sin dueño).",
        "",
        "## 5. Recomendaciones a 90 días",
        "1. Publicar una política de uso aceptable de IA y la lista de herramientas aprobadas (Dirección + Seguridad).",
        "2. Sustituir las herramientas no aprobadas más usadas por su alternativa empresarial (TI).",
        "3. Asignar dueño y documentar cada sistema de IA propio en el Registry (dueños de proceso).",
        "4. Activar inicio de sesión único y bitácora en las herramientas aprobadas (TI).",
        "5. Capacitar a las áreas con más uso no aprobado (Recursos Humanos + Cognitive).",
        "6. Repetir este assessment en 90 días y comparar el puntaje.",
        "",
        "## 6. Casos de uso sugeridos",
        "- Definir con el cliente a partir de los procesos con más volumen y errores (Process Assessment).",
    ]
    return "\n".join(lines)


def assessment_report(db: Session, payload: dict) -> tuple[str, str]:
    """payload ya viene sin datos personales (ver routers/assessment.py). Devuelve (markdown, modo)."""
    if config.BEDROCK_MODE != "bedrock":
        t0 = time.time()
        md = _simulated_report(payload)
        _record(db, "reporte_assessment", "plantilla-local", "simulado", 0, 0, 0, 0, int((time.time() - t0) * 1000), True)
        return md, "simulado"
    if _spent_today(db) >= config.DAILY_LLM_BUDGET_USD:
        raise BudgetExceeded("Se alcanzó el presupuesto diario de IA")
    t0 = time.time()
    text, tin, tout = _converse(config.BEDROCK_MODEL_REPORT, REPORT_SYSTEM,
                                json.dumps(payload, ensure_ascii=False, indent=1), max_tokens=4000)
    _record(db, "reporte_assessment", config.BEDROCK_MODEL_REPORT, "bedrock", tin, tout,
            config.PRICE_REPORT_IN, config.PRICE_REPORT_OUT, int((time.time() - t0) * 1000), True)
    return text, "bedrock"
