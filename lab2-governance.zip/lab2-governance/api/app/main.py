"""Cognitive Governance Platform · Lab 2 (Readiness Assessment + Registry) — versión preliminar."""
import logging
import sys

from fastapi import FastAPI
from starlette.middleware.sessions import SessionMiddleware

from . import config

# Permite importar seed/ desde la raíz del repositorio.
sys.path.insert(0, str(config.ROOT_DIR))

from .db import Base, engine  # noqa: E402
from .routers import admin, assessment, auth_routes, catalog_routes, inventory, registry  # noqa: E402

log = logging.getLogger("lab2")

app = FastAPI(title="Cognitive Governance Platform · Lab 2", version="0.1.0",
              description="Readiness Assessment + AI Registry (versión preliminar para la demo)")
app.add_middleware(SessionMiddleware, secret_key=config.SESSION_SECRET, session_cookie="lab2_session",
                   same_site="lax", https_only=config.SESSION_HTTPS_ONLY, max_age=8 * 3600)

for r in (auth_routes, inventory, registry, catalog_routes, assessment, admin):
    app.include_router(r.router)


@app.on_event("startup")
def startup() -> None:
    Base.metadata.create_all(engine)
    if config.SEED_ON_START:
        from seed.generate_demo import seed_if_empty
        if seed_if_empty():
            log.warning("Base vacía: se cargaron el catálogo y los datos de demo")


@app.get("/api/health")
def health():
    return {"ok": True, "bedrock_mode": config.BEDROCK_MODE, "auth_mode": config.AUTH_MODE}
