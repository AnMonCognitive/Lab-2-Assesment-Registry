"""Modelo de datos de la plataforma (PostgreSQL).

Toda tabla de cliente lleva org_id. La API filtra siempre por organización y,
en producción, se suma la seguridad por fila de PostgreSQL (ops/rls.sql).
"""
from datetime import date, datetime

from sqlalchemy import JSON, Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def now() -> datetime:
    return datetime.utcnow()


class Organization(Base):
    __tablename__ = "organizations"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True)
    kind: Mapped[str] = mapped_column(String(20), default="cliente")  # cliente | cognitive
    is_demo: Mapped[bool] = mapped_column(Boolean, default=True)


class ConsoleUser(Base):
    """Quién entra a la consola. org_id nulo = personal de Cognitive (ve clientes asignados)."""
    __tablename__ = "console_users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(200), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    role: Mapped[str] = mapped_column(String(40))
    org_id: Mapped[int | None] = mapped_column(ForeignKey("organizations.id"), nullable=True)


class Area(Base):
    __tablename__ = "areas"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    name: Mapped[str] = mapped_column(String(80))


class Person(Base):
    __tablename__ = "people"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    area_id: Mapped[int] = mapped_column(ForeignKey("areas.id"))
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(200))
    area: Mapped[Area] = relationship()


class Device(Base):
    __tablename__ = "devices"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    person_id: Mapped[int | None] = mapped_column(ForeignKey("people.id"), nullable=True)
    hostname: Mapped[str] = mapped_column(String(120))
    os: Mapped[str] = mapped_column(String(60))
    agent_status: Mapped[str] = mapped_column(String(20), default="activo")  # activo | sin_reportar | pendiente
    last_seen: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    source: Mapped[str] = mapped_column(String(20), default="simulado")  # simulado | fleet
    fleet_host_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    person: Mapped[Person | None] = relationship()


class AITool(Base):
    """Catálogo global de herramientas de IA (compartido por todos los clientes)."""
    __tablename__ = "ai_tools"
    id: Mapped[int] = mapped_column(primary_key=True)
    slug: Mapped[str] = mapped_column(String(80), unique=True)
    name: Mapped[str] = mapped_column(String(120))
    vendor: Mapped[str] = mapped_column(String(120))
    category: Mapped[str] = mapped_column(String(60))
    risk: Mapped[str] = mapped_column(String(10))  # bajo | medio | alto
    verdict: Mapped[str] = mapped_column(String(20))  # adoptar | esperar | descartar
    enterprise_plan: Mapped[bool] = mapped_column(Boolean, default=False)
    trains_on_data: Mapped[str] = mapped_column(String(40), default="por validar")
    alternative: Mapped[str | None] = mapped_column(String(120), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    reviewed: Mapped[bool] = mapped_column(Boolean, default=False)
    signatures: Mapped[dict] = mapped_column(JSON, default=dict)


class Detection(Base):
    __tablename__ = "detections"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    device_id: Mapped[int] = mapped_column(ForeignKey("devices.id"), index=True)
    tool_id: Mapped[int] = mapped_column(ForeignKey("ai_tools.id"), index=True)
    source: Mapped[str] = mapped_column(String(20), default="agente")  # agente | manual | m365
    raw_signature: Mapped[str] = mapped_column(String(300))
    first_seen: Mapped[datetime] = mapped_column(DateTime, default=now)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=now)
    device: Mapped[Device] = relationship()
    tool: Mapped[AITool] = relationship()


class OrgToolStatus(Base):
    """Decisión de cada cliente sobre cada herramienta."""
    __tablename__ = "org_tool_status"
    __table_args__ = (UniqueConstraint("org_id", "tool_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    tool_id: Mapped[int] = mapped_column(ForeignKey("ai_tools.id"))
    status: Mapped[str] = mapped_column(String(20), default="en_revision")  # aprobada | en_revision | no_aprobada
    owner: Mapped[str | None] = mapped_column(String(120), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class UnknownSignature(Base):
    """Hallazgos que el catálogo no reconoce: Claude sugiere, un analista confirma."""
    __tablename__ = "unknown_signatures"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    kind: Mapped[str] = mapped_column(String(30))  # app | extension | process | package | vscode
    name: Mapped[str] = mapped_column(String(200))
    identifier: Mapped[str | None] = mapped_column(String(200), nullable=True)
    devices_count: Mapped[int] = mapped_column(Integer, default=1)
    status: Mapped[str] = mapped_column(String(20), default="pendiente")  # pendiente | sugerido | confirmado | descartado
    suggestion: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class AISystem(Base):
    """Registry: sistemas de IA propios del cliente (agentes, automatizaciones)."""
    __tablename__ = "ai_systems"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    owner: Mapped[str | None] = mapped_column(String(120), nullable=True)
    area: Mapped[str | None] = mapped_column(String(80), nullable=True)
    purpose: Mapped[str | None] = mapped_column(Text, nullable=True)
    model: Mapped[str | None] = mapped_column(String(80), nullable=True)
    provider: Mapped[str | None] = mapped_column(String(80), nullable=True)
    platform: Mapped[str | None] = mapped_column(String(80), nullable=True)
    data_sources: Mapped[str | None] = mapped_column(Text, nullable=True)
    permissions: Mapped[str | None] = mapped_column(Text, nullable=True)
    monthly_cost_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    risk: Mapped[str] = mapped_column(String(10), default="medio")
    failure_impact: Mapped[str | None] = mapped_column(Text, nullable=True)
    human_approval: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[str] = mapped_column(String(20), default="produccion")  # piloto | produccion | retirado
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Alert(Base):
    __tablename__ = "alerts"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    type: Mapped[str] = mapped_column(String(40))  # ia_no_aprobada | extension_nueva | sistema_sin_dueno | oauth_amplio
    severity: Mapped[str] = mapped_column(String(10))  # alta | media | baja
    title: Mapped[str] = mapped_column(String(200))
    detail: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="abierta")  # abierta | atendida | descartada
    ref: Mapped[str | None] = mapped_column(String(80), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class Assessment(Base):
    __tablename__ = "assessments"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
    status: Mapped[str] = mapped_column(String(20), default="en_curso")  # en_curso | completo
    report_md: Mapped[str | None] = mapped_column(Text, nullable=True)
    report_generated_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    report_mode: Mapped[str | None] = mapped_column(String(20), nullable=True)
    answers: Mapped[list["AssessmentAnswer"]] = relationship(back_populates="assessment", order_by="AssessmentAnswer.id")


class AssessmentAnswer(Base):
    __tablename__ = "assessment_answers"
    id: Mapped[int] = mapped_column(primary_key=True)
    assessment_id: Mapped[int] = mapped_column(ForeignKey("assessments.id"), index=True)
    dimension: Mapped[str] = mapped_column(String(40))
    question: Mapped[str] = mapped_column(Text)
    score: Mapped[int | None] = mapped_column(Integer, nullable=True)  # 0 a 5
    evidence: Mapped[str | None] = mapped_column(Text, nullable=True)
    assessment: Mapped[Assessment] = relationship(back_populates="answers")


class WeeklySnapshot(Base):
    """Foto semanal para las tendencias del Resumen."""
    __tablename__ = "weekly_snapshots"
    id: Mapped[int] = mapped_column(primary_key=True)
    org_id: Mapped[int] = mapped_column(ForeignKey("organizations.id"), index=True)
    week_start: Mapped[date] = mapped_column(Date)
    approved: Mapped[int] = mapped_column(Integer)
    in_review: Mapped[int] = mapped_column(Integer)
    not_approved: Mapped[int] = mapped_column(Integer)
    people_unapproved: Mapped[int] = mapped_column(Integer)


class LLMUsage(Base):
    """Consumo de IA: semilla del futuro Agent Monitor."""
    __tablename__ = "llm_usage"
    id: Mapped[int] = mapped_column(primary_key=True)
    task: Mapped[str] = mapped_column(String(40))
    model: Mapped[str] = mapped_column(String(120))
    mode: Mapped[str] = mapped_column(String(20))  # bedrock | simulado
    input_tokens: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, default=0)
    cost_usd: Mapped[float] = mapped_column(Float, default=0.0)
    latency_ms: Mapped[int] = mapped_column(Integer, default=0)
    ok: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_email: Mapped[str] = mapped_column(String(200))
    org_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    action: Mapped[str] = mapped_column(String(60))
    object: Mapped[str | None] = mapped_column(String(200), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=now)
