"""Configuración leída de variables de entorno (ver .env.example en la raíz)."""
import os
from pathlib import Path


def _bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "si", "sí"}


ROOT_DIR = Path(__file__).resolve().parents[2]

DATABASE_URL = os.getenv("DATABASE_URL", "postgresql+psycopg://lab2:lab2@localhost:5432/lab2")
SESSION_SECRET = os.getenv("SESSION_SECRET", "cambia-esto-en-produccion")
SEED_ON_START = _bool("SEED_ON_START", True)
# En el servidor con HTTPS debe ser true (la cookie de sesión solo viaja cifrada).
SESSION_HTTPS_ONLY = _bool("SESSION_HTTPS_ONLY", False)

# Login: "dev" = selector de usuarios de prueba. "entra" = Microsoft Entra ID (pendiente, ver auth.py).
AUTH_MODE = os.getenv("AUTH_MODE", "dev")

# Catálogo de IA (YAML versionado en el repositorio)
CATALOG_PATH = Path(os.getenv("CATALOG_PATH", ROOT_DIR / "catalog" / "ai_catalog.yaml"))

# Amazon Bedrock. "simulado" responde sin llamar a AWS (útil sin llaves o sin internet).
BEDROCK_MODE = os.getenv("BEDROCK_MODE", "simulado")  # simulado | bedrock
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
# Verificar los IDs exactos (o perfiles de inferencia globales) en la consola de Bedrock.
BEDROCK_MODEL_CLASSIFY = os.getenv("BEDROCK_MODEL_CLASSIFY", "global.anthropic.claude-haiku-4-5")
BEDROCK_MODEL_REPORT = os.getenv("BEDROCK_MODEL_REPORT", "global.anthropic.claude-sonnet-5")
# Precio por millón de tokens (USD) para registrar consumo. Confirmar en la página oficial.
PRICE_CLASSIFY_IN = float(os.getenv("PRICE_CLASSIFY_IN", "1.0"))
PRICE_CLASSIFY_OUT = float(os.getenv("PRICE_CLASSIFY_OUT", "5.0"))
PRICE_REPORT_IN = float(os.getenv("PRICE_REPORT_IN", "2.0"))
PRICE_REPORT_OUT = float(os.getenv("PRICE_REPORT_OUT", "10.0"))
DAILY_LLM_BUDGET_USD = float(os.getenv("DAILY_LLM_BUDGET_USD", "5.0"))

# Fleet (opcional). Sin URL ni token, la sincronización responde "no configurado".
FLEET_URL = os.getenv("FLEET_URL", "")
FLEET_API_TOKEN = os.getenv("FLEET_API_TOKEN", "")
FLEET_ORG_NAME = os.getenv("FLEET_ORG_NAME", "Cognitive (interno)")
