"""Readiness Assessment: cuestionario por dimensión, puntaje y reporte redactado con IA."""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import CAN_EDIT_ASSESSMENT, Ctx, audit, require_org
from ..db import get_db
from ..models import AISystem, AssessmentAnswer
from ..services import bedrock, metrics

router = APIRouter(prefix="/api/assessment", tags=["assessment"])


def _out(a, can_edit: bool) -> dict:
    groups: dict[str, list] = {d: [] for d in metrics.DIMENSIONS}
    for ans in a.answers:
        groups.setdefault(ans.dimension, []).append(
            {"id": ans.id, "question": ans.question, "score": ans.score, "evidence": ans.evidence})
    return {"id": a.id, "status": a.status, "created_at": a.created_at.isoformat(),
            "maturity": metrics.maturity(a), "dimensions": metrics.dimension_scores(a),
            "questions": [{"dimension": d, "items": items} for d, items in groups.items()],
            "has_report": bool(a.report_md),
            "report_generated_at": a.report_generated_at.isoformat() if a.report_generated_at else None,
            "report_mode": a.report_mode, "can_edit": can_edit}


@router.get("")
def get_assessment(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    a = metrics.latest_assessment(db, c.org_id)
    if not a:
        raise HTTPException(404, "Esta organización aún no tiene assessment")
    return _out(a, c.role in CAN_EDIT_ASSESSMENT)


class AnswerIn(BaseModel):
    score: int | None = Field(default=None, ge=0, le=5)
    evidence: str | None = None


@router.put("/answers/{answer_id}")
def update_answer(answer_id: int, body: AnswerIn, c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    if c.role not in CAN_EDIT_ASSESSMENT:
        raise HTTPException(403, "Solo el consultor de Cognitive edita el assessment")
    ans = db.get(AssessmentAnswer, answer_id)
    if not ans or ans.assessment.org_id != c.org_id:
        raise HTTPException(404)
    ans.score, ans.evidence = body.score, body.evidence
    db.commit()
    return {"ok": True}


def build_payload(db: Session, org_id: int, a) -> dict:
    """Datos para el modelo, SIN datos personales: ni nombres, ni correos, ni hostnames."""
    s = metrics.summary(db, org_id)
    rows = metrics.tool_rows(db, org_id)
    systems = list(db.scalars(select(AISystem).where(AISystem.org_id == org_id)))
    dims = []
    for d in metrics.dimension_scores(a):
        ev = [x.evidence for x in a.answers if x.dimension == d["dimension"] and x.evidence]
        dims.append({"dimension": d["dimension"], "promedio": d["promedio"] or 0, "evidencia_clave": ev[0] if ev else ""})
    return {
        "organizacion": "Cliente (alias)",  # el nombre real no se envía al modelo
        "madurez_global": s["kpis"]["maturity"] or 0,
        "dimensiones": dims,
        "inventario": {
            "equipos": s["kpis"]["devices"], "herramientas_detectadas": s["kpis"]["tools_detected"],
            "personas_con_ia_no_aprobada": s["kpis"]["people_unapproved"],
            "aprobadas": s["status_counts"]["aprobada"], "en_revision": s["status_counts"]["en_revision"],
            "no_aprobadas": s["status_counts"]["no_aprobada"],
            "riesgo_alto": [r["name"] for r in rows if r["risk"] == "alto"],
            "uso_por_area": [{"area": r["area"], "personas_con_ia": r["using_ai"], "no_aprobada": r["unapproved"]}
                             for r in s["by_area"]],
            "sistemas_propios": len(systems), "sistemas_sin_dueno": sum(1 for x in systems if not x.owner),
        },
    }


@router.post("/report")
def generate_report(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    if c.role not in CAN_EDIT_ASSESSMENT:
        raise HTTPException(403, "Solo el consultor de Cognitive genera el reporte")
    a = metrics.latest_assessment(db, c.org_id)
    if not a:
        raise HTTPException(404)
    try:
        md, mode = bedrock.assessment_report(db, build_payload(db, c.org_id, a))
    except bedrock.BudgetExceeded as exc:
        raise HTTPException(429, str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(502, f"No se pudo generar el reporte: {exc}") from exc
    # El alias se sustituye por el nombre real solo dentro de la plataforma.
    from ..models import Organization
    org = db.get(Organization, c.org_id)
    a.report_md = md.replace("Cliente (alias)", org.name)
    a.report_generated_at, a.report_mode = datetime.utcnow(), mode
    audit(db, c, "generar_reporte_assessment", str(a.id))
    db.commit()
    return {"ok": True, "mode": mode}


@router.get("/report")
def get_report(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    a = metrics.latest_assessment(db, c.org_id)
    if not a or not a.report_md:
        raise HTTPException(404, "Aún no hay reporte generado")
    return {"markdown": a.report_md, "generated_at": a.report_generated_at.isoformat(), "mode": a.report_mode}
