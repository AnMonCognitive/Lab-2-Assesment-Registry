"""Registry de sistemas de IA propios y Alertas."""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import CAN_DECIDE_TOOLS, CAN_EDIT_SYSTEMS, Ctx, audit, require_org
from ..db import get_db
from ..models import AISystem, Alert

router = APIRouter(prefix="/api", tags=["registry"])

SYSTEM_FIELDS = ["name", "owner", "area", "purpose", "model", "provider", "platform", "data_sources", "permissions",
                 "monthly_cost_usd", "risk", "failure_impact", "human_approval", "status"]


class SystemIn(BaseModel):
    name: str
    owner: str | None = None
    area: str | None = None
    purpose: str | None = None
    model: str | None = None
    provider: str | None = None
    platform: str | None = None
    data_sources: str | None = None
    permissions: str | None = None
    monthly_cost_usd: float | None = None
    risk: str = "medio"
    failure_impact: str | None = None
    human_approval: bool = False
    status: str = "produccion"


def _sys_out(s: AISystem) -> dict:
    out = {f: getattr(s, f) for f in SYSTEM_FIELDS}
    out |= {"id": s.id, "updated_at": s.updated_at.isoformat(),
            "missing": [label for f, label in [("owner", "dueño"), ("data_sources", "datos que consulta"),
                                                ("permissions", "permisos"), ("failure_impact", "qué pasa si falla")]
                        if not getattr(s, f)]}
    return out


@router.get("/systems")
def list_systems(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    return [_sys_out(s) for s in db.scalars(select(AISystem).where(AISystem.org_id == c.org_id).order_by(AISystem.name))]


@router.post("/systems")
def create_system(body: SystemIn, c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    if c.role not in CAN_EDIT_SYSTEMS:
        raise HTTPException(403, "Tu rol no puede registrar sistemas")
    s = AISystem(org_id=c.org_id, **body.model_dump())
    db.add(s)
    audit(db, c, "registrar_sistema", body.name)
    db.commit()
    return _sys_out(s)


@router.put("/systems/{sid}")
def update_system(sid: int, body: SystemIn, c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    s = db.get(AISystem, sid)
    if not s or s.org_id != c.org_id:
        raise HTTPException(404)
    if c.role not in CAN_EDIT_SYSTEMS:
        raise HTTPException(403, "Tu rol no puede editar sistemas")
    for k, v in body.model_dump().items():
        setattr(s, k, v)
    s.updated_at = datetime.utcnow()
    audit(db, c, "editar_sistema", s.name)
    db.commit()
    return _sys_out(s)


@router.get("/alerts")
def list_alerts(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    order = {"abierta": 0, "atendida": 1, "descartada": 2}
    sev = {"alta": 0, "media": 1, "baja": 2}
    alerts = sorted(db.scalars(select(Alert).where(Alert.org_id == c.org_id)),
                    key=lambda a: (order.get(a.status, 9), sev.get(a.severity, 9), -a.id))
    return [{"id": a.id, "type": a.type, "severity": a.severity, "title": a.title, "detail": a.detail,
             "status": a.status, "ref": a.ref, "created_at": a.created_at.isoformat()} for a in alerts]


class AlertIn(BaseModel):
    status: str


@router.patch("/alerts/{aid}")
def update_alert(aid: int, body: AlertIn, c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    a = db.get(Alert, aid)
    if not a or a.org_id != c.org_id:
        raise HTTPException(404)
    if c.role not in CAN_DECIDE_TOOLS:
        raise HTTPException(403, "Solo Seguridad o Cognitive atienden alertas")
    if body.status not in {"abierta", "atendida", "descartada"}:
        raise HTTPException(422, "Estado inválido")
    a.status = body.status
    audit(db, c, "actualizar_alerta", f"{aid}:{body.status}")
    db.commit()
    return {"ok": True}
