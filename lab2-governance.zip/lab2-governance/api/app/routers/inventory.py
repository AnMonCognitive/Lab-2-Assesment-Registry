"""Organizaciones, Resumen, Herramientas, Dispositivos y Áreas."""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from ..auth import CAN_DECIDE_TOOLS, COGNITIVE_ROLES, Ctx, audit, ctx, require_org
from ..db import get_db
from ..models import AITool, Detection, Device, Organization, OrgToolStatus, Person
from ..services import metrics

router = APIRouter(prefix="/api", tags=["inventario"])


@router.get("/orgs")
def orgs(c: Ctx = Depends(ctx), db: Session = Depends(get_db)):
    if c.role == "analista_catalogo":
        return []  # el analista trabaja solo con el catálogo, sin datos de clientes
    if c.role not in COGNITIVE_ROLES:
        o = db.get(Organization, c.org_id)
        return [{"id": o.id, "name": o.name, "kind": o.kind}]
    return [{"id": o.id, "name": o.name, "kind": o.kind}
            for o in db.scalars(select(Organization).order_by(Organization.kind.desc(), Organization.id))]


@router.get("/summary")
def summary(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    return metrics.summary(db, c.org_id)


@router.get("/areas")
def areas(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    return metrics.area_rows(db, c.org_id)


@router.get("/tools")
def tools(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    return metrics.tool_rows(db, c.org_id)


@router.get("/tools/{tool_id}")
def tool_detail(tool_id: int, c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    t = db.get(AITool, tool_id)
    if not t:
        raise HTTPException(404)
    row = next((r for r in metrics.tool_rows(db, c.org_id) if r["id"] == tool_id), None)
    dets = db.scalars(select(Detection).where(Detection.org_id == c.org_id, Detection.tool_id == tool_id)
                      .options(selectinload(Detection.device).selectinload(Device.person).selectinload(Person.area)))
    usage = []
    for d in dets:
        p = d.device.person
        item = {"area": p.area.name if p else None, "first_seen": d.first_seen.isoformat(),
                "last_seen": d.last_seen.isoformat(), "signature": d.raw_signature}
        if c.sees_people:  # Dirección solo ve agregados por área
            item |= {"person": p.name if p else None, "hostname": d.device.hostname}
        usage.append(item)
    return {"tool": {"id": t.id, "name": t.name, "vendor": t.vendor, "category": t.category, "risk": t.risk,
                     "verdict": t.verdict, "enterprise_plan": t.enterprise_plan, "trains_on_data": t.trains_on_data,
                     "alternative": t.alternative, "notes": t.notes, "reviewed": t.reviewed},
            "org": row, "usage": usage, "can_decide": c.role in CAN_DECIDE_TOOLS, "sees_people": c.sees_people}


class StatusIn(BaseModel):
    status: str
    owner: str | None = None


@router.patch("/tools/{tool_id}/status")
def set_status(tool_id: int, body: StatusIn, c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    if c.role not in CAN_DECIDE_TOOLS:
        raise HTTPException(403, "Solo Seguridad o Cognitive deciden el estado de una herramienta")
    if body.status not in {"aprobada", "en_revision", "no_aprobada"}:
        raise HTTPException(422, "Estado inválido")
    st = db.scalars(select(OrgToolStatus).where(OrgToolStatus.org_id == c.org_id, OrgToolStatus.tool_id == tool_id)).first()
    if not st:
        st = OrgToolStatus(org_id=c.org_id, tool_id=tool_id)
        db.add(st)
    st.status, st.updated_at = body.status, datetime.utcnow()
    if body.owner is not None:
        st.owner = body.owner
    audit(db, c, "cambiar_estado_herramienta", f"{tool_id}:{body.status}")
    db.commit()
    return {"ok": True}


@router.get("/devices")
def devices(c: Ctx = Depends(require_org), db: Session = Depends(get_db)):
    if not c.sees_people:
        raise HTTPException(403, "Tu rol ve solo información agregada por área")
    devs = db.scalars(select(Device).where(Device.org_id == c.org_id)
                      .options(selectinload(Device.person).selectinload(Person.area)).order_by(Device.hostname))
    by_dev: dict[int, list[str]] = {}
    statuses = metrics.tool_statuses(db, c.org_id)
    unapproved: dict[int, int] = {}
    for d in metrics.detections(db, c.org_id):
        by_dev.setdefault(d.device_id, []).append(d.tool.name)
        st = statuses.get(d.tool_id)
        if st and st.status == "no_aprobada":
            unapproved[d.device_id] = unapproved.get(d.device_id, 0) + 1
    audit(db, c, "ver_dispositivos")
    db.commit()
    return [{"id": d.id, "hostname": d.hostname, "os": d.os, "agent_status": d.agent_status, "source": d.source,
             "last_seen": d.last_seen.isoformat() if d.last_seen else None,
             "person": d.person.name if d.person else None, "area": d.person.area.name if d.person else None,
             "tools": sorted(by_dev.get(d.id, [])), "unapproved": unapproved.get(d.id, 0)} for d in devs]
