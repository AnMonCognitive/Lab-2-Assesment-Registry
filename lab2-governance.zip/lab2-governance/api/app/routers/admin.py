"""Operación: consumo de IA, bitácora, sincronización con Fleet y reinicio de la demo."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import config
from ..auth import Ctx, audit, ctx, require_roles
from ..db import get_db
from ..models import AuditLog, LLMUsage
from ..services import fleet

router = APIRouter(prefix="/api/admin", tags=["operación"])


@router.get("/llm-usage")
def llm_usage(c: Ctx = Depends(require_roles("admin_cognitive", "consultor")), db: Session = Depends(get_db)):
    rows = list(db.scalars(select(LLMUsage).order_by(LLMUsage.id.desc()).limit(100)))
    total = db.scalar(select(func.coalesce(func.sum(LLMUsage.cost_usd), 0.0)))
    return {"mode": config.BEDROCK_MODE, "total_cost_usd": round(float(total or 0), 4),
            "daily_budget_usd": config.DAILY_LLM_BUDGET_USD,
            "calls": [{"task": r.task, "model": r.model, "mode": r.mode, "input_tokens": r.input_tokens,
                       "output_tokens": r.output_tokens, "cost_usd": r.cost_usd, "latency_ms": r.latency_ms,
                       "ok": r.ok, "at": r.created_at.isoformat()} for r in rows]}


@router.get("/audit")
def audit_log(c: Ctx = Depends(ctx), db: Session = Depends(get_db)):
    """Bitácora de accesos. El admin de Cognitive ve todo; un usuario de cliente, la de su organización."""
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(200)
    if c.user.org_id is not None:
        if c.role not in {"cliente_admin_ti", "cliente_seguridad"}:
            raise HTTPException(403)
        q = q.where(AuditLog.org_id == c.user.org_id)
    elif c.role != "admin_cognitive":
        raise HTTPException(403)
    return [{"user": r.user_email, "org_id": r.org_id, "action": r.action, "object": r.object,
             "at": r.created_at.isoformat()} for r in db.scalars(q)]


@router.post("/fleet-sync")
def fleet_sync(c: Ctx = Depends(require_roles("admin_cognitive")), db: Session = Depends(get_db)):
    try:
        stats = fleet.sync_from_fleet(db)
    except fleet.FleetNotConfigured as exc:
        raise HTTPException(400, str(exc)) from exc
    audit(db, c, "sincronizar_fleet")
    db.commit()
    return stats


@router.post("/reset-demo")
def reset_demo(c: Ctx = Depends(require_roles("admin_cognitive"))):
    """Borra y vuelve a generar los datos de demo (misma semilla = misma demo cada vez)."""
    from seed.generate_demo import reset_and_seed
    reset_and_seed()
    return {"ok": True}
