"""Catálogo de IA (global) y cola de desconocidos (Tech Evaluation)."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import CAN_EDIT_CATALOG, COGNITIVE_ROLES, Ctx, audit, ctx
from ..db import get_db
from ..models import AITool, Organization, UnknownSignature
from ..services import bedrock

router = APIRouter(prefix="/api/catalog", tags=["catálogo"])


def _cognitive_only(c: Ctx = Depends(ctx)) -> Ctx:
    if c.role not in COGNITIVE_ROLES:
        raise HTTPException(403, "El catálogo es interno de Cognitive")
    return c


@router.get("")
def list_catalog(c: Ctx = Depends(ctx), db: Session = Depends(get_db)):
    return [{"id": t.id, "slug": t.slug, "name": t.name, "vendor": t.vendor, "category": t.category, "risk": t.risk,
             "verdict": t.verdict, "enterprise_plan": t.enterprise_plan, "trains_on_data": t.trains_on_data,
             "alternative": t.alternative, "reviewed": t.reviewed,
             "signature_count": sum(len(v) for v in (t.signatures or {}).values())}
            for t in db.scalars(select(AITool).order_by(AITool.category, AITool.name))]


@router.get("/unknowns")
def unknowns(c: Ctx = Depends(_cognitive_only), db: Session = Depends(get_db)):
    orgs = {o.id: o.name for o in db.scalars(select(Organization))}
    # El analista ve la firma, no la organización ni las personas.
    show_org = c.role != "analista_catalogo"
    return [{"id": u.id, "kind": u.kind, "name": u.name, "identifier": u.identifier, "devices_count": u.devices_count,
             "status": u.status, "suggestion": u.suggestion, "org": orgs.get(u.org_id) if show_org else None}
            for u in db.scalars(select(UnknownSignature).order_by(UnknownSignature.status, UnknownSignature.id))]


@router.post("/unknowns/{uid}/classify")
def classify(uid: int, c: Ctx = Depends(_cognitive_only), db: Session = Depends(get_db)):
    u = db.get(UnknownSignature, uid)
    if not u:
        raise HTTPException(404)
    try:
        s, mode = bedrock.classify_signature(db, u.kind, u.name, u.identifier)
    except bedrock.BudgetExceeded as exc:
        raise HTTPException(429, str(exc)) from exc
    except Exception as exc:  # noqa: BLE001 - se informa al usuario, no se cae la consola
        raise HTTPException(502, f"No se pudo clasificar: {exc}") from exc
    u.suggestion = s.model_dump() | {"mode": mode}
    u.status = "sugerido"
    audit(db, c, "clasificar_desconocido", u.name)
    db.commit()
    return u.suggestion


class ConfirmIn(BaseModel):
    action: str  # agregar | descartar
    name: str | None = None
    vendor: str | None = None
    category: str | None = None
    risk: str | None = None
    verdict: str = "esperar"


@router.post("/unknowns/{uid}/confirm")
def confirm(uid: int, body: ConfirmIn, c: Ctx = Depends(_cognitive_only), db: Session = Depends(get_db)):
    if c.role not in CAN_EDIT_CATALOG:
        raise HTTPException(403, "Solo el analista de catálogo o un admin publican fichas")
    u = db.get(UnknownSignature, uid)
    if not u:
        raise HTTPException(404)
    if body.action == "descartar":
        u.status = "descartado"
        audit(db, c, "descartar_desconocido", u.name)
        db.commit()
        return {"ok": True}
    sug = u.suggestion or {}
    name = body.name or sug.get("tool_name") or u.name
    slug = "".join(ch if ch.isalnum() else "-" for ch in name.lower()).strip("-")[:70]
    key = {"app": "apps", "extension": "extensions", "vscode": "vscode", "process": "processes",
           "package": "packages"}.get(u.kind, "apps")
    tool = db.scalars(select(AITool).where(AITool.slug == slug)).first() or AITool(slug=slug, signatures={})
    tool.name, tool.vendor = name, body.vendor or sug.get("vendor") or "por identificar"
    tool.category = body.category or sug.get("category") or "otro"
    tool.risk = body.risk or sug.get("risk") or "medio"
    tool.verdict, tool.reviewed = body.verdict, True
    sigs = dict(tool.signatures or {})
    sigs[key] = sorted(set(sigs.get(key, []) + [u.identifier or u.name]))
    tool.signatures = sigs
    db.add(tool)
    u.status = "confirmado"
    audit(db, c, "publicar_ficha", name)
    db.commit()
    return {"ok": True, "tool_id": tool.id}
