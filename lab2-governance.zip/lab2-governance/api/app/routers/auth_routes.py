from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..auth import COGNITIVE_ROLES, ROLE_LABELS, current_user
from ..db import get_db
from ..models import AuditLog, ConsoleUser, Organization

router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginIn(BaseModel):
    email: str


def _user_out(u: ConsoleUser, db: Session) -> dict:
    org = db.get(Organization, u.org_id) if u.org_id else None
    return {"id": u.id, "email": u.email, "name": u.name, "role": u.role, "role_label": ROLE_LABELS.get(u.role, u.role),
            "org_id": u.org_id, "org_name": org.name if org else "Cognitive", "is_cognitive": u.role in COGNITIVE_ROLES}


@router.get("/mode")
def mode():
    return {"auth_mode": config.AUTH_MODE, "bedrock_mode": config.BEDROCK_MODE}


@router.get("/dev-users")
def dev_users(db: Session = Depends(get_db)):
    if config.AUTH_MODE != "dev":
        raise HTTPException(404)
    return [_user_out(u, db) for u in db.scalars(select(ConsoleUser).order_by(ConsoleUser.id))]


@router.post("/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    if config.AUTH_MODE != "dev":
        raise HTTPException(400, "El login de prueba está desactivado; usa Microsoft Entra ID")
    user = db.scalars(select(ConsoleUser).where(ConsoleUser.email == body.email)).first()
    if not user:
        raise HTTPException(401, "Usuario no encontrado")
    request.session["uid"] = user.id
    db.add(AuditLog(user_email=user.email, org_id=user.org_id, action="login"))
    db.commit()
    return _user_out(user, db)


@router.post("/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}


@router.get("/me")
def me(user: ConsoleUser = Depends(current_user), db: Session = Depends(get_db)):
    return _user_out(user, db)
