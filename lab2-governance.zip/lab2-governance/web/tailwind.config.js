/** Paleta de Cognitive: azul marino, crema y naranja como acento (solo para lo que pide acción). */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        navy: { DEFAULT: "#121A2B", 700: "#1B2740", 500: "#3B5078" },
        cream: { DEFAULT: "#F3F1EA", card: "#FBFAF6", line: "#E0DCD0" },
        accent: { DEFAULT: "#FF7A3D", dark: "#B84A12", tint: "#FDE9DE" },
        data: { DEFAULT: "#1F5FA8", tint: "#E3ECF8", soft: "#A9B4CC" },
        ink: { DEFAULT: "#121A2B", 2: "#4A5263", 3: "#5F6675" },
      },
      fontFamily: {
        display: ["Space Grotesk", "Arial", "sans-serif"],
        sans: ["IBM Plex Sans", "Arial", "sans-serif"],
        mono: ["JetBrains Mono", "Courier New", "monospace"],
      },
    },
  },
  plugins: [],
};
