import { ReactNode, useEffect, useState } from "react";

export const STATUS_LABEL: Record<string, string> = { aprobada: "Aprobada", en_revision: "En revisión", no_aprobada: "No aprobada" };
export const STATUS_COLOR: Record<string, string> = { aprobada: "#1F5FA8", en_revision: "#A9B4CC", no_aprobada: "#FF7A3D" };

export function PageHeader({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-4 mb-6">
      <div>
        <p className="eyebrow mb-1">{eyebrow}</p>
        <h1 className="font-display text-3xl font-bold">{title}</h1>
      </div>
      <div className="flex gap-2 no-print">{children}</div>
    </div>
  );
}

export function Card({ title, children, className = "", action }: { title?: string; children: ReactNode; className?: string; action?: ReactNode }) {
  return (
    <section className={`card p-5 ${className}`}>
      {title && (
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-display font-bold text-[15px]">{title}</h2>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function Kpi({ label, value, hint, highlight }: { label: string; value: ReactNode; hint?: string; highlight?: boolean }) {
  return (
    <div className={`rounded-xl p-4 border ${highlight ? "bg-accent-tint border-accent" : "bg-cream-card border-cream-line"}`}>
      <p className="text-xs text-ink-3">{label}</p>
      <p className="font-display text-3xl font-bold mt-1 tabular-nums">{value}</p>
      {hint && <p className="text-xs text-ink-3 mt-1">{hint}</p>}
    </div>
  );
}

export function RiskBadge({ risk }: { risk: string }) {
  const cls = risk === "alto" ? "bg-accent-tint text-accent-dark" : risk === "medio" ? "bg-[#FBF1D0] text-[#7A5C00]" : "bg-data-tint text-data";
  return <span className={`inline-block whitespace-nowrap shrink-0 rounded-full px-2 py-0.5 text-xs font-medium ${cls}`}>Riesgo {risk}</span>;
}

export function StatusBadge({ status }: { status: string }) {
  const cls = status === "aprobada" ? "bg-data-tint text-data" : status === "no_aprobada" ? "bg-accent-tint text-accent-dark" : "bg-white text-ink-2 border border-cream-line";
  return <span className={`inline-block rounded-full px-2 py-0.5 text-xs font-medium whitespace-nowrap ${cls}`}>{STATUS_LABEL[status] ?? status}</span>;
}

export function VerdictBadge({ verdict }: { verdict: string }) {
  return <span className="font-mono text-[11px] uppercase tracking-wide text-ink-3">{verdict}</span>;
}

export function Loading() {
  return <p className="text-ink-3 text-sm py-10 text-center">Cargando…</p>;
}

export function ErrorBox({ error }: { error: unknown }) {
  return <div className="card p-4 border-accent text-accent-dark text-sm">{String((error as Error)?.message ?? error)}</div>;
}

/** Hook simple para cargar datos de la API y recargarlos. */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    setError(null);
    fn().then((d) => alive && setData(d)).catch((e) => alive && setError(e));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, error, reload: () => setTick((t) => t + 1) };
}

export function Drawer({ open, onClose, children }: { open: boolean; onClose: () => void; children: ReactNode }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex justify-end no-print" onClick={onClose}>
      <div className="absolute inset-0 bg-navy/30" />
      <aside className="relative w-full max-w-xl h-full overflow-y-auto bg-cream p-6 shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <button className="btn-ghost absolute top-4 right-4" onClick={onClose}>Cerrar</button>
        {children}
      </aside>
    </div>
  );
}
