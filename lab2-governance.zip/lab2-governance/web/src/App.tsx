import { createContext, useContext, useEffect, useState } from "react";
import { BrowserRouter, Navigate, NavLink, Route, Routes } from "react-router-dom";
import { api, Org, setApiOrg, User } from "./api";
import Alerts from "./pages/Alerts";
import Areas from "./pages/Areas";
import AssessmentPage from "./pages/Assessment";
import Catalog from "./pages/Catalog";
import Devices from "./pages/Devices";
import Login from "./pages/Login";
import Operations from "./pages/Operations";
import Summary from "./pages/Summary";
import Systems from "./pages/Systems";
import Tools from "./pages/Tools";

type Session = { user: User; org: Org | null; orgs: Org[]; setOrg: (o: Org) => void; logout: () => void };
const Ctx = createContext<Session | null>(null);
export const useSession = () => useContext(Ctx)!;

const SEES_PEOPLE = ["admin_cognitive", "consultor", "cliente_admin_ti", "cliente_seguridad"];

const NAV = [
  { to: "/resumen", label: "Resumen", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/herramientas", label: "Herramientas de IA", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/dispositivos", label: "Dispositivos", show: (u: User) => SEES_PEOPLE.includes(u.role) },
  { to: "/areas", label: "Áreas", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/sistemas", label: "Sistemas de IA propios", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/alertas", label: "Alertas", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/assessment", label: "Readiness Assessment", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/catalogo", label: "Catálogo y Labs", show: (u: User) => u.is_cognitive, internal: true },
  { to: "/operacion", label: "Operación", show: (u: User) => ["admin_cognitive", "consultor"].includes(u.role), internal: true },
];

function Shell({ s }: { s: Session }) {
  const { user, org, orgs, setOrg, logout } = s;
  const home = user.role === "analista_catalogo" ? "/catalogo" : "/resumen";
  return (
    <div className="min-h-screen flex">
      <aside className="w-60 shrink-0 bg-navy text-cream flex flex-col no-print">
        <div className="px-5 pt-6 pb-5 border-b border-navy-500/50">
          <p className="font-mono text-[10px] tracking-[0.14em] text-accent">COGNITIVE · LAB 2</p>
          <p className="font-display font-bold text-lg leading-tight mt-1">Governance Platform</p>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {NAV.filter((n) => n.show(user)).map((n, i, arr) => (
            <div key={n.to}>
              {n.internal && !arr[i - 1]?.internal && <p className="px-3 pt-4 pb-1 font-mono text-[10px] tracking-widest text-data-soft">INTERNO COGNITIVE</p>}
              <NavLink to={n.to} className={({ isActive }) =>
                `block rounded-lg px-3 py-2 text-sm ${isActive ? "bg-cream text-navy font-semibold" : "text-cream/80 hover:bg-navy-700"}`}>
                {n.label}
              </NavLink>
            </div>
          ))}
        </nav>
        <div className="px-5 py-4 border-t border-navy-500/50 text-xs">
          <p className="font-semibold">{user.name}</p>
          <p className="text-data-soft">{user.role_label}</p>
          <button onClick={logout} className="mt-2 text-accent hover:underline">Cerrar sesión</button>
        </div>
      </aside>
      <div className="flex-1 min-w-0">
        <header className="h-14 border-b border-cream-line bg-cream-card/80 flex items-center justify-between px-8 no-print">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-ink-3">Organización:</span>
            {user.is_cognitive && orgs.length > 0 ? (
              <select className="input w-64 py-1.5" value={org?.id ?? ""} onChange={(e) => setOrg(orgs.find((o) => o.id === Number(e.target.value))!)}>
                {orgs.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            ) : <span className="font-semibold">{org?.name ?? "Catálogo global"}</span>}
          </div>
          <span className="font-mono text-[11px] text-ink-3">VERSIÓN PRELIMINAR · DATOS FICTICIOS</span>
        </header>
        <main className="p-8 max-w-[1400px]" key={org?.id ?? 0}>
          <Routes>
            <Route path="/resumen" element={<Summary />} />
            <Route path="/herramientas" element={<Tools />} />
            <Route path="/dispositivos" element={<Devices />} />
            <Route path="/areas" element={<Areas />} />
            <Route path="/sistemas" element={<Systems />} />
            <Route path="/alertas" element={<Alerts />} />
            <Route path="/assessment" element={<AssessmentPage />} />
            <Route path="/catalogo" element={<Catalog />} />
            <Route path="/operacion" element={<Operations />} />
            <Route path="*" element={<Navigate to={home} replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [org, setOrgState] = useState<Org | null>(null);

  const setOrg = (o: Org | null) => {
    setApiOrg(o && user?.is_cognitive ? o.id : null);
    setOrgState(o);
  };

  useEffect(() => { api<User>("/api/auth/me").then(setUser).catch(() => setUser(null)); }, []);

  useEffect(() => {
    if (!user) return;
    api<Org[]>("/api/orgs").then((list) => {
      setOrgs(list);
      const first = list.find((o) => o.kind === "cliente") ?? list[0] ?? null;
      setApiOrg(first && user.is_cognitive ? first.id : null);
      setOrgState(first);
    });
  }, [user]);

  if (user === undefined) return null;
  if (!user) return <Login onLogin={setUser} />;
  if (user.role !== "analista_catalogo" && !org) return null;

  const logout = () => api("/api/auth/logout", { method: "POST" }).finally(() => { setApiOrg(null); setUser(null); });
  const s: Session = { user, org, orgs, setOrg, logout };
  return (
    <Ctx.Provider value={s}>
      <BrowserRouter>
        <Shell s={s} />
      </BrowserRouter>
    </Ctx.Provider>
  );
}
