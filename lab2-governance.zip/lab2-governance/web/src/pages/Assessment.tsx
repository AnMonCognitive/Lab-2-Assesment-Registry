import { useState } from "react";
import ReactMarkdown from "react-markdown";
import { PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer } from "recharts";
import { api, fmtDate } from "../api";
import { Card, ErrorBox, Loading, PageHeader, useLoad } from "../components/ui";

export default function AssessmentPage() {
  const { data, error, reload } = useLoad<any>(() => api("/api/assessment"), []);
  const report = useLoad<any>(() => api("/api/assessment/report").catch(() => null), [data?.report_generated_at]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<"diagnostico" | "reporte">("diagnostico");

  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;

  const radar = data.dimensions.map((d: any) => ({ dim: d.dimension, score: d.promedio ?? 0 }));
  const answered = data.dimensions.filter((d: any) => d.promedio != null).length;
  const generate = async () => {
    setBusy(true); setErr("");
    try { await api("/api/assessment/report", { method: "POST" }); reload(); setTab("reporte"); }
    catch (e: any) { setErr(e.message); }
    finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader eyebrow="Readiness Assessment" title="¿Qué tan lista está la empresa para la IA?">
        {data.can_edit && <button className="btn-accent" disabled={busy || answered === 0} onClick={generate}>{busy ? "Redactando con IA…" : "Generar reporte con IA"}</button>}
        {report.data && tab === "reporte" && <button className="btn-ghost" onClick={() => window.print()}>Imprimir / PDF</button>}
      </PageHeader>
      {err && <p className="text-accent-dark text-sm mb-4">{err}</p>}

      <div className="flex gap-2 mb-5 no-print">
        <button className={tab === "diagnostico" ? "btn-primary" : "btn-ghost"} onClick={() => setTab("diagnostico")}>Diagnóstico</button>
        <button className={tab === "reporte" ? "btn-primary" : "btn-ghost"} onClick={() => setTab("reporte")} disabled={!report.data}>Reporte</button>
      </div>

      {tab === "diagnostico" && (
        <>
          <div className="grid lg:grid-cols-3 gap-5 mb-5">
            <Card title="Madurez por dimensión" className="lg:col-span-2">
              {answered === 0 ? <p className="text-sm text-ink-3 py-16 text-center">Aún no hay respuestas. El consultor de Cognitive llena el cuestionario con el cliente.</p> : (
                <div className="h-80">
                  <ResponsiveContainer>
                    <RadarChart data={radar} outerRadius="75%">
                      <PolarGrid stroke="#E0DCD0" />
                      <PolarAngleAxis dataKey="dim" tick={{ fontSize: 12, fill: "#4A5263" }} />
                      <PolarRadiusAxis domain={[0, 5]} tickCount={6} tick={false} axisLine={false} />
                      <Radar dataKey="score" stroke="#1F5FA8" fill="#1F5FA8" fillOpacity={0.25} strokeWidth={2} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>
            <Card title="Puntaje">
              <p className="font-display text-6xl font-bold">{data.maturity != null ? data.maturity.toFixed(1) : "—"}<span className="text-xl text-ink-3"> / 5</span></p>
              <p className="text-sm text-ink-3 mt-1">{answered} de 9 dimensiones respondidas</p>
              <ul className="mt-4 space-y-1.5 text-sm">
                {[...data.dimensions].filter((d: any) => d.promedio != null).sort((a: any, b: any) => a.promedio - b.promedio).map((d: any, i: number) => (
                  <li key={d.dimension} className="flex justify-between">
                    <span className={i < 3 ? "text-accent-dark font-semibold" : ""}>{d.dimension}</span>
                    <span className="tabular-nums">{d.promedio.toFixed(1)}</span>
                  </li>
                ))}
              </ul>
              <p className="text-xs text-ink-3 mt-3">En naranja, las 3 brechas prioritarias.</p>
            </Card>
          </div>
          <div className="space-y-4">
            {data.questions.map((g: any) => (
              <Card key={g.dimension} title={g.dimension}>
                <div className="space-y-3">
                  {g.items.map((q: any) => <Question key={q.id} q={q} editable={data.can_edit} onSaved={reload} />)}
                </div>
              </Card>
            ))}
          </div>
        </>
      )}

      {tab === "reporte" && report.data && (
        <div className="card p-8 max-w-3xl">
          <p className="text-xs text-ink-3 mb-4 no-print">
            Generado {fmtDate(report.data.generated_at)} · modo {report.data.mode === "bedrock" ? "Claude en Amazon Bedrock" : "simulado (sin Bedrock)"} ·
            borrador para revisión del consultor
          </p>
          <div className="markdown"><ReactMarkdown>{report.data.markdown}</ReactMarkdown></div>
        </div>
      )}
    </>
  );
}

function Question({ q, editable, onSaved }: { q: any; editable: boolean; onSaved: () => void }) {
  const [score, setScore] = useState<number | null>(q.score);
  const [evidence, setEvidence] = useState(q.evidence ?? "");
  const dirty = score !== q.score || evidence !== (q.evidence ?? "");
  const save = () => api(`/api/assessment/answers/${q.id}`, { method: "PUT", json: { score, evidence: evidence || null } }).then(onSaved);
  return (
    <div className="grid md:grid-cols-[1fr_220px] gap-3 items-start border-b border-cream-line/70 pb-3 last:border-0">
      <div>
        <p className="text-sm font-medium">{q.question}</p>
        {editable
          ? <textarea className="input mt-2 text-xs" rows={2} placeholder="Evidencia (qué se observó)" value={evidence} onChange={(e) => setEvidence(e.target.value)} />
          : <p className="text-xs text-ink-3 mt-1">{q.evidence ?? "Sin evidencia registrada"}</p>}
      </div>
      <div className="flex items-center gap-1">
        {[0, 1, 2, 3, 4, 5].map((n) => (
          <button key={n} disabled={!editable} onClick={() => setScore(n)}
            className={`h-8 w-8 rounded-md text-sm tabular-nums border ${score === n ? "bg-navy text-cream border-navy" : "bg-white border-cream-line"} ${editable ? "hover:border-navy" : "cursor-default"}`}>{n}</button>
        ))}
        {editable && dirty && <button className="btn-primary ml-2 px-2 py-1 text-xs" onClick={save}>Guardar</button>}
      </div>
    </div>
  );
}
