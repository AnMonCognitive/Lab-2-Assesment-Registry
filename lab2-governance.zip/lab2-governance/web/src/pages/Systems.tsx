import { useState } from "react";
import { api } from "../api";
import { useSession } from "../App";
import { Drawer, ErrorBox, Loading, PageHeader, RiskBadge, useLoad } from "../components/ui";

const CAN_EDIT = ["admin_cognitive", "consultor", "cliente_admin_ti", "cliente_seguridad"];
const EMPTY = { name: "", owner: "", area: "", purpose: "", model: "", provider: "", platform: "", data_sources: "", permissions: "",
  monthly_cost_usd: null as number | null, risk: "medio", failure_impact: "", human_approval: false, status: "produccion" };
const FIELDS: [keyof typeof EMPTY, string][] = [
  ["name", "Nombre"], ["owner", "Dueño (persona y área)"], ["area", "Área"], ["purpose", "Para qué sirve"], ["model", "Modelo"],
  ["provider", "Proveedor"], ["platform", "Plataforma (n8n, Power Automate, código…)"], ["data_sources", "¿Qué datos consulta?"],
  ["permissions", "¿Qué permisos tiene?"], ["failure_impact", "¿Qué pasa si falla?"],
];
const STATUS: Record<string, string> = { piloto: "Piloto", produccion: "Producción", retirado: "Retirado" };

export default function Systems() {
  const { user } = useSession();
  const { data, error, reload } = useLoad<any[]>(() => api("/api/systems"), []);
  const [edit, setEdit] = useState<any | null>(null);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const canEdit = CAN_EDIT.includes(user.role);
  const total = data.reduce((s, x) => s + (x.monthly_cost_usd ?? 0), 0);

  return (
    <>
      <PageHeader eyebrow="Registry" title="Sistemas de IA propios">
        {canEdit && <button className="btn-accent" onClick={() => setEdit({ ...EMPTY })}>Registrar sistema</button>}
      </PageHeader>
      <p className="text-sm text-ink-3 -mt-3 mb-5">
        Agentes y automatizaciones de la empresa que ningún sensor ve. {data.length} sistemas · {Math.round(total)} USD al mes conocidos ·{" "}
        {data.filter((s) => s.missing.length).length} con ficha incompleta. Aquí se conectará el Agent Monitor (fase 2).
      </p>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {data.map((s) => (
          <div key={s.id} className={`card p-5 flex flex-col gap-2 ${s.missing.includes("dueño") ? "border-accent" : ""}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-display font-bold text-lg leading-tight">{s.name}</p>
                <p className="text-xs text-ink-3">{s.area ?? "Sin área"} · {STATUS[s.status] ?? s.status}</p>
              </div>
              <RiskBadge risk={s.risk} />
            </div>
            <p className="text-sm text-ink-2">{s.purpose}</p>
            <dl className="text-xs grid grid-cols-[110px_1fr] gap-y-1 mt-1">
              <dt className="text-ink-3">Dueño</dt><dd className={s.owner ? "" : "text-accent-dark font-semibold"}>{s.owner ?? "Sin dueño"}</dd>
              <dt className="text-ink-3">Modelo</dt><dd>{[s.model, s.provider].filter(Boolean).join(" · ") || "—"}</dd>
              <dt className="text-ink-3">Datos</dt><dd>{s.data_sources ?? "—"}</dd>
              <dt className="text-ink-3">Permisos</dt><dd>{s.permissions ?? "—"}</dd>
              <dt className="text-ink-3">Si falla</dt><dd>{s.failure_impact ?? "—"}</dd>
              <dt className="text-ink-3">Costo mensual</dt><dd>{s.monthly_cost_usd != null ? `${s.monthly_cost_usd} USD` : "—"}</dd>
              <dt className="text-ink-3">Aprobación humana</dt><dd>{s.human_approval ? "Sí" : "No"}</dd>
            </dl>
            {s.missing.length > 0 && <p className="text-xs text-accent-dark mt-1">Falta: {s.missing.join(", ")}</p>}
            {canEdit && <button className="btn-ghost self-start mt-auto" onClick={() => setEdit(s)}>Editar ficha</button>}
          </div>
        ))}
      </div>
      <Drawer open={!!edit} onClose={() => setEdit(null)}>
        {edit && <SystemForm initial={edit} onSaved={() => { setEdit(null); reload(); }} />}
      </Drawer>
    </>
  );
}

function SystemForm({ initial, onSaved }: { initial: any; onSaved: () => void }) {
  const [f, setF] = useState<any>({ ...EMPTY, ...initial });
  const [err, setErr] = useState("");
  const set = (k: string, v: unknown) => setF((x: any) => ({ ...x, [k]: v }));
  const save = async () => {
    const body: any = {};
    for (const k of Object.keys(EMPTY)) body[k] = f[k] === "" ? null : f[k];
    body.name = f.name; body.risk = f.risk; body.status = f.status; body.human_approval = !!f.human_approval;
    try {
      await api(initial.id ? `/api/systems/${initial.id}` : "/api/systems", { method: initial.id ? "PUT" : "POST", json: body });
      onSaved();
    } catch (e: any) { setErr(e.message); }
  };
  return (
    <div className="space-y-3">
      <p className="eyebrow">Ficha del sistema</p>
      <h2 className="font-display text-2xl font-bold">{initial.id ? f.name : "Registrar sistema de IA"}</h2>
      {FIELDS.map(([k, label]) => (
        <label key={k} className="block text-sm">
          <span className="text-ink-3">{label}</span>
          <input className="input mt-1" value={f[k] ?? ""} onChange={(e) => set(k, e.target.value)} />
        </label>
      ))}
      <div className="grid grid-cols-3 gap-3">
        <label className="text-sm"><span className="text-ink-3">Costo mensual (USD)</span>
          <input type="number" className="input mt-1" value={f.monthly_cost_usd ?? ""} onChange={(e) => set("monthly_cost_usd", e.target.value === "" ? null : Number(e.target.value))} /></label>
        <label className="text-sm"><span className="text-ink-3">Riesgo</span>
          <select className="input mt-1" value={f.risk} onChange={(e) => set("risk", e.target.value)}>{["bajo", "medio", "alto"].map((r) => <option key={r}>{r}</option>)}</select></label>
        <label className="text-sm"><span className="text-ink-3">Estado</span>
          <select className="input mt-1" value={f.status} onChange={(e) => set("status", e.target.value)}>{Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
      </div>
      <label className="text-sm flex items-center gap-2"><input type="checkbox" checked={!!f.human_approval} onChange={(e) => set("human_approval", e.target.checked)} /> Requiere aprobación humana antes de actuar</label>
      {err && <p className="text-accent-dark text-sm">{err}</p>}
      <button className="btn-primary" disabled={!f.name} onClick={save}>Guardar</button>
    </div>
  );
}
