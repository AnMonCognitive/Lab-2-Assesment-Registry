import { useEffect, useState } from "react";
import { api, User } from "../api";

export default function Login({ onLogin }: { onLogin: (u: User) => void }) {
  const [users, setUsers] = useState<User[]>([]);
  const [error, setError] = useState("");

  useEffect(() => { api<User[]>("/api/auth/dev-users").then(setUsers).catch(() => setError("No se pudo conectar con la API")); }, []);

  const login = (email: string) =>
    api<User>("/api/auth/login", { method: "POST", json: { email } }).then(onLogin).catch((e) => setError(e.message));

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <div className="bg-navy text-cream p-12 flex flex-col justify-between relative overflow-hidden">
        <div>
          <p className="font-mono text-xs tracking-[0.14em] text-accent">COGNITIVE AI LAB · LAB 2</p>
          <h1 className="font-display text-5xl font-bold mt-6 leading-tight">Readiness Assessment<br />+ Registry</h1>
          <p className="text-data-soft text-lg mt-4 max-w-md">Qué IA se usa en la empresa, quién la usa, con qué riesgo, y qué tan lista está la organización.</p>
        </div>
        <div className="absolute right-16 bottom-16 w-16 h-16 rounded-full bg-accent" />
        <p className="text-xs text-data-soft">Versión preliminar · todos los datos son ficticios</p>
      </div>
      <div className="p-12 flex flex-col justify-center max-w-xl">
        <p className="eyebrow">Iniciar sesión</p>
        <h2 className="font-display text-2xl font-bold mt-1">Elige un usuario de prueba</h2>
        <p className="text-sm text-ink-3 mt-2 mb-6">
          En producción el acceso es con tu cuenta de Microsoft (Entra ID + MFA). Aquí cada usuario representa un rol,
          para mostrar qué ve cada quién.
        </p>
        <button disabled className="btn-ghost justify-center mb-6 opacity-60 cursor-not-allowed">Entrar con Microsoft (pendiente)</button>
        <div className="space-y-2">
          {users.map((u) => (
            <button key={u.id} onClick={() => login(u.email)}
              className="w-full text-left card px-4 py-3 hover:border-navy transition flex items-center justify-between">
              <span>
                <span className="font-semibold block">{u.role_label}</span>
                <span className="text-xs text-ink-3">{u.email} · {u.org_name}</span>
              </span>
              <span className="text-accent-dark text-sm">Entrar →</span>
            </button>
          ))}
        </div>
        {error && <p className="text-accent-dark text-sm mt-4">{error}</p>}
      </div>
    </div>
  );
}
