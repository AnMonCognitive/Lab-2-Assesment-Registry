import { ReactNode, useMemo, useState } from "react";
import { api, fmtDate } from "../api";
import { Drawer, ErrorBox, Loading, PageHeader, RiskBadge, StatusBadge, VerdictBadge, useLoad } from "../components/ui";

const FILTERS = [["todas", "Todas"], ["no_aprobada", "No aprobadas"], ["en_revision", "En revisión"], ["aprobada", "Aprobadas"]];

export default function Tools() {
  const { data, error, reload } = useLoad<any[]>(() => api("/api/tools"), []);
  const [filter, setFilter] = useState("todas");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<number | null>(null);

  const rows = useMemo(() => (data ?? []).filter((r) =>
    (filter === "todas" || r.status === filter) && `${r.name} ${r.vendor} ${r.category}`.toLowerCase().includes(q.toLowerCase())), [data, filter, q]);

  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  return (
    <>
      <PageHeader eyebrow="Registry · Inventario" title="Herramientas de IA detectadas" />
      <div className="flex flex-wrap items-center gap-2 mb-4">
        {FILTERS.map(([k, label]) => (
          <button key={k} onClick={() => setFilter(k)} className={k === filter ? "btn-primary" : "btn-ghost"}>
            {label} <span className="opacity-60">{k === "todas" ? data.length : data.filter((r) => r.status === k).length}</span>
          </button>
        ))}
        <input className="input max-w-xs ml-auto" placeholder="Buscar herramienta, proveedor o categoría" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="card overflow-x-auto">
        <table className="tbl">
          <thead><tr><th>Herramienta</th><th>Categoría</th><th>Estado</th><th>Riesgo</th><th>Veredicto Labs</th><th className="text-right">Personas</th><th className="text-right">Equipos</th><th>Áreas</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="row" onClick={() => setOpen(r.id)}>
                <td><span className="font-medium">{r.name}</span><span className="block text-xs text-ink-3">{r.vendor}</span></td>
                <td className="text-ink-2">{r.category}</td>
                <td><StatusBadge status={r.status} /></td>
                <td><RiskBadge risk={r.risk} /></td>
                <td><VerdictBadge verdict={r.verdict} /></td>
                <td className="text-right tabular-nums">{r.people}</td>
                <td className="text-right tabular-nums">{r.devices}</td>
                <td className="text-xs text-ink-3 max-w-[220px]">{r.areas.join(", ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Drawer open={open != null} onClose={() => setOpen(null)}>
        {open != null && <ToolDetail id={open} onChanged={reload} />}
      </Drawer>
    </>
  );
}

function ToolDetail({ id, onChanged }: { id: number; onChanged: () => void }) {
  const { data, error, reload } = useLoad<any>(() => api(`/api/tools/${id}`), [id]);
  const [busy, setBusy] = useState(false);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const t = data.tool, o = data.org;

  const setStatus = async (status: string) => {
    setBusy(true);
    try { await api(`/api/tools/${id}/status`, { method: "PATCH", json: { status } }); reload(); onChanged(); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-5">
      <div>
        <p className="eyebrow">{t.category}</p>
        <h2 className="font-display text-2xl font-bold">{t.name}</h2>
        <p className="text-sm text-ink-3">{t.vendor}</p>
        <div className="flex gap-2 mt-3">{o && <StatusBadge status={o.status} />}<RiskBadge risk={t.risk} /></div>
      </div>

      {data.can_decide && (
        <div className="card p-4">
          <p className="text-sm font-semibold mb-2">Decisión de la empresa</p>
          <div className="flex gap-2">
            {[["aprobada", "Aprobar"], ["en_revision", "En revisión"], ["no_aprobada", "No aprobar"]].map(([s, label]) => (
              <button key={s} disabled={busy || o?.status === s} onClick={() => setStatus(s)} className={o?.status === s ? "btn-primary" : "btn-ghost"}>{label}</button>
            ))}
          </div>
          <p className="text-xs text-ink-3 mt-2">La plataforma no bloquea: la decisión se aplica con las herramientas de TI de la empresa.</p>
        </div>
      )}

      <div className="card p-4 text-sm space-y-2">
        <p className="font-semibold">Ficha de Cognitive Labs {t.reviewed ? "" : <span className="font-normal text-xs text-accent-dark">· preliminar, sin revisar</span>}</p>
        <Row k="Veredicto" v={<VerdictBadge verdict={t.verdict} />} />
        <Row k="Plan empresarial disponible" v={t.enterprise_plan ? "Sí" : "No o no confirmado"} />
        <Row k="¿Entrena con datos del cliente?" v={t.trains_on_data} />
        <Row k="Alternativa sugerida" v={t.alternative ?? "—"} />
        {t.notes && <p className="text-ink-2 pt-1">{t.notes}</p>}
      </div>

      {o && (
        <div className="card p-4 text-sm">
          <p className="font-semibold mb-2">Uso en la empresa</p>
          <p className="text-ink-2">{o.people} personas · {o.devices} equipos · desde {fmtDate(o.first_seen)}</p>
          <table className="tbl mt-3">
            <thead><tr>{data.sees_people && <th>Persona</th>}{data.sees_people && <th>Equipo</th>}<th>Área</th><th>Firma detectada</th></tr></thead>
            <tbody>
              {data.usage.map((u: any, i: number) => (
                <tr key={i}>
                  {data.sees_people && <td>{u.person}</td>}
                  {data.sees_people && <td className="font-mono text-xs whitespace-nowrap">{u.hostname}</td>}
                  <td>{u.area}</td>
                  <td className="font-mono text-xs text-ink-3">{u.signature}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!data.sees_people && <p className="text-xs text-ink-3 mt-2">Tu rol ve el uso agregado por área, sin nombres.</p>}
        </div>
      )}
    </div>
  );
}

const Row = ({ k, v }: { k: string; v: ReactNode }) => (
  <div className="flex justify-between gap-4"><span className="text-ink-3">{k}</span><span className="text-right">{v}</span></div>
);
