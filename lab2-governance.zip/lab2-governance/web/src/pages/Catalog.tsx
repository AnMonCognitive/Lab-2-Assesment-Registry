import { useMemo, useState } from "react";
import { api } from "../api";
import { useSession } from "../App";
import { Card, ErrorBox, Loading, PageHeader, RiskBadge, VerdictBadge, useLoad } from "../components/ui";

export default function Catalog() {
  const { user } = useSession();
  const catalog = useLoad<any[]>(() => api("/api/catalog"), []);
  const unknowns = useLoad<any[]>(() => api("/api/catalog/unknowns"), []);
  const [busy, setBusy] = useState<number | null>(null);
  const [err, setErr] = useState("");
  const [q, setQ] = useState("");
  const canPublish = ["admin_cognitive", "analista_catalogo"].includes(user.role);

  const rows = useMemo(() => (catalog.data ?? []).filter((t) => `${t.name} ${t.vendor} ${t.category}`.toLowerCase().includes(q.toLowerCase())), [catalog.data, q]);

  if (catalog.error) return <ErrorBox error={catalog.error} />;
  if (!catalog.data || !unknowns.data) return <Loading />;

  const run = async (id: number, fn: () => Promise<unknown>) => {
    setBusy(id); setErr("");
    try { await fn(); unknowns.reload(); catalog.reload(); } catch (e: any) { setErr(e.message); } finally { setBusy(null); }
  };

  return (
    <>
      <PageHeader eyebrow="Interno Cognitive · Lab 5 Tech Evaluation" title="Catálogo de IA y desconocidos" />
      <Card title="Cola de desconocidos" className="mb-5">
        <p className="text-sm text-ink-3 mb-3">Firmas que el catálogo no reconoce. Claude sugiere categoría y riesgo; un analista confirma y la ficha queda para todos los clientes.</p>
        {err && <p className="text-accent-dark text-sm mb-2">{err}</p>}
        <table className="tbl">
          <thead><tr><th>Firma</th><th>Tipo</th><th>Equipos</th>{user.role !== "analista_catalogo" && <th>Cliente</th>}<th>Sugerencia de la IA</th><th></th></tr></thead>
          <tbody>
            {unknowns.data.map((u) => (
              <tr key={u.id} className={u.status === "confirmado" || u.status === "descartado" ? "opacity-50" : ""}>
                <td><span className="font-medium">{u.name}</span>{u.identifier && <span className="block font-mono text-xs text-ink-3">{u.identifier}</span>}</td>
                <td className="text-ink-2">{u.kind}</td>
                <td className="tabular-nums">{u.devices_count}</td>
                {user.role !== "analista_catalogo" && <td className="text-ink-2">{u.org}</td>}
                <td className="text-xs max-w-sm">
                  {u.suggestion ? (
                    <>
                      <span className="font-semibold">{u.suggestion.is_ai_tool ? u.suggestion.category : "No parece IA"}</span>
                      {u.suggestion.is_ai_tool && <span className="ml-2"><RiskBadge risk={u.suggestion.risk} /></span>}
                      <span className="block text-ink-3 mt-1">{u.suggestion.rationale}</span>
                      <span className="block text-ink-3">Confianza {Math.round(u.suggestion.confidence * 100)}% · {u.suggestion.mode}</span>
                    </>
                  ) : <span className="text-ink-3">—</span>}
                </td>
                <td className="whitespace-nowrap text-right">
                  {u.status === "pendiente" && <button className="btn-primary" disabled={busy === u.id} onClick={() => run(u.id, () => api(`/api/catalog/unknowns/${u.id}/classify`, { method: "POST" }))}>{busy === u.id ? "Clasificando…" : "Clasificar con IA"}</button>}
                  {u.status === "sugerido" && canPublish && (
                    <span className="flex gap-2 justify-end">
                      <button className="btn-accent" onClick={() => run(u.id, () => api(`/api/catalog/unknowns/${u.id}/confirm`, { method: "POST", json: { action: "agregar" } }))}>Publicar ficha</button>
                      <button className="btn-ghost" onClick={() => run(u.id, () => api(`/api/catalog/unknowns/${u.id}/confirm`, { method: "POST", json: { action: "descartar" } }))}>Descartar</button>
                    </span>
                  )}
                  {(u.status === "confirmado" || u.status === "descartado") && <span className="text-xs text-ink-3">{u.status}</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <Card title={`Catálogo (${catalog.data.length} herramientas)`} action={<input className="input max-w-xs py-1.5" placeholder="Buscar" value={q} onChange={(e) => setQ(e.target.value)} />}>
        <p className="text-xs text-accent-dark mb-3">Valores preliminares de Cognitive Labs: revisar cada ficha contra los términos vigentes del proveedor antes de usarla con un cliente.</p>
        <table className="tbl">
          <thead><tr><th>Herramienta</th><th>Categoría</th><th>Riesgo base</th><th>Veredicto</th><th>Plan empresarial</th><th>Alternativa</th><th>Firmas</th></tr></thead>
          <tbody>
            {rows.map((t) => (
              <tr key={t.id}>
                <td><span className="font-medium">{t.name}</span><span className="block text-xs text-ink-3">{t.vendor}{t.reviewed ? " · revisada" : ""}</span></td>
                <td className="text-ink-2">{t.category}</td>
                <td><RiskBadge risk={t.risk} /></td>
                <td><VerdictBadge verdict={t.verdict} /></td>
                <td>{t.enterprise_plan ? "Sí" : "—"}</td>
                <td className="text-xs text-ink-2 max-w-[220px]">{t.alternative ?? "—"}</td>
                <td className="tabular-nums text-ink-3">{t.signature_count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </>
  );
}
