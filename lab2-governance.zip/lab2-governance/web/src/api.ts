// Cliente mínimo de la API. La sesión viaja en una cookie segura; el navegador nunca maneja tokens.

export type User = {
  id: number; email: string; name: string; role: string; role_label: string;
  org_id: number | null; org_name: string; is_cognitive: boolean;
};
export type Org = { id: number; name: string; kind: string };

let currentOrg: number | null = null;
export const setApiOrg = (id: number | null) => { currentOrg = id; };

function withOrg(path: string) {
  if (currentOrg == null) return path;
  return path + (path.includes("?") ? "&" : "?") + `org=${currentOrg}`;
}

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export async function api<T = any>(path: string, opts: RequestInit & { json?: unknown } = {}): Promise<T> {
  const { json, ...rest } = opts;
  const res = await fetch(withOrg(path), {
    credentials: "include",
    ...rest,
    headers: { ...(json !== undefined ? { "Content-Type": "application/json" } : {}), ...(rest.headers || {}) },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  });
  if (!res.ok) {
    let msg = res.statusText;
    try { msg = (await res.json()).detail ?? msg; } catch { /* sin cuerpo */ }
    throw new ApiError(res.status, msg);
  }
  return res.json();
}

export const fmtDate = (iso?: string | null) =>
  iso ? new Date(iso + (iso.endsWith("Z") ? "" : "Z")).toLocaleString("es-MX", { dateStyle: "medium", timeStyle: "short" }) : "—";
export const fmtDay = (iso: string) =>
  new Date(iso + "T12:00:00").toLocaleDateString("es-MX", { day: "numeric", month: "short" });
