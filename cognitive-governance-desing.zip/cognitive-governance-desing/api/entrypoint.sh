#!/bin/sh
# Arranque del contenedor de la API.
# En modo real, el esquema lo gobierna Alembic: aplicamos las migraciones pendientes ANTES de arrancar.
# En modo demo, el esquema se crea solo (create_all) y se carga la semilla; no se tocan migraciones.
set -e

if [ "${DATA_MODE:-demo}" = "real" ]; then
  echo "[entrypoint] Modo real: aplicando migraciones (alembic upgrade head)..."
  alembic upgrade head
  echo "[entrypoint] Migraciones al día."
fi

exec "$@"
