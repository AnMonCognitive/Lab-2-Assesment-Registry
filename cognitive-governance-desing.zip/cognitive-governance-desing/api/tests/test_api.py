"""Pruebas de humo de la API. Requieren PostgreSQL (DATABASE_URL). Ejecutar desde api/:  pytest -q"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
os.environ.setdefault("BEDROCK_MODE", "simulado")

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from seed.generate_demo import reset_and_seed  # noqa: E402


@pytest.fixture(scope="module")
def client():
    reset_and_seed()
    with TestClient(app) as c:
        yield c


def login(c, email):
    r = c.post("/api/auth/login", json={"email": email})
    assert r.status_code == 200, r.text
    return r.json()


def test_requires_login(client):
    client.post("/api/auth/logout")
    assert client.get("/api/summary").status_code == 401


def test_summary_for_security(client):
    login(client, "seguridad@empresademo.mx")
    s = client.get("/api/summary").json()
    assert s["kpis"]["devices"] == 120
    assert s["kpis"]["tools_detected"] > 10
    assert len(s["trend"]) == 12
    assert s["kpis"]["maturity"] is not None


def test_direction_sees_no_people(client):
    login(client, "direccion@empresademo.mx")
    assert client.get("/api/devices").status_code == 403
    tools = client.get("/api/tools").json()
    detail = client.get(f"/api/tools/{tools[0]['id']}").json()
    assert all("person" not in u and "hostname" not in u for u in detail["usage"])


def test_client_cannot_switch_org(client):
    me = login(client, "seguridad@empresademo.mx")
    other = client.get("/api/summary", params={"org": 999}).json()
    # Un usuario de cliente siempre queda en su organización, ignore el parámetro.
    assert other["kpis"]["devices"] == 120
    assert me["org_name"] == "Empresa Demo"


def test_change_tool_status_and_audit(client):
    login(client, "seguridad@empresademo.mx")
    tool = client.get("/api/tools").json()[0]
    assert client.patch(f"/api/tools/{tool['id']}/status", json={"status": "aprobada"}).status_code == 200
    login(client, "admin@cognitive.demo")
    log = client.get("/api/admin/audit").json()
    assert any(r["action"] == "cambiar_estado_herramienta" for r in log)


def test_direction_cannot_change_status(client):
    login(client, "direccion@empresademo.mx")
    tool = client.get("/api/tools").json()[0]
    assert client.patch(f"/api/tools/{tool['id']}/status", json={"status": "aprobada"}).status_code == 403


def test_classify_and_confirm_unknown(client):
    login(client, "analista@cognitive.demo")
    unknowns = client.get("/api/catalog/unknowns").json()
    assert unknowns and unknowns[0]["org"] is None  # el analista no ve la organización
    uid = next(u["id"] for u in unknowns if u["name"] == "Notta")
    sug = client.post(f"/api/catalog/unknowns/{uid}/classify").json()
    assert sug["category"] == "notas de reuniones"
    assert client.post(f"/api/catalog/unknowns/{uid}/confirm", json={"action": "agregar"}).json()["ok"]
    assert any(t["name"] == "Notta" for t in client.get("/api/catalog").json())


def test_assessment_report_simulated(client):
    login(client, "consultor@cognitive.demo")
    orgs = client.get("/api/orgs").json()
    empresa = next(o["id"] for o in orgs if o["name"] == "Empresa Demo")
    a = client.get("/api/assessment", params={"org": empresa}).json()
    assert len(a["dimensions"]) == 9
    r = client.post("/api/assessment/report", params={"org": empresa})
    assert r.json()["mode"] == "simulado"
    md = client.get("/api/assessment/report", params={"org": empresa}).json()["markdown"]
    assert "Empresa Demo" in md and "Cliente (alias)" not in md
    usage = client.get("/api/admin/llm-usage").json()
    assert usage["calls"]


def test_systems_crud(client):
    login(client, "ti@empresademo.mx")
    r = client.post("/api/systems", json={"name": "Agente de prueba", "risk": "bajo"})
    assert r.status_code == 200 and "dueño" in r.json()["missing"]


def test_matcher():
    from app.models import AITool
    from app.services.catalog import match_signature
    tools = [AITool(slug="gh", name="GitHub Copilot", signatures={"vscode": ["github.copilot"]}),
             AITool(slug="ollama", name="Ollama", signatures={"apps": ["Ollama"], "processes": ["ollama"]})]
    assert match_signature(tools, "vscode", "GitHub Copilot", "github.copilot").slug == "gh"
    assert match_signature(tools, "app", "Ollama 0.5.1").slug == "ollama"
    assert match_signature(tools, "app", "Microsoft Excel") is None


# ---------------------------------------------------------------- agente real

def _cognitive_org(client):
    return next(o["id"] for o in client.get("/api/orgs").json() if o["name"] == "Cognitive (interno)")


def _report(items, **extra):
    return {"hostname": "COG-PRUEBA-01", "os": "Windows 11 Pro", "user": "COGNITIVE\ana", "person_name": "Ana Prueba",
            "area": "Desarrollo & Automatización", "agent_version": "0.1.0", "items": items, **extra}


def test_agent_report_flow(client):
    login(client, "admin@cognitive.demo")
    org = _cognitive_org(client)
    token = client.post("/api/agent/tokens", params={"org": org}, json={"label": "Equipos Cognitive"}).json()["token"]
    auth = {"Authorization": f"Bearer {token}"}
    items = [{"kind": "vscode", "name": "GitHub Copilot", "identifier": "github.copilot"},
             {"kind": "app", "name": "Ollama version 0.5.1"},
             {"kind": "extension", "name": "Super AI Summarizer", "identifier": "abcdef"},
             {"kind": "app", "name": "Microsoft Excel"}]

    assert client.post("/api/agent/report", json=_report(items)).status_code == 401
    r = client.post("/api/agent/report", json=_report(items), headers=auth).json()
    assert r["herramientas_ia"] == 2 and r["desconocidos"] == 1
    client.post("/api/agent/report", json=_report(items), headers=auth)  # el mismo reporte otra vez

    devs = {d["hostname"]: d for d in client.get("/api/devices", params={"org": org}).json()}
    d = devs["COG-PRUEBA-01"]
    assert d["agent_status"] == "activo" and d["person"] == "Ana Prueba" and d["area"] == "Desarrollo & Automatización"
    assert sorted(d["tools"]) == ["GitHub Copilot", "Ollama"]
    unk = next(u for u in client.get("/api/catalog/unknowns").json() if u["name"] == "Super AI Summarizer")
    assert unk["devices_count"] == 1  # no crece con cada reporte
    alerts = client.get("/api/alerts", params={"org": org}).json()
    assert sum(1 for a in alerts if "Ollama" in a["title"]) == 1  # riesgo alto: una sola alerta

    # Se desinstala Ollama: la detección se retira.
    client.post("/api/agent/report", json=_report(items[:1]), headers=auth)
    d = next(x for x in client.get("/api/devices", params={"org": org}).json() if x["hostname"] == "COG-PRUEBA-01")
    assert d["tools"] == ["GitHub Copilot"]
    s = client.get("/api/summary", params={"org": org}).json()
    assert s["kpis"]["tools_detected"] == 1 and s["trend"]

    tid = client.get("/api/agent/tokens", params={"org": org}).json()["tokens"][0]["id"]
    client.delete(f"/api/agent/tokens/{tid}", params={"org": org})
    assert client.post("/api/agent/report", json=_report(items), headers=auth).status_code == 401


def test_match_domain():
    from app.models import AITool
    from app.services.catalog import match_domain, web_domains
    tools = [AITool(slug="chatgpt", name="ChatGPT", signatures={"domains": ["chatgpt.com", "chat.openai.com"]}),
             AITool(slug="poe", name="Poe", signatures={"domains": ["poe.com"]})]
    assert match_domain(tools, "chatgpt.com")[0].slug == "chatgpt"
    assert match_domain(tools, "auth.chatgpt.com") == (tools[0], "chatgpt.com")
    assert match_domain(tools, "notchatgpt.com") is None and match_domain(tools, "openai.com") is None
    assert match_domain(tools, "xpoe.com") is None
    assert web_domains(tools) == ["chat.openai.com", "chatgpt.com", "poe.com"]


def test_web_report_flow(client):
    from datetime import date, timedelta
    login(client, "admin@cognitive.demo")
    org = _cognitive_org(client)
    token = client.post("/api/agent/tokens", params={"org": org}, json={"label": "Navegadores"}).json()["token"]
    auth = {"Authorization": f"Bearer {token}"}
    assert client.get("/api/agent/web-domains").status_code == 401
    domains = client.get("/api/agent/web-domains", headers=auth).json()["domains"]
    assert "claude.ai" in domains and "chatgpt.com" in domains

    today = date.today().isoformat()
    usage = [{"day": today, "domain": "claude.ai", "visits": 3, "active_minutes": 12},
             {"day": today, "domain": "chat.deepseek.com", "visits": 1, "active_minutes": 2},
             {"day": today, "domain": "ejemplo.com", "visits": 9, "active_minutes": 9},  # fuera del catálogo
             {"day": (date.today() - timedelta(days=90)).isoformat(), "domain": "claude.ai", "visits": 1}]
    body = {"hostname": "COG-WEB-01", "os": "Windows", "browser": "chrome", "extension_version": "0.1.0",
            "usage": usage}
    r = client.post("/api/agent/web-report", json=body, headers=auth).json()
    assert r["herramientas_ia"] == 2 and r["ignorados"] == 2
    client.post("/api/agent/web-report", json=body, headers=auth)  # el mismo reporte otra vez: no duplica

    d = next(x for x in client.get("/api/devices", params={"org": org}).json() if x["hostname"] == "COG-WEB-01")
    assert sorted(d["tools"]) == ["Claude", "DeepSeek"]
    alerts = client.get("/api/alerts", params={"org": org}).json()
    assert any("DeepSeek" in a["title"] for a in alerts)

    # El agente de Windows del mismo equipo no retira lo que vio la extensión.
    client.post("/api/agent/report", json=_report([], hostname="COG-WEB-01"), headers=auth)
    d = next(x for x in client.get("/api/devices", params={"org": org}).json() if x["hostname"] == "COG-WEB-01")
    assert sorted(d["tools"]) == ["Claude", "DeepSeek"] and d["person"] == "Ana Prueba"

    from app.db import SessionLocal
    from app.models import WebUsage
    from sqlalchemy import select
    with SessionLocal() as db:
        rows = list(db.scalars(select(WebUsage).where(WebUsage.org_id == org)))
    assert sorted((w.domain, w.visits, w.active_minutes) for w in rows) == [("chat.deepseek.com", 1, 2),
                                                                            ("claude.ai", 3, 12)]
    r = client.options("/api/agent/web-report", headers={"Origin": "chrome-extension://" + "a" * 32,
                                                         "Access-Control-Request-Method": "POST",
                                                         "Access-Control-Request-Headers": "authorization"})
    assert r.headers.get("access-control-allow-origin") == "chrome-extension://" + "a" * 32


def test_prompt_events_flow(client):
    from datetime import date, timedelta

    from app.db import SessionLocal
    from app.models import PromptEvent
    from sqlalchemy import select as sa_select

    login(client, "admin@cognitive.demo")
    org = _cognitive_org(client)
    token = client.post("/api/agent/tokens", params={"org": org}, json={"label": "DLP"}).json()["token"]
    auth = {"Authorization": f"Bearer {token}"}

    today = date.today().isoformat()
    events = [
        {"id": "e1", "host": "chatgpt.com", "day": today, "sensitive": {"EMAIL": 1},
         "text": "mi correo es [EMAIL]", "decision": "ocultado"},
        {"id": "e2", "host": "claude.ai", "day": today, "sensitive": {"TARJETA": 2}, "text": "[TARJETA] [TARJETA]"},
        # Sin datos sensibles y sin decisión: NO se guarda (minimización).
        {"id": "e3", "host": "chatgpt.com", "day": today, "sensitive": {}, "text": "hola"},
        # Etiqueta basura que manda la página: se ignora al limpiar.
        {"id": "e4", "host": "chatgpt.com", "day": today, "sensitive": {"<script>": 3}, "text": "x"},
        # Más viejo que la retención: se descarta.
        {"id": "e5", "host": "claude.ai", "day": (date.today() - timedelta(days=200)).isoformat(),
         "sensitive": {"CURP": 1}, "text": "[CURP]"},
    ]
    body = {"hostname": "COG-DLP-01", "os": "Windows", "user": "COGNITIVE\\ana", "person_name": "Ana Prueba",
            "area": "Desarrollo & Automatización", "browser": "chrome", "extension_version": "0.1.0", "events": events}

    assert client.post("/api/agent/prompt-events", json=body).status_code == 401  # sin token
    r = client.post("/api/agent/prompt-events", json=body, headers=auth).json()
    assert r["guardados"] == 2 and r["omitidos"] == 3

    # Idempotencia: el mismo lote otra vez no duplica.
    r2 = client.post("/api/agent/prompt-events", json=body, headers=auth).json()
    assert r2["guardados"] == 0

    with SessionLocal() as db:
        rows = list(db.scalars(sa_select(PromptEvent).where(PromptEvent.org_id == org)))
    assert {e.event_id for e in rows} == {"e1", "e2"}
    e1 = next(e for e in rows if e.event_id == "e1")
    assert e1.sensitive == {"EMAIL": 1} and e1.decision == "ocultado" and e1.tool_id is not None
    assert "[EMAIL]" in e1.text  # el texto llega y se guarda enmascarado


def test_agent_tokens_need_role(client):
    login(client, "direccion@empresademo.mx")
    assert client.post("/api/agent/tokens", json={"label": "x"}).status_code == 403


def test_create_org_and_user(client):
    login(client, "admin@cognitive.demo")
    org = client.post("/api/admin/orgs", json={"name": "Cliente Real SA"}).json()
    assert client.post("/api/admin/orgs", json={"name": "Cliente Real SA"}).status_code == 409
    a = client.get("/api/assessment", params={"org": org["id"]}).json()
    assert len(a["dimensions"]) == 9 and a["maturity"] is None
    assert client.post("/api/admin/users", json={"email": "ti@clientereal.mx", "name": "TI", "role": "cliente_admin_ti",
                                                 "org_id": org["id"]}).status_code == 200
    assert client.post("/api/admin/users", json={"email": "x@y.mx", "name": "X", "role": "consultor",
                                                 "org_id": org["id"]}).status_code == 422


def test_password_login_flow(client, monkeypatch):
    """Login real con contraseña: alta con temporal, login ok/fallido, cuenta sin contraseña, cambio."""
    from app import config

    # El admin inicia sesión en modo dev (sin contraseña) y crea la organización/usuarios.
    login(client, "admin@cognitive.demo")
    org = client.post("/api/admin/orgs", json={"name": "Cliente Password SA"}).json()

    # Usuario creado AÚN en modo dev: no tiene contraseña definida.
    client.post("/api/admin/users", json={"email": "sinpass@clientepw.mx", "name": "Sin Pass",
                                           "role": "cliente_seguridad", "org_id": org["id"]})

    # A partir de aquí, la plataforma corre en modo password.
    monkeypatch.setattr(config, "AUTH_MODE", "password")

    # El admin (sesión ya abierta por cookie) crea un usuario: recibe una contraseña temporal una sola vez.
    r = client.post("/api/admin/users", json={"email": "conpass@clientepw.mx", "name": "Con Pass",
                                              "role": "cliente_seguridad", "org_id": org["id"]}).json()
    temp = r["temp_password"]
    assert temp and len(temp) >= config.PASSWORD_MIN_LEN

    client.post("/api/auth/logout")
    # En modo password, dev-users deja de existir.
    assert client.get("/api/auth/dev-users").status_code == 404

    # Contraseña incorrecta -> 401.
    assert client.post("/api/auth/login", json={"email": "conpass@clientepw.mx", "password": "mal"}).status_code == 401
    # Cuenta existente sin contraseña -> 403 con mensaje claro.
    assert client.post("/api/auth/login", json={"email": "sinpass@clientepw.mx", "password": "x"}).status_code == 403
    # Contraseña correcta -> entra.
    ok = client.post("/api/auth/login", json={"email": "conpass@clientepw.mx", "password": temp})
    assert ok.status_code == 200 and ok.json()["email"] == "conpass@clientepw.mx"

    # Cambio de contraseña: actual incorrecta falla; luego cambia y la nueva sirve.
    assert client.post("/api/auth/change-password",
                       json={"current_password": "mal", "new_password": "ClaveNueva2026"}).status_code == 403
    assert client.post("/api/auth/change-password",
                       json={"current_password": temp, "new_password": "ClaveNueva2026"}).status_code == 200
    client.post("/api/auth/logout")
    assert client.post("/api/auth/login", json={"email": "conpass@clientepw.mx", "password": temp}).status_code == 401
    assert client.post("/api/auth/login",
                       json={"email": "conpass@clientepw.mx", "password": "ClaveNueva2026"}).status_code == 200


def test_reset_blocked_in_real_mode(client, monkeypatch):
    from app import config
    login(client, "admin@cognitive.demo")
    monkeypatch.setattr(config, "IS_DEMO", False)
    assert client.post("/api/admin/reset-demo").status_code == 403
