"""Operación: consumo de IA, bitácora, sincronización con Fleet y reinicio de la demo."""
import secrets

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .. import config
from ..auth import COGNITIVE_ROLES, ROLE_LABELS, Ctx, audit, ctx, require_roles
from ..db import get_db
from ..models import AuditLog, ConsoleUser, LLMUsage, Organization
from ..security import hash_password
from ..services import fleet

router = APIRouter(prefix="/api/admin", tags=["operación"])


def _gen_password() -> str:
    """Contraseña temporal legible (~12 caracteres) para entregar al usuario por un canal seguro."""
    return secrets.token_urlsafe(9)


@router.get("/llm-usage")
def llm_usage(c: Ctx = Depends(require_roles("admin_cognitive", "consultor")), db: Session = Depends(get_db)):
    rows = list(db.scalars(select(LLMUsage).order_by(LLMUsage.id.desc()).limit(100)))
    total = db.scalar(select(func.coalesce(func.sum(LLMUsage.cost_usd), 0.0)))
    return {"mode": config.BEDROCK_MODE, "total_cost_usd": round(float(total or 0), 4),
            "daily_budget_usd": config.DAILY_LLM_BUDGET_USD,
            "calls": [{"task": r.task, "model": r.model, "mode": r.mode, "input_tokens": r.input_tokens,
                       "output_tokens": r.output_tokens, "cost_usd": r.cost_usd, "latency_ms": r.latency_ms,
                       "ok": r.ok, "at": r.created_at.isoformat()} for r in rows]}


@router.get("/audit")
def audit_log(c: Ctx = Depends(ctx), db: Session = Depends(get_db)):
    """Bitácora de accesos. El admin de Cognitive ve todo; un usuario de cliente, la de su organización."""
    q = select(AuditLog).order_by(AuditLog.id.desc()).limit(200)
    if c.user.org_id is not None:
        if c.role not in {"cliente_admin_ti", "cliente_seguridad"}:
            raise HTTPException(403)
        q = q.where(AuditLog.org_id == c.user.org_id)
    elif c.role != "admin_cognitive":
        raise HTTPException(403)
    return [{"user": r.user_email, "org_id": r.org_id, "action": r.action, "object": r.object,
             "at": r.created_at.isoformat()} for r in db.scalars(q)]


@router.post("/fleet-sync")
def fleet_sync(c: Ctx = Depends(require_roles("admin_cognitive")), db: Session = Depends(get_db)):
    try:
        stats = fleet.sync_from_fleet(db)
    except fleet.FleetNotConfigured as exc:
        raise HTTPException(400, str(exc)) from exc
    audit(db, c, "sincronizar_fleet")
    db.commit()
    return stats


class OrgIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)


@router.post("/orgs")
def create_org(body: OrgIn, c: Ctx = Depends(require_roles("admin_cognitive")), db: Session = Depends(get_db)):
    """Alta de un cliente real: organización vacía con su assessment por responder."""
    from ..bootstrap import create_org as _create
    if db.scalars(select(Organization).where(Organization.name == body.name.strip())).first():
        raise HTTPException(409, "Ya existe una organización con ese nombre")
    org = _create(db, body.name.strip())
    audit(db, c, "crear_organizacion", org.name)
    db.commit()
    return {"id": org.id, "name": org.name, "kind": org.kind}


class UserIn(BaseModel):
    email: str = Field(min_length=3, max_length=200)
    name: str = Field(min_length=1, max_length=120)
    role: str
    org_id: int | None = None
    # Solo en AUTH_MODE=password: contraseña inicial. Si se omite, se genera una temporal y se devuelve una vez.
    password: str | None = None


class SetPasswordIn(BaseModel):
    password: str | None = None  # omitir => generar una temporal


@router.get("/users")
def list_users(c: Ctx = Depends(require_roles("admin_cognitive")), db: Session = Depends(get_db)):
    orgs = {o.id: o.name for o in db.scalars(select(Organization))}
    return [{"id": u.id, "email": u.email, "name": u.name, "role": u.role, "role_label": ROLE_LABELS.get(u.role, u.role),
             "org": orgs.get(u.org_id) if u.org_id else "Cognitive"}
            for u in db.scalars(select(ConsoleUser).order_by(ConsoleUser.id))]


@router.post("/users")
def create_user(body: UserIn, c: Ctx = Depends(require_roles("admin_cognitive")), db: Session = Depends(get_db)):
    if body.role not in ROLE_LABELS:
        raise HTTPException(422, "Rol inválido")
    is_cognitive = body.role in COGNITIVE_ROLES
    if is_cognitive == (body.org_id is not None):
        raise HTTPException(422, "Los roles de Cognitive van sin organización; los de cliente, con una")
    if body.org_id is not None and not db.get(Organization, body.org_id):
        raise HTTPException(404, "Organización no encontrada")
    email = body.email.strip().lower()
    if db.scalars(select(ConsoleUser).where(ConsoleUser.email == email)).first():
        raise HTTPException(409, "Ya existe un usuario con ese correo")
    u = ConsoleUser(email=email, name=body.name.strip(), role=body.role, org_id=body.org_id)

    temp_password = None
    if config.AUTH_MODE == "password":
        pw = (body.password or "").strip()
        if pw and len(pw) < config.PASSWORD_MIN_LEN:
            raise HTTPException(422, f"La contraseña debe tener al menos {config.PASSWORD_MIN_LEN} caracteres")
        if not pw:
            pw = _gen_password()
            temp_password = pw  # se muestra UNA vez; el admin la entrega por un canal seguro
        u.password_hash = hash_password(pw)

    db.add(u)
    audit(db, c, "crear_usuario", email)
    db.commit()
    # temp_password solo viene cuando se generó automáticamente (igual que el token de agente: visible una vez).
    return {"id": u.id, "temp_password": temp_password}


@router.post("/users/{uid}/set-password")
def set_user_password(uid: int, body: SetPasswordIn,
                      c: Ctx = Depends(require_roles("admin_cognitive")), db: Session = Depends(get_db)):
    """Reinicia la contraseña de un usuario (olvido/alta). Devuelve la temporal una vez si se generó."""
    if config.AUTH_MODE != "password":
        raise HTTPException(400, "El manejo de contraseñas solo aplica en modo password")
    u = db.get(ConsoleUser, uid)
    if not u:
        raise HTTPException(404, "Usuario no encontrado")
    pw = (body.password or "").strip()
    if pw and len(pw) < config.PASSWORD_MIN_LEN:
        raise HTTPException(422, f"La contraseña debe tener al menos {config.PASSWORD_MIN_LEN} caracteres")
    temp_password = None
    if not pw:
        pw = _gen_password()
        temp_password = pw
    u.password_hash = hash_password(pw)
    audit(db, c, "reiniciar_contrasena", u.email)
    db.commit()
    return {"ok": True, "temp_password": temp_password}


@router.post("/reset-demo")
def reset_demo(c: Ctx = Depends(require_roles("admin_cognitive"))):
    """Borra y vuelve a generar los datos de demo (misma semilla = misma demo cada vez)."""
    if not config.IS_DEMO:
        raise HTTPException(403, "En modo real no se borran los datos")
    from seed.generate_demo import reset_and_seed
    reset_and_seed()
    return {"ok": True}
