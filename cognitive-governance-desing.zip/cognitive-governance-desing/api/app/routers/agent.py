"""Agente de inventario y extensión del navegador: recepción de reportes y tokens de inscripción por organización."""
from datetime import datetime

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..auth import Ctx, audit, require_org
from ..db import get_db
from ..models import AgentToken, AITool, Device
from ..services import ingest
from ..services.catalog import web_domains

router = APIRouter(prefix="/api/agent", tags=["agente"])

CAN_MANAGE_AGENT = {"admin_cognitive", "consultor", "cliente_admin_ti"}


def _agent_token(authorization: str = Header(default=""), db: Session = Depends(get_db)) -> AgentToken:
    """El agente y la extensión no tienen sesión: se identifican con el token de su organización."""
    token = authorization.removeprefix("Bearer ").strip()
    t = ingest.resolve_token(db, token) if token else None
    if not t:
        raise HTTPException(401, "Token del agente inválido o revocado")
    t.last_used_at = datetime.utcnow()
    return t


@router.post("/report")
def report(body: ingest.AgentReport, t: AgentToken = Depends(_agent_token), db: Session = Depends(get_db)):
    """Lo llama el agente instalado en cada equipo."""
    return ingest.ingest_report(db, t.org_id, body)


@router.get("/web-domains")
def domains(t: AgentToken = Depends(_agent_token), db: Session = Depends(get_db)):
    """Lista de dominios que vigila la extensión: lo que no esté aquí ni se cuenta ni se guarda en el navegador."""
    db.commit()  # guarda last_used_at
    return {"domains": web_domains(list(db.scalars(select(AITool))))}


@router.post("/web-report")
def web_report(body: ingest.WebReport, t: AgentToken = Depends(_agent_token), db: Session = Depends(get_db)):
    """Lo llama la extensión del navegador (agent/browser/)."""
    return ingest.ingest_web_report(db, t.org_id, body)


@router.post("/prompt-events")
def prompt_events(body: ingest.PromptEventsReport, t: AgentToken = Depends(_agent_token), db: Session = Depends(get_db)):
    """Capa DLP: la extensión reporta mensajes con datos sensibles (texto YA enmascarado). Ver ingest_prompt_events."""
    return ingest.ingest_prompt_events(db, t.org_id, body)


def _manager(c: Ctx = Depends(require_org)) -> Ctx:
    if c.role not in CAN_MANAGE_AGENT:
        raise HTTPException(403, "Tu rol no administra el agente")
    return c


@router.get("/tokens")
def list_tokens(c: Ctx = Depends(_manager), db: Session = Depends(get_db)):
    devices = db.scalars(select(Device).where(Device.org_id == c.org_id, Device.source == "agente"))
    return {"devices": sum(1 for _ in devices),
            "tokens": [{"id": t.id, "label": t.label, "created_by": t.created_by, "created_at": t.created_at.isoformat(),
                        "last_used_at": t.last_used_at.isoformat() if t.last_used_at else None, "revoked": t.revoked}
                       for t in db.scalars(select(AgentToken).where(AgentToken.org_id == c.org_id)
                                           .order_by(AgentToken.id.desc()))]}


class TokenIn(BaseModel):
    label: str = Field(min_length=1, max_length=120)


@router.post("/tokens")
def create_token(body: TokenIn, c: Ctx = Depends(_manager), db: Session = Depends(get_db)):
    """Devuelve el token en claro UNA sola vez; después solo se guarda su hash."""
    token = ingest.create_token(db, c.org_id, body.label, c.user.email)
    audit(db, c, "crear_token_agente", body.label)
    db.commit()
    return {"token": token}


@router.delete("/tokens/{token_id}")
def revoke_token(token_id: int, c: Ctx = Depends(_manager), db: Session = Depends(get_db)):
    t = db.get(AgentToken, token_id)
    if not t or t.org_id != c.org_id:
        raise HTTPException(404)
    t.revoked = True
    audit(db, c, "revocar_token_agente", t.label)
    db.commit()
    return {"ok": True}
