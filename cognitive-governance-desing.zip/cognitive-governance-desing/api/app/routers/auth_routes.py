from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import config
from ..auth import COGNITIVE_ROLES, ROLE_LABELS, authenticate, current_user
from ..db import get_db
from ..models import AuditLog, ConsoleUser, Organization
from ..security import hash_password, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginIn(BaseModel):
    email: str
    password: str | None = None


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str


def _user_out(u: ConsoleUser, db: Session) -> dict:
    org = db.get(Organization, u.org_id) if u.org_id else None
    return {"id": u.id, "email": u.email, "name": u.name, "role": u.role, "role_label": ROLE_LABELS.get(u.role, u.role),
            "org_id": u.org_id, "org_name": org.name if org else "Cognitive", "is_cognitive": u.role in COGNITIVE_ROLES,
            "data_mode": config.DATA_MODE}


@router.get("/mode")
def mode():
    """La consola usa esto para saber qué pantalla de login mostrar (selector de usuarios vs. correo+contraseña)."""
    return {"auth_mode": config.AUTH_MODE, "bedrock_mode": config.BEDROCK_MODE, "data_mode": config.DATA_MODE}


@router.get("/dev-users")
def dev_users(db: Session = Depends(get_db)):
    """Solo en modo dev: lista de usuarios de prueba para el selector de la pantalla de login."""
    if config.AUTH_MODE != "dev":
        raise HTTPException(404)
    return [_user_out(u, db) for u in db.scalars(select(ConsoleUser).order_by(ConsoleUser.id))]


@router.post("/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    if config.AUTH_MODE == "entra":
        raise HTTPException(400, "El login local está desactivado; usa Microsoft Entra ID")

    # Mensaje claro cuando la cuenta existe pero aún no tiene contraseña definida (modo password).
    if config.AUTH_MODE == "password":
        from ..auth import find_user
        existing = find_user(db, body.email)
        if existing and not existing.password_hash:
            raise HTTPException(403, "Tu cuenta aún no tiene contraseña. Pide al administrador que te active el acceso.")

    user = authenticate(db, body.email, body.password)
    if not user:
        # Mismo mensaje para "no existe" y "contraseña incorrecta": no revelamos cuál correo es válido.
        raise HTTPException(401, "Correo o contraseña incorrectos")

    request.session["uid"] = user.id
    db.add(AuditLog(user_email=user.email, org_id=user.org_id, action="login"))
    db.commit()
    return _user_out(user, db)


@router.post("/change-password")
def change_password(body: ChangePasswordIn, user: ConsoleUser = Depends(current_user), db: Session = Depends(get_db)):
    """El usuario con sesión cambia su propia contraseña. Requiere la contraseña actual."""
    if config.AUTH_MODE != "password":
        raise HTTPException(400, "El cambio de contraseña solo aplica en modo password")
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(403, "La contraseña actual no es correcta")
    if len(body.new_password) < config.PASSWORD_MIN_LEN:
        raise HTTPException(422, f"La nueva contraseña debe tener al menos {config.PASSWORD_MIN_LEN} caracteres")
    user.password_hash = hash_password(body.new_password)
    db.add(AuditLog(user_email=user.email, org_id=user.org_id, action="cambiar_contrasena"))
    db.commit()
    return {"ok": True}


@router.post("/logout")
def logout(request: Request):
    request.session.clear()
    return {"ok": True}


@router.get("/me")
def me(user: ConsoleUser = Depends(current_user), db: Session = Depends(get_db)):
    return _user_out(user, db)
