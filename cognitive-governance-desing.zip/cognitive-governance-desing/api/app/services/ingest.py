"""Ingesta de inventarios reales: lo que el agente (agent/) reporta de cada equipo.

Cada reporte es la foto COMPLETA del equipo en ese momento: lo que ya no aparece se retira.
Principio de minimización: solo nombres e identificadores de software; nunca contenido, historial ni pantallas.

La extensión del navegador (agent/browser/) reporta aparte el uso web de IA: solo dominios del catálogo con
visitas y minutos activos por día. Ver ingest_web_report.
"""
import hashlib
import re
import secrets
from datetime import date, datetime, timedelta

from pydantic import BaseModel, Field
from sqlalchemy import delete, func, select
from sqlalchemy.orm import Session

from ..models import (AgentToken, AITool, Alert, Area, Detection, Device, DeviceUnknown, OrgToolStatus, Person,
                      PromptEvent, UnknownSignature, WebUsage, WeeklySnapshot)
from .catalog import match_domain, match_signature
from .fleet import AI_HINT

KINDS = {"app", "extension", "vscode", "process", "package"}
UNASSIGNED_AREA = "Sin asignar"
# Un equipo que no reporta en este tiempo pasa a "sin reportar" (el agente reporta cada hora).
STALE_AFTER = timedelta(hours=26)
# Una detección web se retira si la herramienta no se usa en el navegador durante este tiempo.
WEB_RETENTION = timedelta(days=30)
BROWSERS = {"chrome", "edge", "brave"}
# Los eventos DLP (prompts con datos sensibles) se conservan este tiempo y luego se borran solos.
PROMPT_RETENTION_DAYS = 90
# Etiquetas de tipo de dato válidas (p. ej. EMAIL, TARJETA, CONFIDENCIAL). Lo que manda la extensión no es confiable.
PROMPT_TAG_RE = re.compile(r"^[A-ZÑÉ_]{2,20}$")
PROMPT_DECISIONS = {"enviado", "ocultado"}


class ReportItem(BaseModel):
    kind: str
    name: str = Field(max_length=300)
    identifier: str | None = Field(default=None, max_length=300)


class AgentReport(BaseModel):
    hostname: str = Field(min_length=1, max_length=120)
    os: str = Field(default="?", max_length=60)
    user: str | None = Field(default=None, max_length=200)
    person_name: str | None = Field(default=None, max_length=120)
    area: str | None = Field(default=None, max_length=80)
    agent_version: str | None = Field(default=None, max_length=20)
    items: list[ReportItem] = Field(default_factory=list, max_length=10000)


class WebDay(BaseModel):
    day: date
    domain: str = Field(min_length=1, max_length=120)
    visits: int = Field(default=0, ge=0, le=100000)
    active_minutes: int = Field(default=0, ge=0, le=1440)


class WebReport(BaseModel):
    """Lo que envía la extensión: totales por día y dominio del catálogo. Nunca URLs, títulos ni contenido."""
    hostname: str = Field(min_length=1, max_length=120)
    os: str = Field(default="?", max_length=60)
    user: str | None = Field(default=None, max_length=200)
    person_name: str | None = Field(default=None, max_length=120)
    area: str | None = Field(default=None, max_length=80)
    browser: str = Field(default="?", max_length=20)
    extension_version: str | None = Field(default=None, max_length=20)
    usage: list[WebDay] = Field(default_factory=list, max_length=2000)


class PromptEventItem(BaseModel):
    """Un mensaje con datos sensibles. `text` llega YA enmascarado; aquí nunca debe venir el dato real."""
    id: str = Field(min_length=1, max_length=80)         # id de la extensión: clave de idempotencia
    host: str = Field(min_length=1, max_length=120)
    day: date
    time: datetime | None = None
    text: str = Field(default="", max_length=20000)
    sensitive: dict[str, int] = Field(default_factory=dict)
    decision: str | None = Field(default=None, max_length=20)


class PromptEventsReport(BaseModel):
    """Lo que envía la extensión en la capa DLP: solo mensajes con datos sensibles, con el texto enmascarado."""
    hostname: str = Field(min_length=1, max_length=120)
    os: str = Field(default="?", max_length=60)
    user: str | None = Field(default=None, max_length=200)
    person_name: str | None = Field(default=None, max_length=120)
    area: str | None = Field(default=None, max_length=80)
    browser: str = Field(default="?", max_length=20)
    extension_version: str | None = Field(default=None, max_length=20)
    events: list[PromptEventItem] = Field(default_factory=list, max_length=2000)


# ---------------------------------------------------------------- tokens de inscripción

def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create_token(db: Session, org_id: int, label: str, created_by: str) -> str:
    token = "lab2_" + secrets.token_urlsafe(32)
    db.add(AgentToken(org_id=org_id, label=label, token_hash=hash_token(token), created_by=created_by))
    db.commit()
    return token


def resolve_token(db: Session, token: str) -> AgentToken | None:
    t = db.scalars(select(AgentToken).where(AgentToken.token_hash == hash_token(token))).first()
    return t if t and not t.revoked else None


# ---------------------------------------------------------------- ingesta

def _area(db: Session, org_id: int, name: str) -> Area:
    a = db.scalars(select(Area).where(Area.org_id == org_id, Area.name == name)).first()
    if not a:
        a = Area(org_id=org_id, name=name)
        db.add(a)
        db.flush()
    return a


def _person(db: Session, org_id: int, r: AgentReport | WebReport | PromptEventsReport) -> Person | None:
    if not r.user:
        return None
    # El agente no conoce el correo: la cuenta del sistema operativo identifica a la persona.
    key = r.user.strip().lower()
    p = db.scalars(select(Person).where(Person.org_id == org_id, Person.email == key)).first()
    if not p:
        p = Person(org_id=org_id, area_id=_area(db, org_id, r.area or UNASSIGNED_AREA).id,
                   name=r.person_name or r.user, email=key)
        db.add(p)
        db.flush()
        return p
    if r.person_name:
        p.name = r.person_name
    if r.area:  # el área configurada al instalar el agente manda
        p.area_id = _area(db, org_id, r.area).id
    return p


def _alert_for_new_tool(db: Session, org_id: int, tool: AITool, hostname: str) -> None:
    st = db.scalars(select(OrgToolStatus).where(OrgToolStatus.org_id == org_id, OrgToolStatus.tool_id == tool.id)).first()
    if st and st.status == "no_aprobada":
        kind, sev, title = "ia_no_aprobada", "alta" if tool.risk == "alto" else "media", f"IA no aprobada detectada: {tool.name}"
    elif tool.risk == "alto" and not (st and st.status == "aprobada"):
        kind, sev, title = "ia_riesgo_alto", "media", f"Herramienta de riesgo alto detectada: {tool.name}"
    else:
        return
    if db.scalars(select(Alert).where(Alert.org_id == org_id, Alert.ref == tool.slug, Alert.status == "abierta")).first():
        return
    detail = f"Primera detección en el equipo {hostname}."
    if tool.alternative:
        detail += f" Alternativa sugerida: {tool.alternative}."
    db.add(Alert(org_id=org_id, type=kind, severity=sev, title=title, detail=detail, ref=tool.slug))


def _unknown(db: Session, org_id: int, kind: str, name: str, identifier: str | None) -> UnknownSignature:
    u = db.scalars(select(UnknownSignature).where(UnknownSignature.org_id == org_id, UnknownSignature.kind == kind,
                                                  UnknownSignature.name == name)).first()
    if not u:
        u = UnknownSignature(org_id=org_id, kind=kind, name=name, identifier=identifier, devices_count=0)
        db.add(u)
        db.flush()
    return u


def ingest_report(db: Session, org_id: int, r: AgentReport) -> dict:
    now = datetime.utcnow()
    dev = db.scalars(select(Device).where(Device.org_id == org_id, Device.source == "agente",
                                          Device.hostname == r.hostname)).first()
    if not dev:
        dev = Device(org_id=org_id, hostname=r.hostname, source="agente", os=r.os)
        db.add(dev)
    dev.os, dev.agent_status, dev.last_seen = r.os, "activo", now
    db.flush()
    person = _person(db, org_id, r)
    if person:
        dev.person_id = person.id

    tools = list(db.scalars(select(AITool)))
    org_tools = set(db.scalars(select(Detection.tool_id).where(Detection.org_id == org_id)))
    matched: dict[int, str] = {}
    unknown_ids: set[int] = set()
    seen = set()
    for it in r.items:
        if it.kind not in KINDS or not it.name.strip():
            continue
        key = (it.kind, it.name.strip().lower(), (it.identifier or "").lower())
        if key in seen:
            continue
        seen.add(key)
        tool = match_signature(tools, it.kind, it.name, it.identifier)
        if tool:
            matched.setdefault(tool.id, f"{it.kind}:{it.name}"[:300])
        elif AI_HINT.search(f"{it.name} {it.identifier or ''}"):
            # Solo lo que "parece IA" va a la cola de desconocidos; el resto del software se ignora.
            unknown_ids.add(_unknown(db, org_id, it.kind, it.name.strip(), it.identifier).id)

    # Detecciones: alta de lo nuevo, actualización de lo visto, retiro de lo desinstalado.
    current = {d.tool_id: d for d in db.scalars(select(Detection).where(Detection.device_id == dev.id))}
    by_id = {t.id: t for t in tools}
    for tool_id, raw in matched.items():
        if tool_id in current:
            current[tool_id].last_seen = now
        else:
            db.add(Detection(org_id=org_id, device_id=dev.id, tool_id=tool_id, source="agente", raw_signature=raw,
                             first_seen=now, last_seen=now))
            if tool_id not in org_tools:
                _alert_for_new_tool(db, org_id, by_id[tool_id], r.hostname)
    removed = [tid for tid, d in current.items() if tid not in matched and d.source == "agente"]
    if removed:
        db.execute(delete(Detection).where(Detection.device_id == dev.id, Detection.tool_id.in_(removed)))

    # Desconocidos: un vínculo por equipo, así el conteo no crece con cada reporte.
    linked = set(db.scalars(select(DeviceUnknown.unknown_id).where(DeviceUnknown.device_id == dev.id)))
    for uid in unknown_ids - linked:
        db.add(DeviceUnknown(device_id=dev.id, unknown_id=uid))
    if linked - unknown_ids:
        db.execute(delete(DeviceUnknown).where(DeviceUnknown.device_id == dev.id,
                                               DeviceUnknown.unknown_id.in_(linked - unknown_ids)))
    db.flush()
    for uid in unknown_ids | linked:
        u = db.get(UnknownSignature, uid)
        u.devices_count = db.scalar(select(func.count()).select_from(DeviceUnknown).where(DeviceUnknown.unknown_id == uid))

    mark_stale_devices(db, org_id, now)
    db.flush()
    update_weekly_snapshot(db, org_id, now)
    db.commit()
    return {"equipo": dev.hostname, "herramientas_ia": len(matched), "desconocidos": len(unknown_ids),
            "retiradas": len(removed), "elementos_recibidos": len(r.items)}


def ingest_web_report(db: Session, org_id: int, r: WebReport) -> dict:
    """Uso web de IA. Los totales del día se sobrescriben (el reporte se puede repetir sin duplicar)."""
    now = datetime.utcnow()
    # El mismo equipo que reporta el agente de Windows (se identifican por el nombre del equipo).
    dev = db.scalars(select(Device).where(Device.org_id == org_id, Device.source == "agente",
                                          Device.hostname == r.hostname)).first()
    if not dev:
        dev = Device(org_id=org_id, hostname=r.hostname, source="agente", os=r.os)
        db.add(dev)
    dev.agent_status, dev.last_seen = "activo", now
    db.flush()
    if r.user:  # sin usuario, el equipo conserva la persona que asignó el agente
        dev.person_id = _person(db, org_id, r).id

    browser = r.browser.lower() if r.browser.lower() in BROWSERS else "?"
    tools = list(db.scalars(select(AITool)))
    oldest = (now - WEB_RETENTION).date()
    used: dict[int, str] = {}
    rows: dict[tuple, WebUsage] = {}
    ignored = 0
    for u in r.usage:
        m = match_domain(tools, u.domain)
        if not m or u.day < oldest or u.day > now.date() + timedelta(days=1) or not (u.visits or u.active_minutes):
            ignored += 1
            continue
        tool, domain = m
        key = (tool.id, domain, u.day)
        if key in rows:  # el mismo dominio dos veces en un reporte (p. ej. chat.x.com y x.com): se suman
            row = rows[key]
            row.visits += u.visits
            row.active_minutes = min(1440, row.active_minutes + u.active_minutes)
        else:
            row = db.scalars(select(WebUsage).where(
                WebUsage.device_id == dev.id, WebUsage.tool_id == tool.id, WebUsage.domain == domain,
                WebUsage.day == u.day, WebUsage.browser == browser)).first()
            if not row:
                row = WebUsage(org_id=org_id, device_id=dev.id, tool_id=tool.id, domain=domain, day=u.day,
                               browser=browser)
                db.add(row)
            rows[key] = row
            row.visits, row.active_minutes = u.visits, u.active_minutes
        used.setdefault(tool.id, f"dominio:{domain}")

    # Detecciones: el uso web cuenta igual que una instalación; no se duplica si el agente ya la vio.
    current = {d.tool_id: d for d in db.scalars(select(Detection).where(Detection.device_id == dev.id))}
    org_tools = set(db.scalars(select(Detection.tool_id).where(Detection.org_id == org_id)))
    by_id = {t.id: t for t in tools}
    for tool_id, raw in used.items():
        if tool_id in current:
            current[tool_id].last_seen = now
        else:
            db.add(Detection(org_id=org_id, device_id=dev.id, tool_id=tool_id, source="navegador", raw_signature=raw,
                             first_seen=now, last_seen=now))
            if tool_id not in org_tools:
                _alert_for_new_tool(db, org_id, by_id[tool_id], r.hostname)
    expired = [tid for tid, d in current.items()
               if tid not in used and d.source == "navegador" and now - d.last_seen > WEB_RETENTION]
    if expired:
        db.execute(delete(Detection).where(Detection.device_id == dev.id, Detection.tool_id.in_(expired)))

    mark_stale_devices(db, org_id, now)
    db.flush()
    update_weekly_snapshot(db, org_id, now)
    db.commit()
    return {"equipo": dev.hostname, "herramientas_ia": len(used), "ignorados": ignored, "retiradas": len(expired)}


def _clean_sensitive(d: dict) -> dict:
    """Solo deja etiquetas válidas en mayúsculas con conteo entero positivo. El payload de la página no es confiable."""
    out: dict[str, int] = {}
    for tag, n in (d or {}).items():
        if PROMPT_TAG_RE.match(str(tag)) and isinstance(n, int) and not isinstance(n, bool) and n > 0:
            out[str(tag)] = n
    return out


def ingest_prompt_events(db: Session, org_id: int, r: PromptEventsReport) -> dict:
    """Capa DLP: guarda los mensajes con datos sensibles que reporta la extensión.

    Minimización: solo se guarda un evento si traía datos sensibles (o pasó por la advertencia). El texto ya viene
    enmascarado. Idempotencia: el `id` de la extensión no se guarda dos veces. El equipo se une por hostname, igual
    que el agente y el reporte web.
    """
    now = datetime.utcnow()
    dev = db.scalars(select(Device).where(Device.org_id == org_id, Device.source == "agente",
                                          Device.hostname == r.hostname)).first()
    if not dev:
        dev = Device(org_id=org_id, hostname=r.hostname, source="agente", os=r.os)
        db.add(dev)
    dev.agent_status, dev.last_seen = "activo", now
    db.flush()
    if r.user:  # sin usuario, el equipo conserva la persona que asignó el agente
        dev.person_id = _person(db, org_id, r).id

    browser = r.browser.lower() if r.browser.lower() in BROWSERS else "?"
    tools = list(db.scalars(select(AITool)))
    oldest = (now - timedelta(days=PROMPT_RETENTION_DAYS)).date()

    incoming_ids = [e.id for e in r.events]
    already = set(db.scalars(select(PromptEvent.event_id).where(
        PromptEvent.org_id == org_id, PromptEvent.event_id.in_(incoming_ids)))) if incoming_ids else set()

    stored = 0
    skipped = 0
    seen = set()
    for e in r.events:
        sens = _clean_sensitive(e.sensitive)
        decision = e.decision if e.decision in PROMPT_DECISIONS else None
        # Minimización: sin datos sensibles y sin advertencia previa, no se guarda nada (aunque llegue texto).
        if not sens and not decision:
            skipped += 1
            continue
        if e.day < oldest or e.day > now.date() + timedelta(days=1):
            skipped += 1
            continue
        if e.id in already or e.id in seen:  # idempotencia
            skipped += 1
            continue
        seen.add(e.id)
        m = match_domain(tools, e.host)
        tool_id = m[0].id if m else None
        host = m[1] if m else e.host.strip().lower()[:120]
        occurred = e.time.replace(tzinfo=None) if e.time else now
        db.add(PromptEvent(org_id=org_id, device_id=dev.id, person_id=dev.person_id, tool_id=tool_id,
                           event_id=e.id, host=host, day=e.day, occurred_at=occurred,
                           text=(e.text or "")[:20000], sensitive=sens, decision=decision,
                           browser=browser, source="extension"))
        stored += 1

    # Retención: se borran los eventos más viejos que PROMPT_RETENTION_DAYS.
    db.execute(delete(PromptEvent).where(PromptEvent.org_id == org_id, PromptEvent.day < oldest))

    mark_stale_devices(db, org_id, now)
    db.flush()
    db.commit()
    return {"equipo": dev.hostname, "guardados": stored, "omitidos": skipped}


def mark_stale_devices(db: Session, org_id: int, now: datetime) -> None:
    for d in db.scalars(select(Device).where(Device.org_id == org_id, Device.source == "agente",
                                             Device.agent_status == "activo")):
        if d.last_seen and now - d.last_seen > STALE_AFTER:
            d.agent_status = "sin_reportar"


def update_weekly_snapshot(db: Session, org_id: int, now: datetime) -> None:
    """Foto de la semana en curso para la tendencia del Resumen (se sobrescribe hasta que cambie la semana)."""
    from . import metrics
    s = metrics.summary(db, org_id)
    monday = (now - timedelta(days=now.weekday())).date()
    snap = db.scalars(select(WeeklySnapshot).where(WeeklySnapshot.org_id == org_id,
                                                   WeeklySnapshot.week_start == monday)).first()
    if not snap:
        snap = WeeklySnapshot(org_id=org_id, week_start=monday)
        db.add(snap)
    c = s["status_counts"]
    snap.approved, snap.in_review, snap.not_approved = c["aprobada"], c["en_revision"], c["no_aprobada"]
    snap.people_unapproved = s["kpis"]["people_unapproved"]
