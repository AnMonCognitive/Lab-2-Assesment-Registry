"""Login y control de acceso.

Modo "dev" (por defecto): la pantalla de login muestra usuarios de prueba, uno por rol.
Modo "entra": pendiente. Pasos para activarlo (semana 2 del plan):
  1. Registrar la app en Entra ID (URL de retorno: https://<consola>/api/auth/callback).
  2. Agregar Authlib y completar login_entra()/callback_entra() con OIDC (código de autorización + PKCE).
  3. Mapear grupos de Entra -> roles de ROLE_LABELS y crear el ConsoleUser al primer ingreso.
"""
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import config
from .db import get_db
from .models import AuditLog, ConsoleUser, Organization
from .security import verify_password

ROLE_LABELS = {
    "admin_cognitive": "Admin Cognitive",
    "consultor": "Consultor Cognitive",
    "analista_catalogo": "Analista de catálogo",
    "cliente_admin_ti": "Admin TI del cliente",
    "cliente_seguridad": "Seguridad del cliente",
    "cliente_direccion": "Dirección del cliente",
}

COGNITIVE_ROLES = {"admin_cognitive", "consultor", "analista_catalogo"}
# Quién ve nombres de personas y hostnames (Dirección solo ve agregados por área).
SEES_PEOPLE = {"admin_cognitive", "consultor", "cliente_admin_ti", "cliente_seguridad"}
CAN_DECIDE_TOOLS = {"admin_cognitive", "consultor", "cliente_seguridad"}
CAN_EDIT_ASSESSMENT = {"admin_cognitive", "consultor"}
CAN_EDIT_CATALOG = {"admin_cognitive", "analista_catalogo"}
CAN_EDIT_SYSTEMS = {"admin_cognitive", "consultor", "cliente_admin_ti", "cliente_seguridad"}
# Eventos DLP (prompts con datos sensibles, texto enmascarado): dato más sensible → solo Seguridad y Cognitive.
# Dirección NUNCA, ni siquiera Admin TI del cliente.
CAN_SEE_PROMPTS = {"admin_cognitive", "consultor", "cliente_seguridad"}


@dataclass
class Ctx:
    """Usuario actual + organización sobre la que está trabajando."""
    user: ConsoleUser
    org_id: int | None

    @property
    def role(self) -> str:
        return self.user.role

    @property
    def sees_people(self) -> bool:
        return self.user.role in SEES_PEOPLE


def find_user(db: Session, email: str) -> ConsoleUser | None:
    return db.scalars(select(ConsoleUser).where(ConsoleUser.email == (email or "").strip().lower())).first()


def authenticate(db: Session, email: str, password: str | None = None) -> ConsoleUser | None:
    """Interfaz ÚNICA de autenticación. Devuelve el usuario si las credenciales son válidas, o None.

    Hoy soporta dos backends según AUTH_MODE; mañana Keycloak/Entra se enchufan AQUÍ (validar el token
    OIDC y resolver/crear el ConsoleUser) sin tocar los routers ni la pantalla de login.
      - "dev":      basta con que el correo exista (sin contraseña). Solo desarrollo/demo.
      - "password": correo + contraseña, verificada contra el hash bcrypt.
    """
    user = find_user(db, email)
    if not user:
        return None
    if config.AUTH_MODE == "dev":
        return user
    if config.AUTH_MODE == "password":
        return user if verify_password(password or "", user.password_hash) else None
    return None  # "entra" u otro: aún no implementado aquí


def current_user(request: Request, db: Session = Depends(get_db)) -> ConsoleUser:
    uid = request.session.get("uid")
    if not uid:
        raise HTTPException(401, "No has iniciado sesión")
    user = db.get(ConsoleUser, uid)
    if not user:
        request.session.clear()
        raise HTTPException(401, "Sesión inválida")
    return user


def ctx(request: Request, db: Session = Depends(get_db), user: ConsoleUser = Depends(current_user)) -> Ctx:
    """Resuelve la organización: un usuario de cliente siempre queda en la suya;
    el personal de Cognitive elige con ?org=<id> (por defecto, el primer cliente)."""
    if user.org_id is not None:
        return Ctx(user, user.org_id)
    if user.role == "analista_catalogo":
        return Ctx(user, None)
    org_param = request.query_params.get("org")
    if org_param:
        org = db.get(Organization, int(org_param))
        if not org:
            raise HTTPException(404, "Organización no encontrada")
        return Ctx(user, org.id)
    first = db.scalars(select(Organization).where(Organization.kind == "cliente").order_by(Organization.id)).first()
    return Ctx(user, first.id if first else None)


def require_org(c: Ctx = Depends(ctx)) -> Ctx:
    if c.org_id is None:
        raise HTTPException(403, "Este rol no tiene acceso a datos de clientes")
    return c


def require_roles(*roles: str):
    def dep(c: Ctx = Depends(ctx)) -> Ctx:
        if c.role not in roles:
            raise HTTPException(403, "Tu rol no permite esta acción")
        return c
    return dep


def audit(db: Session, c: Ctx, action: str, obj: str | None = None) -> None:
    db.add(AuditLog(user_email=c.user.email, org_id=c.org_id, action=action, object=obj))
