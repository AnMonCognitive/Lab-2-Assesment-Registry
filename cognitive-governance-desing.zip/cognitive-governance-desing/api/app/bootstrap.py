"""Arranque en modo real (DATA_MODE=real): sin datos ficticios.

Siempre mantiene el catálogo al día con el YAML. Si la base está vacía, crea la primera organización y el
primer administrador (BOOTSTRAP_ORG_NAME, BOOTSTRAP_ADMIN_EMAIL); el resto se da de alta desde Operación.
"""
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import config
from .models import Assessment, AssessmentAnswer, ConsoleUser, Organization
from .security import hash_password
from .services.catalog import sync_catalog


def new_assessment(db: Session, org_id: int) -> Assessment:
    """Assessment vacío con las 9 dimensiones (el consultor lo responde en la consola)."""
    from seed.generate_demo import QUESTIONS
    a = Assessment(org_id=org_id, status="en_curso")
    db.add(a)
    db.flush()
    for dim, qs in QUESTIONS.items():
        for q in qs:
            db.add(AssessmentAnswer(assessment_id=a.id, dimension=dim, question=q))
    return a


def create_org(db: Session, name: str, kind: str = "cliente") -> Organization:
    org = Organization(name=name, kind=kind, is_demo=False)
    db.add(org)
    db.flush()
    new_assessment(db, org.id)
    return org


def bootstrap_real(db: Session) -> list[str]:
    done = []
    sync_catalog(db)
    if not db.scalars(select(Organization)).first():
        create_org(db, config.BOOTSTRAP_ORG_NAME, kind="cognitive")
        done.append(f"organización '{config.BOOTSTRAP_ORG_NAME}'")
    if not db.scalars(select(ConsoleUser)).first():
        admin = ConsoleUser(email=config.BOOTSTRAP_ADMIN_EMAIL, name="Administrador", role="admin_cognitive")
        if config.AUTH_MODE == "password" and config.BOOTSTRAP_ADMIN_PASSWORD:
            admin.password_hash = hash_password(config.BOOTSTRAP_ADMIN_PASSWORD)
            done.append(f"administrador {config.BOOTSTRAP_ADMIN_EMAIL} (con contraseña inicial)")
        elif config.AUTH_MODE == "password":
            # Sin contraseña inicial: el admin no podrá entrar hasta que se le asigne una.
            done.append(f"administrador {config.BOOTSTRAP_ADMIN_EMAIL} (SIN contraseña: define BOOTSTRAP_ADMIN_PASSWORD)")
        else:
            done.append(f"administrador {config.BOOTSTRAP_ADMIN_EMAIL}")
        db.add(admin)
    db.commit()
    return done
