"""Cognitive Governance Platform · Lab 2 (Readiness Assessment + Registry) — versión preliminar."""
import logging
import sys

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware

from . import config

# Permite importar seed/ desde la raíz del repositorio.
sys.path.insert(0, str(config.ROOT_DIR))

from .db import Base, SessionLocal, engine  # noqa: E402
from .routers import admin, agent, assessment, auth_routes, catalog_routes, inventory, registry  # noqa: E402

log = logging.getLogger("lab2")

app = FastAPI(title="Cognitive Governance Platform · Lab 2", version="0.1.0",
              description="Readiness Assessment + AI Registry (versión preliminar para la demo)")
app.add_middleware(SessionMiddleware, secret_key=config.SESSION_SECRET, session_cookie="lab2_session",
                   same_site="lax", https_only=config.SESSION_HTTPS_ONLY, max_age=8 * 3600)

# Solo la extensión del navegador llama a la API desde otro origen; se autentica con token, nunca con la cookie.
app.add_middleware(CORSMiddleware, allow_origin_regex=r"^chrome-extension://[a-p]{32}$", allow_credentials=False,
                   allow_methods=["GET", "POST"], allow_headers=["Authorization", "Content-Type"])

for r in (auth_routes, inventory, registry, catalog_routes, assessment, admin, agent):
    app.include_router(r.router)


@app.on_event("startup")
def startup() -> None:
    # Demo/test: el esquema es desechable, se crea al vuelo. Real: lo gobiernan las migraciones de Alembic
    # (se aplican con `alembic upgrade head`, normalmente desde el entrypoint del contenedor antes de arrancar).
    if config.IS_DEMO:
        Base.metadata.create_all(engine)
    if not config.IS_DEMO:
        from .bootstrap import bootstrap_real
        with SessionLocal() as db:
            for item in bootstrap_real(db):
                log.warning("Modo real: se creó %s", item)
        if config.AUTH_MODE == "dev":
            log.warning("Modo real con AUTH_MODE=dev: cualquiera que abra la consola puede entrar. "
                        "Úsalo solo en una red de confianza hasta activar el login con contraseña o Entra ID.")
    elif config.SEED_ON_START:
        from seed.generate_demo import seed_if_empty
        if seed_if_empty():
            log.warning("Base vacía: se cargaron el catálogo y los datos de demo")


@app.get("/api/health")
def health():
    return {"ok": True, "data_mode": config.DATA_MODE, "bedrock_mode": config.BEDROCK_MODE,
            "auth_mode": config.AUTH_MODE}
