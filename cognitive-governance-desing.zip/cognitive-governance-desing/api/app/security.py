"""Hashing de contraseñas (bcrypt).

Solo se guarda el hash de la contraseña, nunca la contraseña en claro (igual que el token de agente).
bcrypt incluye su propia sal y un factor de coste; `verify` es tolerante a hashes inválidos o vacíos.
"""
import bcrypt

# bcrypt solo considera los primeros 72 bytes de la contraseña; truncamos explícitamente para evitar
# el error de versiones nuevas de la librería cuando la entrada supera ese límite.
_MAX_BYTES = 72


def _prep(password: str) -> bytes:
    return password.encode("utf-8")[:_MAX_BYTES]


def hash_password(password: str) -> str:
    """Devuelve el hash bcrypt (string de ~60 caracteres) listo para guardar."""
    return bcrypt.hashpw(_prep(password), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str | None) -> bool:
    """True si la contraseña coincide con el hash. Nunca lanza: hash nulo/corrupto => False."""
    if not password or not password_hash:
        return False
    try:
        return bcrypt.checkpw(_prep(password), password_hash.encode("utf-8"))
    except (ValueError, TypeError):
        return False
