"""agregar password_hash a console_users (login con contraseña)

Revision ID: 0002_password_hash
Revises: 0001_baseline
Create Date: 2026-10-20 18:00:00.000000+00:00

Primera migración "real": agrega la columna del hash de contraseña SIN borrar datos.
Es el cambio que habilita AUTH_MODE=password. En una base con usuarios existentes, la columna
queda en NULL (esos usuarios deben recibir una contraseña con /api/admin/users/{id}/set-password).
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "0002_password_hash"
down_revision: Union[str, None] = "0001_baseline"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("console_users", sa.Column("password_hash", sa.String(length=255), nullable=True))


def downgrade() -> None:
    op.drop_column("console_users", "password_hash")
