"""Entorno de Alembic.

Toma la URL de la base de app.config (DATABASE_URL) e importa TODO el modelo para que
el autogenerate compare contra el esquema real (app.models registra las tablas en Base.metadata).
"""
from logging.config import fileConfig

from alembic import context
from sqlalchemy import engine_from_config, pool

# Permite "import app.*" al correr alembic desde el directorio api/.
from app import config as app_config  # noqa: E402
from app.db import Base  # noqa: E402
import app.models  # noqa: F401,E402  (registra todas las tablas en Base.metadata)

cfg = context.config
if cfg.config_file_name is not None:
    fileConfig(cfg.config_file_name)

# La URL siempre viene de la app, nunca del alembic.ini.
cfg.set_main_option("sqlalchemy.url", app_config.DATABASE_URL)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    context.configure(
        url=app_config.DATABASE_URL,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        cfg.get_section(cfg.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(connection=connection, target_metadata=target_metadata, compare_type=True)
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
