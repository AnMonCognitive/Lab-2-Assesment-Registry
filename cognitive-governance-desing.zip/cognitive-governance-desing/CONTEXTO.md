# Contexto del proyecto · Cognitive Governance Platform

Documento de traspaso para empezar un proyecto nuevo y más ordenado partiendo de **Lab 2**
(`C:\Users\gelci\Downloads\lab2-governance\lab2-governance`). Copiarlo a la raíz del proyecto nuevo, idealmente
como `CLAUDE.md`, para que Claude Code lo lea al abrirlo. Última actualización: 14 de octubre de 2026.

## Qué es

Una consola web para que una empresa sepa **qué IA se usa, quién la usa, con qué riesgo y qué tan lista está la
organización**. La opera Cognitive (consultoría) para sus clientes. Tiene dos piezas:

1. **AI Registry / inventario:** detecta herramientas de IA en los equipos (apps, extensiones, procesos, uso web), las
   cruza con un catálogo de riesgo, permite aprobar o no aprobar cada una y genera alertas.
2. **Readiness Assessment:** 9 dimensiones de madurez que llena el consultor, con un reporte generado por Claude
   (Amazon Bedrock).

Demo comprometida: **13 de noviembre de 2026**.

## Objetivo del proyecto nuevo

**Pasar de datos fijos a datos dinámicos.** En Lab 2 la demo se ve con datos ficticios de semilla fija
(`seed/generate_demo.py`: 3 organizaciones, 120 equipos, 12 semanas de tendencia). El proyecto nuevo debe funcionar
solo con datos reales que llegan en vivo de los equipos, y lo que hoy está fijo en archivos debe poder cambiarse
desde la consola.

### Qué ya es dinámico en Lab 2 (`DATA_MODE=real`)
- Equipos, personas, áreas y detecciones: llegan del agente de Windows y de la extensión del navegador, cada hora.
- Alertas: se generan solas al detectar una IA no aprobada o de riesgo alto.
- Tendencia semanal: se toma una foto en cada reporte (`WeeklySnapshot`).
- Organizaciones, usuarios de la consola y tokens del agente: se dan de alta desde **Operación**.
- Desconocidos: lo que "parece IA" y no está en el catálogo pasa a una cola. Bedrock sugiere la ficha y el analista
  la publica.

### Qué sigue fijo y hay que volver dinámico
| Qué | Dónde está hoy | Qué hace falta |
| --- | --- | --- |
| Catálogo de IA (51 herramientas, firmas, dominios, riesgo) | `catalog/ai_catalog.yaml`, se carga al arrancar | Editarlo desde la consola, con historial de cambios; el YAML solo como carga inicial |
| Preguntas del assessment (9 dimensiones) | `QUESTIONS` en `seed/generate_demo.py` | Tabla propia, editable y versionada |
| Usuarios de prueba y login | `AUTH_MODE=dev` (selector sin contraseña) | Microsoft Entra ID (pendiente en `api/app/auth.py`) |
| Datos de demo | `seed/generate_demo.py` | Separarlos por completo del código de producción (solo para pruebas) |
| Uso web (visitas y minutos) | Se guarda en `web_usage` pero no se muestra | Vistas y métricas en la consola |
| Precios de Bedrock | Variables `PRICE_*` en `.env` | Revisar contra la página oficial |

## Arquitectura actual de Lab 2 (reutilizable)

```
Equipos Windows ── agente PowerShell (cada hora) ──┐
Chrome/Edge ── extensión MV3 (cada hora) ──────────┤  token por organización (Bearer)
                                                    ▼
                         Caddy (HTTPS) ──► FastAPI (api/) ──► PostgreSQL
                              │                  └──► Amazon Bedrock (Claude: clasificar desconocidos, reporte)
Personas ─────────────────────┴──► React + Vite + Tailwind (web/)
```

| Carpeta | Qué hay | Estado |
| --- | --- | --- |
| `api/` | FastAPI + SQLAlchemy. Routers: auth, inventory, registry, catalog, assessment, admin, agent | Funciona; 16 pruebas en `api/tests` |
| `api/app/services/ingest.py` | Ingesta de reportes del agente y de la extensión, tokens, alertas, foto semanal | Funciona |
| `api/app/services/catalog.py` | Carga del catálogo y reconocimiento de firmas (`match_signature`, `match_domain`) | Funciona |
| `api/app/services/bedrock.py` | Llamadas a Claude con modo simulado, registro de tokens y costo, presupuesto diario | Funciona |
| `web/` | Consola: Resumen, Herramientas, Dispositivos, Áreas, Registry, Alertas, Assessment, Catálogo, Operación | Funciona |
| `agent/windows/` | Agente PowerShell sin administrador: programas, apps de la Store, extensiones, VS Code/Cursor, procesos | Probado con un equipo real |
| `agent/browser/` | Extensión Chrome/Edge/Brave: visitas y minutos en dominios del catálogo | **Prototipo**, sin probar en navegador real |
| `catalog/` | `ai_catalog.yaml` con valores **preliminares** (`reviewed: false`) | Pendiente de revisión |
| `fleet/` | Integración con Fleet/osquery | Código listo, sin probar |
| `ops/` | `backup.sh` (pg_dump a S3), `rls.sql` (seguridad por fila) | RLS sin activar |

Roles: admin Cognitive, consultor, analista de catálogo, admin TI del cliente, seguridad del cliente y dirección
(esta última solo ve agregados por área, nunca nombres).

## Decisiones tomadas (no volver a discutir sin motivo)

- **Minimización de datos:** solo nombres e identificadores de software y, en el navegador, dominios del catálogo con
  conteos. Nunca contenido, URLs completas, títulos, historial, pantallas ni teclas.
- **La extensión del navegador recolecta y no almacena.** Complementa al agente, no lo reemplaza; los datos viven en
  PostgreSQL. El equipo se une entre agente y extensión por `hostname` (`%COMPUTERNAME%`).
- **No escribir un servidor HTTP propio desde cero.** Caddy + FastAPI/uvicorn + PostgreSQL ya es el servidor propio.
- **AWS:** primero EC2 con docker compose (rol de IAM, solo puertos 80/443, respaldos a S3) y después RDS PostgreSQL.
  Más adelante, separar el servicio de recepción (`/api/agent/*`) de la consola con el mismo código.
- **Multi-cliente:** toda tabla de cliente lleva `org_id`; la API siempre filtra por organización.
- **Bedrock** con modo `simulado` para trabajar sin AWS.

## Pendientes conocidos

1. Login con Entra ID. Hasta entonces, en modo real la consola solo en red de confianza o VPN.
2. Activar `ops/rls.sql` (ya incluye `web_usage`).
3. Migraciones con Alembic (hoy `create_all` al arrancar; no altera tablas existentes).
4. Agente para macOS.
5. Probar la extensión en Chrome y Edge reales, publicarla como "no listada" y actualizar el aviso de privacidad
   (mide tiempo en sitios de IA).
6. Revisar el catálogo contra los términos vigentes de cada proveedor antes de mostrarlo a un cliente.
7. Probar Fleet con un servidor real, o descartarlo si el agente propio basta.

## Recomendaciones para el proyecto nuevo

- Usar **git desde el primer día**.
- Reutilizar módulo por módulo lo que ya funciona (catálogo, agente, ingesta, permisos, pruebas) en lugar de
  reescribirlo. Lo que cambia es la organización y que los datos fijos pasen a la base de datos.
- Que la demo use una organización real de prueba (los equipos de Cognitive con el agente instalado) en lugar de datos
  de semilla.
- Mantener el proyecto Lab 2 como referencia, sin borrarlo.
