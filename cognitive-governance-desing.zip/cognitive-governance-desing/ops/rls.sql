-- Seguridad por fila (Row-Level Security) para producción.
-- La API ya filtra por organización; esto es una segunda barrera por si el código tiene un error.
-- Requiere que la API ejecute, al inicio de cada petición:  SET app.org_id = '<id>';
-- (pendiente de implementar en app/db.py antes del primer cliente real).

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['areas','people','devices','detections','org_tool_status','unknown_signatures',
                           'ai_systems','alerts','assessments','weekly_snapshots','web_usage']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('DROP POLICY IF EXISTS org_isolation ON %I', t);
    EXECUTE format($p$CREATE POLICY org_isolation ON %I
                     USING (org_id = current_setting('app.org_id', true)::int)$p$, t);
  END LOOP;
END $$;

-- El usuario de la API no debe ser dueño de las tablas ni superusuario (si lo es, RLS no aplica).
