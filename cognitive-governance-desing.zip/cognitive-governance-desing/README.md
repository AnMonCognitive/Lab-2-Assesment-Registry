# Cognitive Governance Platform · Lab 2

**Readiness Assessment + AI Registry** — versión preliminar para la demo del 13 de noviembre de 2026.

Consola web que responde: *¿qué IA se usa en la empresa, quién la usa, con qué riesgo y qué tan lista está la organización?*
Todos los datos incluidos son **ficticios**.

## Qué funciona hoy

| Módulo | Estado |
| --- | --- |
| Login por rol (6 usuarios de prueba) y permisos por rol | Funciona (modo `dev`) |
| Resumen: KPIs, tendencia de 12 semanas, uso por área, "atender primero" | Funciona con datos de demo |
| Herramientas de IA: inventario, ficha, decisión aprobar / no aprobar | Funciona |
| Dispositivos (solo roles que ven personas) | Funciona con datos de demo |
| Áreas (vista agregada, sin nombres) | Funciona |
| Registry de sistemas de IA propios: alta, edición, fichas incompletas | Funciona |
| Alertas: atender, descartar, reabrir | Funciona |
| Readiness Assessment: 9 dimensiones, radar, edición por el consultor, reporte con IA, imprimir a PDF | Funciona (IA en modo simulado o Bedrock) |
| Catálogo de IA (51 herramientas) y cola de desconocidos con clasificación por IA | Funciona |
| Operación: consumo de IA (tokens, costo, latencia), bitácora de accesos, reinicio de demo | Funciona |
| **Modo real** (`DATA_MODE=real`): agente propio para Windows, tokens por organización, alta de clientes y usuarios | Funciona (probado con un equipo real) |
| Extensión de navegador (uso web de IA: visitas y minutos por sitio del catálogo) | **Prototipo**, probado con pruebas de la API; sin probar en un navegador real (ver `agent/browser/README.md`) |
| Sincronización con Fleet (agente osquery) | Código listo, **sin probar con Fleet real** |
| Login con Microsoft Entra ID | **Pendiente** (ver `api/app/auth.py`) |
| Seguridad por fila en PostgreSQL | Script listo en `ops/rls.sql`, **sin activar** |

## Arranque rápido con Docker (recomendado)

Requisitos: Docker y Docker Compose.

```bash
cp .env.example .env        # cambia POSTGRES_PASSWORD y SESSION_SECRET
docker compose up -d --build
```

Abre http://localhost y entra con cualquier usuario de prueba. La primera vez se cargan el catálogo y los datos de demo.

Para incluir el agente (Fleet + MySQL + Redis):

```bash
docker compose --profile fleet up -d --build
```

## Desarrollo sin Docker

Requisitos: Python 3.12+, Node 20+, PostgreSQL 16.

```bash
# Base de datos (una vez)
createuser -s lab2 && createdb -O lab2 lab2   # usuario y clave "lab2" por defecto (ver api/app/config.py)

# API  → http://localhost:8000/docs
cd api
pip install -r requirements.txt
uvicorn app.main:app --reload

# Consola  → http://localhost:5173  (redirige /api a la API)
cd web
npm install
npm run dev

# Pruebas de la API
cd api && pytest -q

# Volver a generar los datos de demo (misma semilla = misma demo)
python -m seed.generate_demo
```

## Usuarios de prueba

| Usuario | Rol | Qué ve |
| --- | --- | --- |
| admin@cognitive.demo | Admin Cognitive | Todo, todas las organizaciones, bitácora, Fleet, reinicio |
| consultor@cognitive.demo | Consultor Cognitive | Clientes, edita y genera el assessment |
| analista@cognitive.demo | Analista de catálogo | Solo catálogo y desconocidos, sin datos de clientes |
| ti@empresademo.mx | Admin TI del cliente | Su organización con detalle; registra sistemas |
| seguridad@empresademo.mx | Seguridad del cliente | Detalle por persona; aprueba herramientas; atiende alertas |
| direccion@empresademo.mx | Dirección del cliente | Solo agregados por área, sin nombres ni equipos |

## Activar Claude en Amazon Bedrock

1. En la cuenta de AWS, habilitar el acceso a Claude Haiku 4.5 y Claude Sonnet 5 en Bedrock (us-east-1).
2. Crear el usuario técnico con permiso solo de `bedrock:InvokeModel` sobre esos modelos.
3. En `.env`: `BEDROCK_MODE=bedrock`, las llaves y los IDs de modelo **tal como aparecen en la consola de Bedrock**
   (los valores por defecto de `.env.example` son de referencia y deben verificarse).
4. Reiniciar la API. El consumo aparece en **Operación**.

Reglas que el código ya cumple (`api/app/services/bedrock.py`): sin datos personales hacia el modelo (el nombre del
cliente se reemplaza por un alias), respuestas JSON validadas, tope diario de gasto, todo registrado en `llm_usage`,
y la IA solo sugiere: un analista o el consultor confirman.

## Datos reales con el agente propio (recomendado para el prototipo)

1. En `.env`: `DATA_MODE=real` (con una base de datos nueva, distinta de la demo) y `BOOTSTRAP_ADMIN_EMAIL`.
   Al arrancar se cargan el catálogo, la organización `BOOTSTRAP_ORG_NAME` y el administrador; nada ficticio.
2. Entrar como administrador → **Operación**: crear las organizaciones cliente y los usuarios de la consola.
3. Elegir la organización arriba → **Operación → Agente de inventario → Generar token** (se muestra una sola vez).
4. En cada equipo Windows, con el consentimiento escrito de la persona, desde la carpeta `agent/windows`:
   ```powershell
   powershell -ExecutionPolicy Bypass -File install.ps1 -ServerUrl https://consola.<dominio> -Token lab2_xxx -Area "TI"
   ```
   Instala para el usuario actual (sin administrador) una tarea que reporta al iniciar sesión y cada hora.
   `lab2-agent.ps1 -DryRun` muestra lo que se enviaría sin enviarlo. Desinstalar: `uninstall.ps1`.
5. Los equipos aparecen en **Dispositivos**; las IA del catálogo, en **Herramientas**; lo que parece IA y no está en
   el catálogo, en **Catálogo → desconocidos**; las herramientas de riesgo alto nuevas generan una alerta.

Qué envía el agente: nombres de programas instalados y apps de la Store, extensiones de Chrome/Edge/Brave, extensiones
de VS Code/Cursor/Windsurf y nombres de procesos. Nunca contenido, historial, pantallas ni teclas. Cada reporte es la
foto completa del equipo: lo desinstalado se retira solo; un equipo sin reportar 26 h pasa a "sin reportar".

Limitaciones actuales: solo Windows (macOS pendiente); con `AUTH_MODE=dev` cualquiera que abra la consola puede entrar,
así que en modo real úsala solo en una red de confianza hasta activar Entra ID; sin Alembic, una base creada con
una versión anterior necesita las tablas nuevas (`agent_tokens`, `device_unknowns`, `web_usage`), que se crean solas al arrancar.

El agente no ve el uso de IA en el navegador (chatgpt.com, claude.ai…). Para eso está la extensión de
`agent/browser/` (prototipo), que usa el mismo token: ver su README.

## Conectar el agente (Fleet)

1. `docker compose --profile fleet up -d` y abrir `https://<FLEET_DOMAIN>` para crear el usuario administrador.
2. Crear un usuario de API en Fleet y poner `FLEET_URL=http://fleet:8080` y `FLEET_API_TOKEN` en `.env`.
3. Aplicar las consultas: `fleetctl apply -f fleet/queries.yml`.
4. Generar instaladores: `fleetctl package --type=msi` (Windows) y `--type=pkg` (macOS) con la URL y el secreto de
   inscripción que da Fleet. Instalar en los 5 equipos de Cognitive **con su consentimiento escrito**.
5. En la consola, **Operación → Sincronizar con Fleet**. Los equipos aparecen en la organización "Cognitive (interno)".

## Despliegue en el servidor (Lightsail 8 GB)

```bash
# Ubuntu 24.04, una sola vez
sudo apt update && sudo apt install -y docker.io docker-compose-v2 ufw fail2ban unattended-upgrades
sudo ufw allow 80,443/tcp && sudo ufw allow from <IP-oficina> to any port 22 && sudo ufw enable
git clone <repo> /opt/lab2 && cd /opt/lab2
cp .env.example .env   # CONSOLE_DOMAIN=consola.<dominio>, FLEET_DOMAIN=fleet.<dominio>, SESSION_HTTPS_ONLY=true, claves largas
docker compose --profile fleet up -d --build
# Respaldos nocturnos a S3
sudo crontab -e   →   0 3 * * * /opt/lab2/ops/backup.sh >> /var/log/lab2-backup.log 2>&1
```

Los DNS de ambos subdominios deben apuntar a la IP estática antes del primer arranque, para que Caddy obtenga los certificados.

## Diseño (Figma "IA-Gobernanza")

La consola sigue el sistema visual del Figma: barra lateral negra, rojo de marca (`#EC3A3F`) para acción y estado
activo, verde / naranja / rojo como colores oficiales de estado, morado para lo generado por IA, tipografía Poppins
(empaquetada con `@fontsource/poppins`, no depende de Google Fonts).

- Tokens: `web/tailwind.config.js` · estilos base (botones, campos, tablas, eyebrow): `web/src/index.css`
- Componentes del sistema (chips, KPI, control de decisión, escala 0–5, cajón lateral, tarjeta "Borrador IA",
  veredicto con orbe…): `web/src/components/ui.tsx` · íconos de navegación: `web/src/components/icons.tsx`
- Marca: `web/public/brand/` (`cognitive-logo.png`, `cognitive-mark.png`, `orb.png`). Se recortaron de la exportación
  PNG del Figma; **reemplazarlos por los archivos oficiales (SVG o PNG @2x) con el mismo nombre** para mejor nitidez.
- Navegación responsive: barra completa en escritorio, contraída a íconos en tablet, barra superior con menú en móvil.
- Pantalla "Registra tu cuenta" (modo `password`): solo interfaz. La API no tiene alta autoservicio; las cuentas
  las crea el administrador en **Operación**.

## Estructura

```
agent/          agente de inventario propio (windows/: PowerShell; browser/: extensión de uso web, prototipo)
api/            FastAPI: modelos, permisos, routers, servicios (bedrock, catálogo, fleet, métricas), pruebas
web/            React + Vite + Tailwind + Recharts: las vistas de la consola
catalog/        ai_catalog.yaml: catálogo de IA (valores preliminares de Cognitive Labs)
seed/           generate_demo.py: datos ficticios con semilla fija
fleet/          queries.yml: consultas osquery como código
ops/            backup.sh, rls.sql
docs/           guion de la demo
```

## Pendientes antes de un cliente real

- [ ] Login con Microsoft Entra ID (multi-cliente) y desactivar `AUTH_MODE=dev`
- [ ] Activar `ops/rls.sql` y que la API fije `app.org_id` en cada petición
- [ ] Probar `services/fleet.py` contra Fleet real y ajustar a la respuesta de su API
- [ ] Revisar cada ficha del catálogo (riesgo, veredicto, "¿entrena con datos?") con Tech Evaluation
- [ ] Migraciones con Alembic (hoy se crean tablas al arrancar)
- [ ] Worker con cola (RQ + Redis) para sincronización periódica y reportes largos
- [ ] Instaladores firmados, contrato de encargo de tratamiento y aviso de privacidad modelo
- [ ] Prueba de penetración
