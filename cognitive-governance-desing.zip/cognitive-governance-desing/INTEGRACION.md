# Integración · Central Lab 2 + Extensión DLP

Este repo une los **dos proyectos**:

1. **Central (Lab 2)** — FastAPI + React + PostgreSQL + agente Windows. La base de gobernanza/inventario.
2. **Extensión de navegador (Gobernanza IA / Cognitive)** — ahora en `agent/browser/`, reemplaza al prototipo
   metadata-only anterior. Añade la capa **DLP**: avisa y enmascara datos sensibles en sitios de IA, avisa/cancela
   descargas de apps de IA de escritorio, y reporta los eventos a la consola.

## Qué se agregó a la central (puente DLP)

- **Modelo `PromptEvent`** (`api/app/models.py`): evento DLP con texto **ya enmascarado**, tipos de dato detectados,
  decisión del usuario, `host`, día/hora. `UniqueConstraint(org_id, event_id)` para idempotencia.
- **Servicio `ingest_prompt_events`** (`api/app/services/ingest.py`): valida, aplica minimización (solo guarda si hay
  datos sensibles o pasó por la advertencia), idempotencia, retención (90 días) y saneado de etiquetas. Resuelve la
  herramienta por `match_domain`; une el equipo por `hostname` (igual que el agente de Windows y el reporte web).
- **Endpoint `POST /api/agent/prompt-events`** (`api/app/routers/agent.py`): autenticado con el token de organización.
- **Prueba `test_prompt_events_flow`** (`api/tests/test_api.py`).

## Qué cambió en la extensión

- Identidad por **política administrada** (`serverUrl`, `token`, `hostname`, `user`, `area` en `schema.json`), igual que
  la extensión original de Lab 2. Sin esos tres primeros, funciona como recolector local y no envía nada.
- Envía los eventos DLP a `POST {serverUrl}/api/agent/prompt-events` con el patrón outbox (enviar → confirmar → borrar,
  reintento, idempotencia por `id`).
- Diccionario de términos de la empresa (`orgTerms` por política, o la pestaña **Términos** del popup).
- Aviso/cancelación de descargas de apps de IA de escritorio.

## Cómo correrlo

```bash
cp .env.example .env            # cambia POSTGRES_PASSWORD y SESSION_SECRET
docker compose up -d --build
# consola: http://localhost   (usuarios de prueba en README.md)
```

### Conectar la extensión (pruebas)

1. Carga `agent/browser/` como extensión sin empaquetar (chrome://extensions → modo desarrollador).
2. En la consola web, Operación → crea un **token de organización**.
3. En la consola del service worker de la extensión:
   ```js
   chrome.storage.local.set({ config: {
     serverUrl: "http://localhost:8000",
     token: "lab2_...",
     hostname: "MI-EQUIPO-01"
   }})
   ```
4. Manda un prompt con un dato sensible (p. ej. un teléfono) en ChatGPT. En segundos aparece un `PromptEvent`.

### Despliegue (producción)

Usa `agent/browser/install-policy.ps1` por GPO/Intune: pone `serverUrl`, `token` y `hostname = %COMPUTERNAME%` por
equipo, para que la consola una el reporte del navegador con el del agente de Windows.

## Pendientes de la integración (lo que falta, honesto)

1. **Vista de Seguridad en la consola** que liste los `prompt_events` (y que **Dirección no** los vea). Aún no existe.
2. **Feed de inventario desde esta extensión** (`/api/agent/web-report`, visitas/minutos) para alimentar los tableros
   de uso con datos reales del navegador. La extensión hoy solo alimenta el canal DLP; el inventario de instalados lo
   sigue dando el agente de Windows.
3. **Seguridad (de Lab 2, ahora más urgente porque se guarda contenido enmascarado):** activar `ops/rls.sql` y
   **Entra ID** antes de producción (hoy `AUTH_MODE=dev` sin contraseña).
4. **Actualizar `CONTEXTO.md`:** el principio "nunca contenido" cambió con el visto bueno del cliente; ahora es
   "contenido enmascarado, solo cuando hay datos sensibles, con consentimiento".
5. **Validar la captura** de la extensión en los 4-5 chatbots más usados (criterio de "listo").
