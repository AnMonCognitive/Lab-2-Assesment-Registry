# Cognitive Governance Platform — Gobernanza y DLP de IA

Plataforma para que una empresa sepa **qué IA usan sus empleados, con qué riesgo, y evite que se filtren datos
sensibles** hacia herramientas de IA — todo con datos reales que llegan en vivo de cada equipo.

Une dos piezas en un solo producto:

1. **Extensión de navegador (DLP de IA):** revisa lo que el empleado va a enviar a una herramienta de IA; si
   detecta datos sensibles, **avisa y los enmascara** antes de que salgan. También avisa/cancela la descarga de
   apps de IA de escritorio.
2. **Consola central (gobernanza/inventario):** recibe los reportes, los guarda por organización y los muestra a
   Seguridad/TI: inventario de IA, alertas, "readiness assessment" y los eventos de datos sensibles.

---

## 1. El problema que resuelve

Los empleados usan ChatGPT, Claude, Gemini, etc. para trabajar, y muchas veces **pegan datos sensibles** (correos,
teléfonos, tarjetas, CURP, secretos de la empresa) sin pensar que esa información **sale de la empresa** y puede
quedar almacenada por el proveedor. La empresa no tiene visibilidad de **qué IA se usa** ni forma de **frenar la
fuga accidental**.

Este producto ataca ese riesgo en el canal donde ocurre el 95% de los casos (el navegador) y le da a Seguridad un
tablero con evidencia para actuar.

---

## 2. Cómo funciona (Input → Proceso → Output)

```
EQUIPOS (Input)                         SERVIDOR (Proceso)              CONSOLA (Output)
┌───────────────────────┐                                           ┌──────────────────────┐
│ Empleado usa una IA    │                                          │ Seguridad: datos      │
│                        │   (dato real) ─► IA externa (el riesgo)  │   sensibles, alertas  │
│  Extensión ───────────────(evento enmascarado + token)──────►┐    │ TI: inventario        │
│  Agente Windows ──────────(inventario)───────────────────────┤──► │ Dirección: agregados  │
│  DNS (opcional) ──────────(dominios de IA)───────────────────┘    │   (sin nombres)       │
└───────────────────────┘        FastAPI + PostgreSQL              └──────────────────────┘
```

**Los dos flujos del equipo (clave de privacidad):**

- El **dato real** del empleado viaja a la **IA externa** — ese es el riesgo que se vigila, no pasa por el servidor.
- A **tu servidor** solo viaja el **evento enmascarado**: el texto con el dato ya reemplazado por una etiqueta
  (`[TELÉFONO]`), el tipo de dato, la decisión y el equipo. **Nunca el valor real.**

---

## 3. Arquitectura y componentes

| Componente | Carpeta | Qué hace |
| --- | --- | --- |
| **Extensión de navegador** | `agent/browser/` | Captura/enmascara datos sensibles, avisa, cancela descargas de apps de IA, reporta eventos e inventario de uso web. Manifest V3 (Chrome/Edge/Brave). |
| **API central** | `api/` | FastAPI + SQLAlchemy. Recibe reportes del agente y la extensión, aplica permisos y multi-tenant, guarda en PostgreSQL. |
| **Consola web** | `web/` | React + Vite + Tailwind. Tableros por rol: Resumen, Herramientas, Dispositivos, Datos sensibles, Áreas, Alertas, Assessment, Catálogo, Operación. |
| **Agente de Windows** | `agent/windows/` | PowerShell sin admin: inventario de apps/extensiones/procesos de IA instalados. |
| **Catálogo de IA** | `catalog/ai_catalog.yaml` | Herramientas de IA conocidas, con dominios, firmas y nivel de riesgo. |
| **Infra** | `docker-compose.yml`, `Caddyfile` | PostgreSQL + API + consola (Caddy termina HTTPS y enruta `/api`). |

Canales de entrada (todos opcionales y complementarios): **extensión** (navegador, con DLP), **agente de Windows**
(inventario de instalados) y **DNS** (inventario de dominios de IA, incluye escritorio). La consola los une.

---

## 4. Modelo de identidad (multi-tenant)

Dos planos de identidad, unidos por la **organización**:

- **Equipo → organización, por el token de agente.** Cada reporte lleva `Authorization: Bearer <token>`. El token
  pertenece a una organización (`AgentToken.org_id`); todo lo que ese reporte crea se guarda bajo esa organización.
  El **hostname** distingue cada equipo dentro de la organización. *El equipo no elige su organización: la hereda
  del token que se le configuró.*
- **Cuenta de consola → organización, por `ConsoleUser.org_id`.** Un usuario de cliente queda amarrado a su
  organización (siempre ve solo la suya); el personal de Cognitive (`org_id` nulo) puede ver varias y elige con un
  selector.

Resultado: el usuario de Seguridad de la Empresa A ve **solo** los equipos cuyos tokens son de la Empresa A. Toda
tabla de cliente lleva `org_id` y la API filtra siempre por organización (en producción, además, RLS de PostgreSQL).

---

## 5. Privacidad y minimización (decisión de diseño)

- **Solo se guarda lo sensible.** Un mensaje sin datos sensibles se revisa en la página y **se descarta**; no se
  transmite ni se guarda.
- **El texto se enmascara antes de salir de la página** (`redact.js`): `[EMAIL]`, `[TARJETA]`, `[CURP]`,
  `[CONFIDENCIAL]`, etc. El servidor nunca recibe el valor real.
- **Tipos de dato + decisión**, no el dato: se guarda `{EMAIL: 1, TARJETA: 2}` y si el usuario "envió de todos
  modos" u "ocultó".
- **Diccionario de la empresa:** términos propios (clientes, proyectos) que también se enmascaran como
  `[CONFIDENCIAL]`, configurables por política o desde el popup.
- **Acceso restringido:** los eventos de datos sensibles solo los ve **Seguridad** (y Cognitive). **Dirección**
  nunca ve contenido ni nombres, solo agregados por área.
- **Retención:** los eventos se borran solos a los 90 días (configurable).

---

## 6. Modelo de datos (tablas principales)

- `organizations`, `console_users`, `areas`, `people`, `devices` — base multi-tenant.
- `ai_tools` — catálogo global de herramientas (riesgo, dominios, firmas).
- `agent_tokens` — tokens por organización (solo se guarda el hash).
- `detections`, `web_usage` — inventario de uso (qué IA se usa y cuánto).
- `prompt_events` — **capa DLP**: evento con texto enmascarado, tipos de dato, decisión, equipo. Idempotente por
  `event_id`.
- `alerts`, `assessments`, `weekly_snapshots`, `audit_log`, `llm_usage` — gobernanza y operación.

---

## 7. API principal

**Ingesta (autenticada con token de organización):**
- `POST /api/agent/report` — inventario del agente de Windows.
- `POST /api/agent/web-report` — uso web (visitas/minutos por dominio del catálogo).
- `POST /api/agent/prompt-events` — **eventos DLP** (mensajes con datos sensibles, texto enmascarado).
- `GET  /api/agent/web-domains` — dominios que vigila la extensión (también sirve para probar el token).
- `POST/GET/DELETE /api/agent/tokens` — gestión de tokens por organización.

**Consola (autenticada con sesión):**
- `GET /api/summary`, `/api/tools`, `/api/devices`, `/api/areas`, `/api/alerts`, `/api/assessment`.
- `GET /api/prompt-events` — lista los eventos DLP (solo Seguridad/Cognitive).
- `POST /api/admin/orgs`, `/api/admin/users` — alta de organizaciones y usuarios (solo admin).

---

## 8. Cómo correrlo

**Requisito:** Docker Desktop. (No necesitas instalar PostgreSQL, Python ni Node — todo corre en contenedores.)

```bash
copy .env.example .env        # Windows cmd  (o cp en bash)
# Edita .env: pon POSTGRES_PASSWORD y SESSION_SECRET (cadenas largas)
docker compose up -d --build
```

Abre **http://localhost**. En modo demo entras con un usuario de prueba (ej. `seguridad@empresademo.mx`), sin
contraseña.

**Modos (en `.env`):**
- `DATA_MODE=demo` — carga datos ficticios para ver la consola poblada.
- `DATA_MODE=real` — sin datos ficticios; crea la primera organización y el primer admin
  (`BOOTSTRAP_ORG_NAME`, `BOOTSTRAP_ADMIN_EMAIL`) y se llena solo con lo que reportan los equipos.
- `AUTH_MODE=dev` — login por correo sin contraseña (solo red de confianza). `entra` (Microsoft Entra ID) está
  pendiente.
- `BEDROCK_MODE=simulado` — el "assessment" por IA funciona sin AWS.

Comandos útiles: `docker compose ps`, `docker compose logs -f api`, `docker compose down`, `docker compose down -v`
(borra la base).

---

## 9. Enrolar un equipo (configurar la extensión)

El equipo necesita tres datos: **URL de la consola**, **token de la organización** y **nombre del equipo**. Dos formas:

- **Zero-touch (flotas / IT):** `agent/browser/install-policy.ps1` por GPO/Intune empuja los tres por política
  (`hostname = %COMPUTERNAME%`). El usuario no hace nada.
- **Auto-enrolamiento (manual):** en el popup de la extensión, pestaña **Conexión**, el usuario pega la URL + el
  token (que Seguridad/TI generó en Operación) y el nombre del equipo. Botón **Probar conexión** valida contra la
  consola.

Si hay política, el popup muestra la conexión en modo lectura (la política manda).

---

## 10. Roles y permisos

| Rol | Ve |
| --- | --- |
| Admin Cognitive | Todo, todas las organizaciones, bitácora, alta de orgs/usuarios |
| Consultor Cognitive | Clientes asignados, edita el assessment |
| Analista de catálogo | Solo el catálogo global |
| Admin TI (cliente) | Su organización: inventario, dispositivos, tokens |
| Seguridad (cliente) | Su organización + **datos sensibles**; aprueba herramientas, atiende alertas |
| Dirección (cliente) | Solo agregados por área — **sin nombres, sin contenido** |

---

## 11. Estado del proyecto

**Funciona y está verificado de punta a punta:**
- Extensión: DLP (enmascarado + aviso), diccionario de términos, aviso/cancelación de descargas, pestaña Conexión.
- Central: ingesta DLP (`prompt-events`) con idempotencia y minimización; multi-tenant por token/organización.
- Consola: pestaña **Datos sensibles** (solo Seguridad), con el evento enmascarado, tipos y decisión.
- Flujo completo probado: extensión captura → central guarda → consola muestra.

**Pendiente (roadmap al cierre):**
1. **Migraciones con Alembic** (hoy `create_all`; necesario para cambiar el esquema sin borrar la base).
2. **Catálogo y preguntas del assessment editables desde la consola** (hoy en YAML/código).
3. **Seguridad de producción:** activar RLS de PostgreSQL + Microsoft Entra ID (hoy login `dev` sin contraseña).
4. **Separar del todo demo y real** (modo real como camino principal).
5. **Validar la captura** en los 4-5 chatbots más usados.

**Fuera de alcance por ahora (futuro):** agente macOS, publicar la extensión en la tienda, proxy/CASB de escritorio
para inspección de contenido, DPAs/legal formal.

---

## 12. Alcance y límites (honesto)

- **La extensión cubre el canal navegador.** El canal **escritorio** (apps nativas de IA) se cierra con controles
  del cliente (bloqueo por AppLocker/Intune, o DNS para inventario), no con el código de la extensión.
- El producto **reduce la fuga accidental y da evidencia para actuar**; no previene la evasión deliberada de un
  insider (eso es política interna + RRHH). Declararlo así acota la responsabilidad del producto.
- En modo `AUTH_MODE=dev` no hay contraseñas: úsalo solo en red de confianza hasta activar Entra ID.

---

## 13. Estructura del repositorio

```
api/            FastAPI + SQLAlchemy (modelos, routers, servicios de ingesta y catálogo)
web/            Consola React + Vite + Tailwind
agent/browser/  Extensión Manifest V3 (DLP + inventario web)  ← la extensión del producto
agent/windows/  Agente PowerShell de inventario
catalog/        ai_catalog.yaml (catálogo de herramientas de IA)
ops/            rls.sql (seguridad por fila), backup.sh
seed/           generate_demo.py (datos de demo; separado del código de producción)
docker-compose.yml, Caddyfile, .env.example
INTEGRACION.md  Notas de la integración extensión + central
```
