<#
  Instala el agente de inventario de IA · Lab 2 para el usuario actual (no requiere administrador).

  Ejemplo:
    powershell -ExecutionPolicy Bypass -File install.ps1 -ServerUrl http://consola.midominio.com -Token lab2_xxx -Area "TI"

  Copia el agente a %LOCALAPPDATA%\Lab2Agent y crea una tarea programada que reporta al iniciar sesión y cada hora.
  Desinstalar:  powershell -ExecutionPolicy Bypass -File uninstall.ps1
#>
param(
  [Parameter(Mandatory = $true)][string]$ServerUrl,
  [Parameter(Mandatory = $true)][string]$Token,
  [string]$Area,
  [string]$PersonName,
  [switch]$Yes
)
$ErrorActionPreference = 'Stop'
$TaskName = 'Lab2 - Agente de inventario de IA'
$Dest = Join-Path $env:LOCALAPPDATA 'Lab2Agent'

if (-not $Yes) {
  Write-Host @"

Este agente enviará a $ServerUrl, cada hora, la lista de software de este equipo:
  programas instalados, extensiones de navegador y de editores de código, y nombres de procesos.
NO envía contenido de archivos, historial de navegación, pantallas, teclas ni documentos.
El objetivo es saber qué herramientas de IA se usan, conforme al aviso de privacidad de la empresa.

"@
  if ((Read-Host 'Escribe SI para aceptar e instalar') -ne 'SI') { Write-Host 'Instalación cancelada.'; exit 1 }
}

New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'lab2-agent.ps1') $Dest -Force
[ordered]@{ ServerUrl = $ServerUrl; Token = $Token; Area = $Area; PersonName = $PersonName } |
  ConvertTo-Json | Set-Content (Join-Path $Dest 'config.json') -Encoding UTF8

$script = Join-Path $Dest 'lab2-agent.ps1'
$action = New-ScheduledTaskAction -Execute 'powershell.exe' `
  -Argument "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$script`""
$triggers = @(
  (New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"),
  (New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Hours 1))
)
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
  -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggers -Settings $settings `
  -Description 'Reporta el inventario de software (detección de herramientas de IA) a la consola Lab 2.' -Force | Out-Null

Write-Host 'Primer reporte...'
& $script
Write-Host "`nListo. El agente reporta al iniciar sesión y cada hora. Registro: $Dest\agent.log"
