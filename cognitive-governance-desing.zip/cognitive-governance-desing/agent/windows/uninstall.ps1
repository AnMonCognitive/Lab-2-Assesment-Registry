# Desinstala el agente de inventario de IA · Lab 2 del usuario actual.
$ErrorActionPreference = 'Stop'
Unregister-ScheduledTask -TaskName 'Lab2 - Agente de inventario de IA' -Confirm:$false -ErrorAction SilentlyContinue
Remove-Item (Join-Path $env:LOCALAPPDATA 'Lab2Agent') -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'Agente desinstalado. El equipo quedará como "sin reportar" en la consola.'
