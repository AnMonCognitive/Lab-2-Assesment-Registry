<#
  Agente de inventario de IA · Lab 2 (Windows, PowerShell 5.1+)

  Envía a la consola la lista de software del equipo para detectar herramientas de IA.
  Qué recoge (solo nombres e identificadores de software):
    - programas instalados y apps de la Microsoft Store
    - extensiones de Chrome, Edge y Brave
    - extensiones de VS Code, Cursor y Windsurf
    - nombres de procesos en ejecución
  Qué NO recoge: contenido de archivos, historial de navegación, pantallas, teclas ni documentos.

  Uso:  lab2-agent.ps1                 (lee config.json junto al script y envía)
        lab2-agent.ps1 -DryRun         (no envía; guarda en payload.json lo que se enviaría)
#>
param(
  [string]$ConfigPath = (Join-Path $PSScriptRoot 'config.json'),
  [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
$AgentVersion = '0.1.0'
$LogPath = Join-Path $PSScriptRoot 'agent.log'

function Write-Log([string]$msg) {
  $line = '{0:yyyy-MM-dd HH:mm:ss}  {1}' -f (Get-Date), $msg
  $old = @()
  if (Test-Path $LogPath) { $old = @(Get-Content $LogPath -Tail 199) }
  Set-Content -Path $LogPath -Value ($old + $line) -Encoding UTF8
}

$cfg = Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
$items = New-Object System.Collections.Generic.List[object]
function Add-Item([string]$kind, [string]$name, [string]$id) {
  if ($name -and $name.Trim()) {
    $items.Add([ordered]@{ kind = $kind; name = $name.Trim(); identifier = $(if ($id) { $id } else { $null }) })
  }
}

# ------------------------------------------------------------------ 1. programas instalados
$uninstallKeys = @(
  'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
  'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
  'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
)
foreach ($k in $uninstallKeys) {
  Get-ItemProperty $k -ErrorAction SilentlyContinue |
    Where-Object { $_.DisplayName -and -not $_.SystemComponent } |
    ForEach-Object { Add-Item 'app' $_.DisplayName $null }
}

# Apps de la Microsoft Store (ChatGPT, Copilot y otras se instalan así). "OpenAI.ChatGPT-Desktop" -> "OpenAI ChatGPT Desktop"
try {
  Get-AppxPackage -ErrorAction Stop |
    Where-Object { -not $_.IsFramework -and $_.SignatureKind -ne 'System' } |
    ForEach-Object { Add-Item 'app' ($_.Name -replace '[._-]', ' ') $_.Name }
} catch { }

# ------------------------------------------------------------------ 2. extensiones de navegador
function Resolve-ExtName($manifest, [string]$dir) {
  $name = [string]$manifest.name
  if ($name -match '^__MSG_(.+)__$') {
    $key = $Matches[1]
    $locales = @($manifest.default_locale, 'es', 'en', 'en_US') | Where-Object { $_ }
    foreach ($loc in $locales) {
      $file = Join-Path $dir "_locales\$loc\messages.json"
      if (Test-Path $file) {
        $msgs = Get-Content $file -Raw -Encoding UTF8 | ConvertFrom-Json
        $prop = $msgs.PSObject.Properties | Where-Object { $_.Name -ieq $key } | Select-Object -First 1
        if ($prop) { return [string]$prop.Value.message }
      }
    }
  }
  return $name
}

$browsers = @(
  "$env:LOCALAPPDATA\Google\Chrome\User Data",
  "$env:LOCALAPPDATA\Microsoft\Edge\User Data",
  "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data"
)
foreach ($root in $browsers) {
  if (-not (Test-Path $root)) { continue }
  Get-ChildItem $root -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' } |
    ForEach-Object {
      $extRoot = Join-Path $_.FullName 'Extensions'
      if (-not (Test-Path $extRoot)) { return }
      Get-ChildItem $extRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        $extId = $_.Name
        $verDir = Get-ChildItem $_.FullName -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
        if (-not $verDir) { return }
        try {
          $m = Get-Content (Join-Path $verDir.FullName 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
          Add-Item 'extension' (Resolve-ExtName $m $verDir.FullName) $extId
        } catch { }
      }
    }
}

# ------------------------------------------------------------------ 3. extensiones de editores de código
foreach ($editor in @('.vscode', '.cursor', '.windsurf')) {
  $extRoot = Join-Path $env:USERPROFILE "$editor\extensions"
  if (-not (Test-Path $extRoot)) { continue }
  Get-ChildItem $extRoot -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    $pkg = Join-Path $_.FullName 'package.json'
    if (-not (Test-Path $pkg)) { return }
    try {
      $p = Get-Content $pkg -Raw -Encoding UTF8 | ConvertFrom-Json
      $extId = ("{0}.{1}" -f $p.publisher, $p.name).ToLower()
      $display = [string]$p.displayName
      if (-not $display -or $display -match '^%.*%$') { $display = $extId }
      Add-Item 'vscode' $display $extId
    } catch { }
  }
}

# ------------------------------------------------------------------ 4. procesos en ejecución (solo el nombre)
Get-Process -ErrorAction SilentlyContinue | Select-Object -ExpandProperty ProcessName -Unique |
  ForEach-Object { Add-Item 'process' $_ $null }

# ------------------------------------------------------------------ envío
$osName = try { (Get-CimInstance Win32_OperatingSystem).Caption -replace '^Microsoft\s+', '' } catch { 'Windows' }
$personName = $cfg.PersonName
if (-not $personName) {
  try { $personName = ([adsi]"WinNT://$env:USERDOMAIN/$env:USERNAME,user").FullName.ToString() } catch { }
}
$report = [ordered]@{
  hostname      = $env:COMPUTERNAME
  os            = $osName
  user          = "$env:USERDOMAIN\$env:USERNAME"
  person_name   = $(if ($personName) { $personName } else { $null })
  area          = $(if ($cfg.Area) { $cfg.Area } else { $null })
  agent_version = $AgentVersion
  items         = $items
}
$json = $report | ConvertTo-Json -Depth 4 -Compress

if ($DryRun) {
  $out = Join-Path $PSScriptRoot 'payload.json'
  Set-Content -Path $out -Value $json -Encoding UTF8
  $items | Group-Object { $_.kind } | ForEach-Object { '{0,-10} {1}' -f $_.Name, $_.Count }
  "Sin enviar. Reporte completo en: $out"
  return
}

try {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $r = Invoke-RestMethod -Method Post -Uri ($cfg.ServerUrl.TrimEnd('/') + '/api/agent/report') `
    -Headers @{ Authorization = "Bearer $($cfg.Token)" } -ContentType 'application/json; charset=utf-8' `
    -Body ([Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 60
  Write-Log ("OK  {0} elementos · {1} herramientas de IA · {2} desconocidos" -f $items.Count, $r.herramientas_ia, $r.desconocidos)
  $r
} catch {
  Write-Log ("ERROR  {0}" -f $_.Exception.Message)
  throw
}
