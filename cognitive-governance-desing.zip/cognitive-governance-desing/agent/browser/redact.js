/*
  Gobernanza IA · ocultamiento de datos sensibles en los prompts

  Se usa en dos lados (por eso es un script clásico que se cuelga de globalThis y no un módulo):
    - content.js, ANTES de mandar el prompt: el dato real nunca sale de la página hacia la extensión.
    - background.js, al guardar y al limpiar prompts viejos: segunda pasada por si algo llegó sin ocultar.

  Cada dato encontrado se reemplaza por una etiqueta ([EMAIL], [TARJETA], …) y se cuenta por tipo,
  para que el registro muestre QUÉ tipo de dato se intentó compartir sin guardar el dato.
  Los números (tarjeta, CLABE, IBAN) se validan con su dígito verificador para no ocultar cualquier cifra.
*/
(() => {
  // --- Diccionario de términos de la empresa ----------------------------------
  // Palabras o frases propias de la organización que deben ocultarse además de la PII genérica:
  // nombres de clientes, códigos de proyecto, "CONFIDENCIAL", nombres clave internos, etc.
  // Se cargan por orden de prioridad: política de empresa (chrome.storage.managed.orgTerms) >
  // almacenamiento local (chrome.storage.local.orgTerms, útil para pruebas) > esta lista por defecto.
  // Lo ideal es que IT los fije por política; así se cambian para toda la flota sin reempaquetar.
  const DEFAULT_ORG_TERMS = [
    // "Acme S.A. de C.V.", "Proyecto Zeus", "CONFIDENCIAL", "codigo-cliente-123",
  ];
  const escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  // Regla dinámica construida con los términos de la empresa (o null si no hay ninguno).
  let orgRule = null;
  function setTerms(terms) {
    const list = (Array.isArray(terms) ? terms : [])
      .map((t) => String(t).trim())
      .filter((t) => t.length >= 3)            // evita términos demasiado cortos (ruido / sobre-ocultado)
      .filter((t, i, a) => a.indexOf(t) === i) // sin duplicados
      .sort((a, b) => b.length - a.length)     // el más largo primero ("Proyecto Zeus" antes que "Zeus")
      .slice(0, 2000);                         // tope de seguridad
    if (!list.length) { orgRule = null; return; }
    try {
      orgRule = { tag: "CONFIDENCIAL", re: new RegExp(`(?:${list.map(escapeRe).join("|")})`, "gi") };
    } catch {
      orgRule = null; // si algún término rompe el patrón, se desactiva en vez de fallar
    }
  }

  const digits = (s) => s.replace(/\D/g, "");

  function luhn(num) {
    let sum = 0;
    for (let i = 0; i < num.length; i++) {
      let d = Number(num[num.length - 1 - i]);
      if (i % 2) { d *= 2; if (d > 9) d -= 9; }
      sum += d;
    }
    return sum % 10 === 0;
  }

  // CLABE (México): 18 dígitos, pesos 3-7-1 sobre los primeros 17.
  function clabe(num) {
    const w = [3, 7, 1];
    let sum = 0;
    for (let i = 0; i < 17; i++) sum += (Number(num[i]) * w[i % 3]) % 10;
    return (10 - (sum % 10)) % 10 === Number(num[17]);
  }

  // IBAN: módulo 97 = 1.
  function iban(raw) {
    const s = raw.replace(/\s/g, "").toUpperCase();
    const moved = s.slice(4) + s.slice(0, 4);
    let rest = 0;
    for (const ch of moved) {
      const v = /\d/.test(ch) ? ch : String(ch.charCodeAt(0) - 55);
      for (const d of v) rest = (rest * 10 + Number(d)) % 97;
    }
    return rest === 1;
  }

  // Orden importante: primero lo más específico, para que una clave no termine marcada como teléfono.
  const RULES = [
    { tag: "CLAVE_PRIVADA", re: /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?(-----END [A-Z ]*PRIVATE KEY-----|$)/g },
    { tag: "TOKEN", re: /\beyJ[\w-]{10,}\.[\w-]{10,}\.[\w-]{10,}/g },
    { tag: "CLAVE_API", re: /\b(sk-(?:proj-|ant-|live-)?[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_\w{20,}|xox[abprs]-[\w-]{10,}|AIza[0-9A-Za-z_-]{35}|[rs]k_(?:live|test)_[0-9a-zA-Z]{20,}|glpat-[\w-]{20,})\b/g },
    { tag: "TOKEN", re: /\b((?:Bearer|Basic)\s+)[A-Za-z0-9._~+/=-]{16,}/gi, keep: 1 },
    // Usuario:contraseña dentro de una dirección (postgres://usuario:clave@servidor).
    { tag: "CONTRASEÑA", re: /\b([a-z][\w+.-]*:\/\/[^\s:@/]+:)[^\s@/]+(?=@)/gi, keep: 1 },
    // "password: xxx", "contraseña = xxx", "api_key: xxx", "mi contraseña es xxx".
    { tag: "CONTRASEÑA", re: /\b((?:password|passwd|pwd|contrase[ñn]a|clave de acceso|secret|token|api[_ -]?key|pin)\s*(?:[:=]|\bes\b|\bis\b)\s*)("[^"]+"|'[^']+'|\S+)/gi, keep: 1 },
    { tag: "EMAIL", re: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g },
    { tag: "CURP", re: /\b[A-Z][AEIOUX][A-Z]{2}\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[HMX](?:AS|BC|BS|CC|CL|CM|CS|CH|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS|NE)[B-DF-HJ-NP-TV-Z]{3}[A-Z\d]\d\b/gi },
    { tag: "RFC", re: /\b[A-ZÑ&]{3,4}\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])[A-Z\d]{2}[A\d]\b/gi },
    { tag: "IBAN", re: /\b[A-Z]{2}\d{2}(?: ?[A-Z0-9]{4}){3,7}(?: ?[A-Z0-9]{1,4})?\b/g, check: iban },
    { tag: "CLABE", re: /\b\d{3}[ -]?\d{3}[ -]?\d{11}[ -]?\d\b/g, check: (m) => digits(m).length === 18 && clabe(digits(m)) },
    { tag: "TARJETA", re: /\b\d(?:[ -]?\d){12,18}\b/g, check: (m) => luhn(digits(m)) },
    { tag: "SSN", re: /\b\d{3}-\d{2}-\d{4}\b/g },
    { tag: "NSS", re: /\b((?:nss|imss|n[uú]mero de seguro social)\W{0,5})\d{11}\b/gi, keep: 1 },
    { tag: "IP", re: /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g },
    // Teléfonos: 10 a 13 dígitos con o sin separadores (+52 55 1234 5678, (55) 1234-5678, 5512345678).
    { tag: "TELÉFONO", re: /(?<![\w+])\+?\d[\d\s().-]{8,17}\d(?!\w)/g, check: (m) => { const n = digits(m).length; return n >= 10 && n <= 13; } },
  ];

  /** Devuelve { text, found } con los datos sensibles reemplazados y la cuenta por tipo. */
  function redact(input) {
    let text = String(input ?? "");
    const found = {};
    // Los términos de la empresa se aplican al final, sobre lo que la PII genérica no haya ocultado.
    const rules = orgRule ? [...RULES, orgRule] : RULES;
    for (const { tag, re, check, keep } of rules) {
      text = text.replace(re, (m, ...groups) => {
        if (check && !check(m)) return m;
        found[tag] = (found[tag] ?? 0) + 1;
        return `${keep ? groups[keep - 1] : ""}[${tag}]`;
      });
    }
    return { text, found };
  }

  globalThis.GobernanzaRedact = { redact, setTerms };

  // Carga de términos: política de empresa > almacenamiento local > lista por defecto. Se recarga si cambian.
  // redact() es síncrono y usa el último conjunto cargado; la carga desde el almacenamiento es casi instantánea.
  async function loadOrgTerms() {
    let terms = DEFAULT_ORG_TERMS;
    try {
      const managed = await chrome.storage.managed.get("orgTerms");
      if (Array.isArray(managed?.orgTerms) && managed.orgTerms.length) {
        terms = managed.orgTerms;
      } else {
        const local = await chrome.storage.local.get("orgTerms");
        if (Array.isArray(local?.orgTerms)) terms = local.orgTerms;
      }
    } catch {
      // chrome.storage.managed puede no existir sin política: se usan local / por defecto.
    }
    setTerms(terms);
  }
  try {
    setTerms(DEFAULT_ORG_TERMS); // algo útil de inmediato, antes de que llegue el almacenamiento
    loadOrgTerms();
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "managed" || (area === "local" && changes.orgTerms)) loadOrgTerms();
    });
  } catch {
    // Contexto sin chrome.storage: queda solo la PII genérica.
  }
})();
