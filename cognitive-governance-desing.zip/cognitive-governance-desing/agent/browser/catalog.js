/*
  Catálogo de herramientas de IA en uso (única fuente para background, popup y advertencia).

  Se arma con:
    1. ai_domains.js -> lista fija de dominios de herramientas de IA incluida en la extensión.
    2. storage.local.detected -> sitios que el detector automático marcó como IA (ver detector.js y
       background.js). Entran como herramientas "auto:<host>" con categoría "detectada", salvo que ya estén
       en el catálogo o en la lista de ignorados.
  El manifest no tiene dominios: las reglas de advertencia y los content scripts se generan desde aquí
  (ver syncCatalog en background.js), así que agregar una herramienta no requiere publicar otra versión.

  La lista de ignorados (DEFAULT_IGNORE, más abajo) sirve para descartar falsos positivos del detector
  automático (sitios grandes con funciones de IA que no son herramientas de IA en sí).
*/
import { AI_TOOLS } from "./ai_domains.js";

// Dirección de la consola donde se reportan los sitios detectados automáticamente (POST JSON).
// Vacía = las detecciones solo quedan en este navegador.
export const DETECTIONS_URL = "";

// Sitios grandes que tienen funciones de IA o cajas de chat pero no son herramientas de IA en sí.
// El detector no los marca. La consola puede agregar más con "ignore".
const DEFAULT_IGNORE = [
  "google.com", "bing.com", "duckduckgo.com", "yahoo.com", "youtube.com",
  "facebook.com", "instagram.com", "whatsapp.com", "messenger.com", "x.com", "twitter.com", "linkedin.com",
  "microsoft.com", "office.com", "live.com", "outlook.com", "github.com", "gitlab.com",
  "slack.com", "zoom.us", "teams.microsoft.com", "notion.so", "atlassian.net", "amazon.com",
];

const DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;

const normHost = (h) => String(h).toLowerCase().trim().replace(/^www\./, "").replace(/\.$/, "");

/** Limpia y valida una lista de herramientas. Lo que no cumple el formato se descarta. */
function clean(list) {
  if (!Array.isArray(list)) return [];
  const seen = new Set();
  const tools = [];
  for (const t of list) {
    if (!t || typeof t.id !== "string" || !t.id || seen.has(t.id)) continue;
    const domains = (Array.isArray(t.domains) ? t.domains : []).map(normHost).filter((d) => DOMAIN_RE.test(d));
    if (!domains.length) continue;
    seen.add(t.id);
    tools.push({ id: t.id, name: typeof t.name === "string" && t.name ? t.name : t.id,
      category: typeof t.category === "string" ? t.category : null, domains, auto: t.auto === true });
  }
  return tools;
}

/** Lista de ignorados vigente (incluida + la de la consola). */
export function makeIgnore(extra = []) {
  const list = [...DEFAULT_IGNORE, ...(Array.isArray(extra) ? extra : [])].map(normHost).filter((d) => DOMAIN_RE.test(d));
  return (host) => {
    const h = normHost(host);
    return list.some((d) => h === d || h.endsWith(`.${d}`));
  };
}

/** Herramientas vigentes y función de ignorados: catálogo (descargado o incluido) + detectadas. */
export async function getCatalog() {
  const { catalog, detected = {} } = await chrome.storage.local.get(["catalog", "detected"]);
  const remote = clean(catalog?.tools);
  const base = remote.length ? remote : clean(AI_TOOLS);
  const isIgnored = makeIgnore(catalog?.ignore);
  const known = indexCatalog(base);
  const auto = Object.keys(detected)
    .filter((h) => !known.findTool(h) && !isIgnored(h))
    .map((h) => ({ id: `auto:${h}`, name: h, category: "detectada", domains: [h], auto: true }));
  return { tools: [...base, ...clean(auto)], isIgnored };
}

/** Índices para buscar rápido. findTool acepta una dirección completa o solo el host. */
export function indexCatalog(tools) {
  const byId = new Map(tools.map((t) => [t.id, t]));
  const byDomain = new Map(tools.flatMap((t) => t.domains.map((d) => [d, t])));

  function findTool(urlOrHost) {
    let host = urlOrHost || "";
    if (host.includes("://")) {
      try {
        const u = new URL(host);
        if (u.protocol !== "https:" && u.protocol !== "http:") return null;
        host = u.hostname;
      } catch {
        return null;
      }
    }
    host = normHost(host);
    // Se busca del host completo hacia arriba: auth.chatgpt.com -> chatgpt.com -> com
    const parts = host.split(".");
    for (let i = 0; i < parts.length - 1; i++) {
      const domain = parts.slice(i).join(".");
      const tool = byDomain.get(domain);
      if (tool) return { tool, domain };
    }
    return null;
  }

  return { tools, byId, byDomain, findTool };
}

/** true si el host es un dominio público válido (no localhost, IPs ni intranet sin punto). */
export const isPublicHost = (host) => DOMAIN_RE.test(normHost(host)) && !/^\d+(\.\d+){3}$/.test(host);

/** Avisa a la consola de un sitio detectado automáticamente. Solo el host y las señales, nunca contenido. */
export async function reportDetection(host, entry) {
  if (!DETECTIONS_URL) return;
  try {
    await fetch(DETECTIONS_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ host, score: entry.score, signals: entry.signals, first: entry.first, last: entry.last }),
    });
  } catch (e) {
    console.warn(`[Gobernanza IA] No se pudo reportar la detección de ${host}: ${e.message}`);
  }
}
