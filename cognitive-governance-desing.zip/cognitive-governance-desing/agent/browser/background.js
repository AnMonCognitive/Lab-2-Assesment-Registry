/*
  Gobernanza IA · detección de sitios de IA (Chrome, Edge y Brave; Manifest V3)

  Cada vez que una pestaña cambia de dirección, se compara su dominio contra el catálogo (catalog.js).
  Si entra a una herramienta de IA:
    - se cuenta una visita del día            -> storage.local.usage     { día: { toolId: { visits } } }
    - se actualiza el inventario de la persona -> storage.local.inventory { toolId: { first, last, days, visits, domains } }
    - se marca la pestaña con "IA"
  Qué NO se guarda: direcciones completas, rutas, títulos ni contenido. La dirección se descarta en el acto.
*/
import { getCatalog, indexCatalog, isPublicHost, reportDetection } from "./catalog.js";
import "./redact.js"; // deja globalThis.GobernanzaRedact

const { redact } = globalThis.GobernanzaRedact;

const PROMPT_KEEP_DAYS = 30;   // los prompts se borran solos del navegador después de este tiempo
const PROMPT_MAX = 2000;       // tope de prompts guardados (evita que el almacenamiento crezca sin fin)
// ------------------------------------------------------------------ configuración de envío a la consola
// serverUrl, token y hostname llegan por POLÍTICA ADMINISTRADA (install-policy.ps1 pone hostname = %COMPUTERNAME%
// por equipo, para que la consola una este reporte con el del agente de Windows del mismo equipo). Para pruebas
// se pueden poner en chrome.storage.local.config. Sin los tres, la extensión no envía: queda como recolector local.
const UPLOAD_PATH = "/api/agent/prompt-events"; // endpoint DLP del central (Lab 2)
const UPLOAD_BATCH = 50;          // máximo de eventos por envío
const UPLOAD_RETRY_MIN = 5;       // cada cuántos minutos se reintenta vaciar la cola
const DELETE_AFTER_UPLOAD = true; // true: borra el evento local al confirmarse; false: lo marca { sent: true }

/** La política administrada manda; la config local solo sirve para pruebas. Igual que la extensión de Lab 2. */
async function getConfig() {
  let managed = {};
  try { managed = await chrome.storage.managed.get(null); } catch { /* sin política */ }
  const { config: local = {} } = await chrome.storage.local.get("config");
  // orgTerms también viaja por managed, pero es del diccionario (redact.js), no de la config de envío.
  const set = Object.fromEntries(Object.entries(managed).filter(([k, v]) => k !== "orgTerms" && v));
  const c = { ...local, ...set };
  return { ...c, ready: Boolean(c.serverUrl && c.token && c.hostname) };
}

const OS_NAMES = { win: "Windows", mac: "macOS", linux: "Linux", cros: "ChromeOS", openbsd: "OpenBSD", android: "Android" };
async function osName() {
  try { const p = await chrome.runtime.getPlatformInfo(); return OS_NAMES[p.os] ?? p.os; } catch { return "?"; }
}
function browserName() {
  if (navigator.brave) return "brave";
  const brands = navigator.userAgentData?.brands?.map((b) => b.brand) ?? [];
  return brands.some((b) => /edge/i.test(b)) ? "edge" : "chrome";
}

// El catálogo se lee del almacenamiento al despertar el service worker. Todo lo que lo usa espera a `ready`.
let catalog = indexCatalog([]);
let isIgnored = () => false;
let ready = loadCatalog();
async function loadCatalog() {
  const current = await getCatalog();
  catalog = indexCatalog(current.tools);
  isIgnored = current.isIgnored;
}

/** Devuelve { tool, domain } si la dirección es de una herramienta de IA, o null. Requiere `await ready`. */
export function detectAI(url) {
  return catalog.findTool(url);
}

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// Los eventos llegan en paralelo: todo lo que lee y luego escribe el almacenamiento va en fila,
// para que dos eventos seguidos (p. ej. una redirección) no lean el mismo estado y cuenten doble.
let queue = Promise.resolve();
const serial = (fn) => (queue = queue.then(fn, fn));

/** Suma una visita al día y al inventario. Debe llamarse dentro de serial(). */
async function recordVisit({ tool, domain }) {
  const day = today();
  const { usage = {}, inventory = {} } = await chrome.storage.local.get(["usage", "inventory"]);

  const row = ((usage[day] ??= {})[tool.id] ??= { visits: 0 });
  row.visits += 1;

  const inv = (inventory[tool.id] ??= { first: day, last: day, days: 1, visits: 0, domains: [] });
  if (inv.last !== day) { inv.days += 1; inv.last = day; }
  inv.visits += 1;
  if (!inv.domains.includes(domain)) inv.domains.push(domain);

  await chrome.storage.local.set({ usage, inventory });
}

function setBadge(tabId, hit) {
  chrome.action.setBadgeText({ tabId, text: hit ? "IA" : "" }).catch(() => {});
  if (hit) {
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#d93025" }).catch(() => {});
    chrome.action.setTitle({ tabId, title: `Sitio de IA: ${hit.tool.name}` }).catch(() => {});
  } else {
    chrome.action.setTitle({ tabId, title: "Gobernanza IA" }).catch(() => {});
  }
}

// Visita = la pestaña ENTRA a una herramienta de IA. Moverse dentro de la misma herramienta (aunque cambie de
// dominio, como chat.openai.com -> chatgpt.com) no cuenta otra vez.
// La última herramienta por pestaña va en storage.session porque el service worker se duerme seguido.
async function onUrl(tabId, url) {
  await ready;
  const hit = detectAI(url);
  setBadge(tabId, hit);
  // Al salir de la herramienta (a otro sitio o a la advertencia), se quita el permiso de la pestaña:
  // la próxima entrada vuelve a mostrar el aviso.
  if (!hit) revokeTab(tabId);
  return serial(async () => {
    const key = `tab${tabId}`;
    const prev = (await chrome.storage.session.get(key))[key] ?? null;
    const current = hit?.tool.id ?? null;
    if (current === prev) return;
    if (!hit) return chrome.storage.session.remove(key);
    await chrome.storage.session.set({ [key]: current });
    await recordVisit(hit);
    console.log(`[Gobernanza IA] Entrada a ${hit.tool.name} (${hit.domain})`);
  });
}

chrome.tabs.onUpdated.addListener((tabId, change, tab) => {
  if (change.url) onUrl(tabId, change.url);
  // Al recargar, el navegador borra la marca de la pestaña: se vuelve a poner sin contar otra visita.
  else if (change.status === "complete" && tab.url) ready.then(() => setBadge(tabId, detectAI(tab.url)));
});

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.session.remove([`tab${tabId}`, `sig${tabId}`]);
  revokeTab(tabId);
});

// Al instalar o arrancar, marcar las pestañas que ya estaban abiertas (sin contarlas como visita).
async function markOpenTabs() {
  await ready;
  for (const tab of await chrome.tabs.query({})) {
    const hit = tab.url && detectAI(tab.url);
    if (!hit) continue;
    setBadge(tab.id, hit);
    await chrome.storage.session.set({ [`tab${tab.id}`]: hit.tool.id });
  }
}

/*
  Migración desde la versión 0.0.1, que contaba por dominio: { día: { "chat.openai.com": { category, visits } } }.
  Se pasa a conteo por herramienta y, si aún no hay inventario, se arma con el historial que ya existía.
*/
const migrate = () => serial(async () => {
  await ready;
  const { usage = {}, inventory } = await chrome.storage.local.get(["usage", "inventory"]);
  let changed = false;
  for (const [day, rows] of Object.entries(usage)) {
    const next = {};
    for (const [key, v] of Object.entries(rows)) {
      const tool = catalog.byDomain.get(key);
      const id = tool ? tool.id : key;  // ya era un id de herramienta, o un dominio que ya no está en la lista
      if (tool || "category" in v) changed = true;
      (next[id] ??= { visits: 0, domains: [] }).visits += v.visits ?? 0;
      if (tool) next[id].domains.push(key);
    }
    usage[day] = next;
  }
  const inv = inventory ?? {};
  if (!inventory) {
    for (const day of Object.keys(usage).sort()) {
      for (const [id, v] of Object.entries(usage[day])) {
        const e = (inv[id] ??= { first: day, last: day, days: 0, visits: 0, domains: [] });
        e.last = day; e.days += 1; e.visits += v.visits;
        for (const d of v.domains ?? []) if (!e.domains.includes(d)) e.domains.push(d);
      }
    }
    changed = true;
  }
  for (const rows of Object.values(usage)) for (const v of Object.values(rows)) delete v.domains;
  if (changed) await chrome.storage.local.set({ usage, inventory: inv });
});

// Al instalar o actualizar se normaliza el historial a la política actual:
//   1. Se re-ocultan datos en prompts viejos (por si se guardaron sin enmascarar).
//   2. Se CONSERVAN solo los que tienen datos sensibles (o que pasaron por la advertencia); los demás,
//      guardados por una versión anterior que registraba todo, se descartan.
const redactStoredPrompts = () => serial(async () => {
  const { prompts = [] } = await chrome.storage.local.get("prompts");
  if (!prompts.length) return;
  const kept = [];
  for (const p of prompts) {
    const { text, found } = redact(p.text);
    p.text = text;
    p.sensitive = mergeCounts(p.sensitive, found);
    if (Object.keys(p.sensitive).length || p.decision) {
      if (!Object.keys(p.sensitive).length) delete p.sensitive;
      kept.push(p);
    }
  }
  if (kept.length !== prompts.length || kept.some((p, i) => p !== prompts[i])) {
    await chrome.storage.local.set({ prompts: kept });
  }
});

// Limpia del historial las detecciones automáticas que ya no corresponden: host ahora ignorado, o host que
// pasó a estar en el catálogo (p. ej. deepseek.com, que el detector marcó como "auto:" antes de volverse un
// dominio de la herramienta DeepSeek). Solo toca entradas "auto:<host>"; las del catálogo no se tocan.
const cleanStaleAuto = () => serial(async () => {
  await ready;
  const stale = (host) => isIgnored(host) || !!catalog.findTool(host);
  const { detected = {}, inventory = {}, usage = {} } = await chrome.storage.local.get(["detected", "inventory", "usage"]);
  let changed = false;
  for (const host of Object.keys(detected)) if (stale(host)) { delete detected[host]; changed = true; }
  for (const id of Object.keys(inventory)) if (id.startsWith("auto:") && stale(id.slice(5))) { delete inventory[id]; changed = true; }
  for (const day of Object.keys(usage)) for (const id of Object.keys(usage[day])) {
    if (id.startsWith("auto:") && stale(id.slice(5))) { delete usage[day][id]; changed = true; }
  }
  if (changed) await chrome.storage.local.set({ detected, inventory, usage });
});

chrome.runtime.onInstalled.addListener(() => { migrate(); markOpenTabs(); redactStoredPrompts(); cleanStaleAuto(); });
chrome.runtime.onStartup.addListener(markOpenTabs);

// ------------------------------------------------------------------ registro de prompts
// El content script (content.js) revisa el prompt al enviarlo en una herramienta de IA. Los datos sensibles
// ya vienen reemplazados por etiquetas (redact.js) y aquí se vuelve a pasar por redact() por si algo llegó
// sin ocultar.
//
// REGLA DE GUARDADO: solo se guarda el prompt si CONTENÍA datos sensibles (o si el usuario pasó por la
// advertencia y decidió "enviado"/"ocultado"). Los mensajes sin datos sensibles se leen para revisarlos y
// se descartan: NUNCA se guardan. Lo que se guarda es el texto ya enmascarado, con fecha, hora y los TIPOS
// de datos detectados (sensitive: { EMAIL: 1, TARJETA: 2 }), nunca el dato real. El aviso al usuario lo
// muestra el content script en la propia página.

/** Suma conteos por tipo. Solo acepta etiquetas en mayúsculas con números (lo que manda la página no es confiable). */
function mergeCounts(...sources) {
  const out = {};
  for (const src of sources) {
    for (const [tag, n] of Object.entries(src ?? {})) {
      if (/^[A-ZÑÉ_]{2,20}$/.test(tag) && Number.isInteger(n) && n > 0) out[tag] = (out[tag] ?? 0) + n;
    }
  }
  return out;
}

function savePrompt(host, raw, reported, decision) {
  return serial(async () => {
    await ready;
    const tool = catalog.findTool(host)?.tool;
    if (!tool || !raw) return;
    const { text, found } = redact(raw);
    const sensitive = mergeCounts(reported, found);
    const warned = decision === "enviado" || decision === "ocultado";
    // Protección, no archivo: si el mensaje NO tenía datos sensibles, se descarta sin guardar nada.
    // (Si pasó por la advertencia, `sensitive` ya trae los tipos detectados, así que también entra aquí.)
    if (!Object.keys(sensitive).length) {
      console.log(`[Gobernanza IA] Mensaje en ${tool.name} sin datos sensibles: revisado y descartado (no se guarda).`);
      return;
    }
    const now = new Date();
    const day = today();
    const { prompts = [] } = await chrome.storage.local.get("prompts");
    prompts.push({ id: `${now.getTime()}-${Math.random().toString(36).slice(2, 7)}`,
      toolId: tool.id, host, day, time: now.toISOString(), text, sensitive, sent: false,
      // Si pasó por la advertencia de datos sensibles: "enviado" (de todos modos) u "ocultado" (se quitaron).
      ...(warned ? { decision } : {}) });
    // Retención: se quitan los más viejos que PROMPT_KEEP_DAYS y se respeta el tope PROMPT_MAX.
    const limit = new Date(now - PROMPT_KEEP_DAYS * 86400000).toISOString().slice(0, 10);
    let kept = prompts.filter((p) => p.day >= limit);
    if (kept.length > PROMPT_MAX) kept = kept.slice(kept.length - PROMPT_MAX);
    await chrome.storage.local.set({ prompts: kept });
    console.log(`[Gobernanza IA] Prompt con datos sensibles registrado en ${tool.name} (${text.length} caracteres)`);
  });
}

// ------------------------------------------------------------------ envío a la consola (outbox)
// Los eventos con datos sensibles se guardan con { sent: false } y se mandan a la consola (Lab 2) con el patrón
// enviar -> confirmar -> borrar: solo cuando responde OK se borran (o se marcan como enviados). Si no hay red o
// la consola falla, la cola se conserva y se reintenta en la próxima alarma, sin perder datos. Sin configuración
// (serverUrl/token/hostname), no se envía nada y la extensión funciona como recolector local.
// Contrato: POST /api/agent/prompt-events, autenticado con el token de organización (mismo del agente de Windows).

// Un solo envío a la vez: dos vaciados en paralelo mandarían el mismo lote dos veces.
let uploading = false;
async function flushOutbox() {
  if (uploading) return;
  const cfg = await getConfig();
  if (!cfg.ready) return; // sin serverUrl/token/hostname: recolector local
  uploading = true;
  try {
    await ready;
    const url = cfg.serverUrl.replace(/\/+$/, "") + UPLOAD_PATH;
    const os = await osName();
    const browser = browserName();
    const extVersion = chrome.runtime.getManifest().version;
    for (;;) {
      const { prompts = [] } = await chrome.storage.local.get("prompts");
      const pending = prompts.filter((p) => !p.sent);
      if (!pending.length) break;
      const batch = pending.slice(0, UPLOAD_BATCH);

      // Contrato de Lab 2 (ingest.PromptEventsReport): identidad por hostname; cada evento lleva su host.
      const payload = {
        hostname: cfg.hostname,
        os,
        user: cfg.user || null,
        area: cfg.area || null,
        browser,
        extension_version: extVersion,
        events: batch.map((p) => ({
          id: p.id,                     // clave de idempotencia: la consola no lo guarda dos veces
          host: p.host || "",           // la consola resuelve la herramienta por dominio (match_domain)
          day: p.day,
          time: p.time,
          text: p.text,                 // ya enmascarado (redact.js): el dato real nunca sale
          sensitive: p.sensitive ?? {}, // tipos detectados, p. ej. { EMAIL: 1, TARJETA: 2 }
          decision: p.decision ?? null, // "enviado" | "ocultado" | null
        })),
      };

      let res;
      try {
        res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${cfg.token}` },
          body: JSON.stringify(payload),
        });
      } catch (e) {
        console.warn(`[Gobernanza IA] Envío fallido (red): ${e.message}. Se reintentará.`);
        break;
      }
      if (!res.ok) {
        console.warn(`[Gobernanza IA] Envío rechazado por la consola: HTTP ${res.status}. Se reintentará.`);
        break;
      }

      // Confirmado: borrar (o marcar) los enviados. Se relee dentro de serial() por si llegó otro evento.
      const ids = new Set(batch.map((p) => p.id));
      await serial(async () => {
        const { prompts = [] } = await chrome.storage.local.get("prompts");
        const next = DELETE_AFTER_UPLOAD
          ? prompts.filter((p) => !ids.has(p.id))
          : prompts.map((p) => (ids.has(p.id) ? { ...p, sent: true } : p));
        await chrome.storage.local.set({ prompts: next });
      });
      console.log(`[Gobernanza IA] ${batch.length} evento(s) enviados a la consola.`);
      if (batch.length < UPLOAD_BATCH) break; // era la cola final
    }
  } finally {
    uploading = false;
  }
}

// ------------------------------------------------------------------ descargas de apps de IA de escritorio
// Avisa y CANCELA la descarga de instaladores de apps de IA de escritorio (ChatGPT, Claude, etc.). Solo
// cubre lo que se baja POR EL NAVEGADOR; si lo traen por USB o gestor de paquetes, eso lo cubre el bloqueo
// de apps del cliente (AppLocker/Intune).
// Heurística: es un instalador (.exe/.msi/.dmg/...) Y (el nombre coincide con una app de IA conocida O la
// descarga viene de un dominio de IA del catálogo).
const INSTALLER_RE = /\.(exe|msi|dmg|pkg|appimage|deb|rpm)(?:\?|#|$)/i;
const AI_APP_NAME_RE = /(chatgpt|claude|copilot|ollama|lm[\s._-]?studio|gpt4all|deepseek|perplexity|\bgrok\b|le[\s._-]?chat|mistral|cherry[\s._-]?studio|anythingllm|\bjan\b|msty)/i;

function isAiInstaller(url, filename) {
  const name = (filename || "").split(/[\\/]/).pop() || "";
  if (!INSTALLER_RE.test(name) && !INSTALLER_RE.test(url)) return false;
  if (AI_APP_NAME_RE.test(`${name} ${url}`)) return true;
  return !!detectAI(url);
}

chrome.downloads.onCreated.addListener((item) => {
  const url = item.finalUrl || item.url || "";
  ready.then(() => {
    if (!isAiInstaller(url, item.filename)) return;
    // Se PAUSA mientras la persona decide (no se cancela todavía).
    chrome.downloads.pause(item.id).catch(() => {});
    const fname = ((item.filename || url).split(/[\\/]/).pop() || "el instalador").split(/[?#]/)[0];
    askDownloadDecision(item.id, fname);
    console.log(`[Gobernanza IA] Descarga de app de IA de escritorio en pausa, esperando decisión: ${fname}`);
  });
});

async function askDownloadDecision(id, filename) {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab?.id) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: showDownloadChoiceNotice, args: [id, filename] });
      return;
    }
  } catch {
    // Página restringida o sin pestaña donde preguntar: no se puede mostrar el aviso.
  }
  // Si no se pudo preguntar, por seguridad (DLP) se cancela en vez de dejarla pasar en silencio.
  chrome.downloads.cancel(id).then(() => chrome.downloads.erase({ id }).catch(() => {})).catch(() => {});
}

// Se ejecuta DENTRO de la página: autocontenida, en shadow DOM. Manda la decisión al background por mensaje.
function showDownloadChoiceNotice(id, filename) {
  const ID = "cognitive-gobernanza-ia-descarga";
  if (document.getElementById(ID)) return;
  const wrap = document.createElement("div");
  wrap.id = ID;
  const root = wrap.attachShadow({ mode: "closed" });
  root.innerHTML = `
    <style>
      .bg { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center; justify-content: center;
        padding: 16px; background: rgba(0,0,0,.6); font: 15px/1.5 system-ui, "Segoe UI", sans-serif; color: #1f2328; }
      .card { max-width: 500px; width: 100%; background: #fff; border-top: 6px solid #d93025; border-radius: 10px;
        padding: 24px 26px; box-shadow: 0 10px 40px rgba(0,0,0,.35); box-sizing: border-box; }
      h1 { font-size: 20px; color: #d93025; margin: 0 0 8px; }
      p { margin: 0 0 8px; } .file { font-weight: 600; word-break: break-all; }
      .actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; margin-top: 16px; }
      button { font: 600 14px/1 system-ui, "Segoe UI", sans-serif; padding: 10px 14px; border-radius: 6px; cursor: pointer;
        border: 1px solid #c4c8cc; background: #fff; color: #1f2328; }
      button.primary { background: #d93025; border-color: #d93025; color: #fff; }
    </style>
    <div class="bg"><div class="card" role="alertdialog" aria-modal="true">
      <h1>Estás descargando una app de IA de escritorio</h1>
      <p class="file"></p>
      <p>Según la política de tu empresa, las herramientas de IA se usan desde el navegador, donde los datos sensibles están protegidos. Las apps de escritorio quedan fuera de esa protección.</p>
      <div class="actions">
        <button type="button" data-a="continue">Continuar con la instalación</button>
        <button type="button" class="primary" data-a="cancel">Cancelar descarga</button>
      </div>
    </div></div>`;
  root.querySelector(".file").textContent = filename;
  const block = (e) => {
    if (e.composedPath().includes(wrap)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  };
  const decide = (decision) => {
    try { chrome.runtime.sendMessage({ type: "downloadDecision", id, decision }); } catch {}
    wrap.remove();
    window.removeEventListener("keydown", block, true);
  };
  for (const b of root.querySelectorAll("button")) b.addEventListener("click", () => decide(b.dataset.a));
  window.addEventListener("keydown", block, true);
  (document.body || document.documentElement).appendChild(wrap);
  root.querySelector('[data-a="cancel"]').focus();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "prompt" && sender.tab) savePrompt(msg.host || "", String(msg.text || ""), msg.sensitive, msg.decision).then(flushOutbox);
  // La página de advertencia avisa que la persona aceptó: se deja pasar esa herramienta y luego navega.
  if (msg?.type === "allowTool" && sender.tab) {
    allowTool(msg.toolId, sender.tab.id).then(() => sendResponse(true), () => sendResponse(false));
    return true; // respuesta asíncrona
  }
  // Decisión del aviso de descarga de app de IA: continuar (reanuda) o cancelar.
  if (msg?.type === "downloadDecision" && Number.isInteger(msg.id)) {
    if (msg.decision === "continue") {
      chrome.downloads.resume(msg.id).catch(() => {});
      console.log(`[Gobernanza IA] Descarga reanudada por decisión del usuario (id ${msg.id}).`);
    } else {
      chrome.downloads.cancel(msg.id).then(() => chrome.downloads.erase({ id: msg.id }).catch(() => {})).catch(() => {});
      console.log(`[Gobernanza IA] Descarga cancelada por decisión del usuario (id ${msg.id}).`);
    }
  }
  // Señal del detector automático (detector.js), solo de la ventana principal.
  if (msg?.type === "aiSignal" && sender.tab && sender.frameId === 0 && sender.tab.url) {
    addSignal(sender.tab.id, sender.tab.url, String(msg.signal));
  }
});

// ------------------------------------------------------------------ catálogo dinámico
// Nada de dominios en el manifest: todo se arma aquí desde el catálogo vigente.
//  - Advertencia ANTES de entrar: una regla de declarativeNetRequest con todos los dominios redirige la
//    navegación principal (clic en un enlace, dirección escrita, favorito…) a warning.html antes de que salga
//    la petición al sitio de IA. La dirección original va después del "#" para continuar si la persona acepta.
//  - El aviso sale en CADA visita: al aceptar se agrega una regla de sesión de mayor prioridad que deja pasar
//    esa herramienta SOLO en esa pestaña, y se quita en cuanto la pestaña sale de la herramienta o se cierra
//    (revokeTab). Así, moverse dentro de la herramienta no repite el aviso, pero volver a entrar sí.
//  - Registro de prompts: content.js se registra solo en los dominios del catálogo.
//  - Detector automático: detector.js se registra en todos los demás sitios.
const REDIRECT_RULE = 1;     // id de la regla de redirección (dinámica)
const ALLOW_BASE = 1000;     // ids de las reglas de permiso (de sesión): 1000 + id de la pestaña
const SCRIPT_ID = "gobernanza-prompts";
const DETECTOR_ID = "gobernanza-detector";

async function upsertScript(script) {
  const registered = await chrome.scripting.getRegisteredContentScripts({ ids: [script.id] });
  if (registered.length) await chrome.scripting.updateContentScripts([script]);
  else await chrome.scripting.registerContentScripts([script]);
}

async function syncCatalog() {
  await loadCatalog();
  const domains = [...catalog.byDomain.keys()];

  const old = (await chrome.declarativeNetRequest.getDynamicRules()).map((r) => r.id);
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: old,
    addRules: domains.length ? [{
      id: REDIRECT_RULE,
      priority: 1,
      action: { type: "redirect", redirect: { regexSubstitution: `${chrome.runtime.getURL("warning.html")}#\\1` } },
      condition: { regexFilter: "^(https?://.*)$", requestDomains: domains, resourceTypes: ["main_frame"] },
    }] : [],
  });

  // Content script de registro de prompts, solo en los dominios del catálogo (y sus subdominios).
  const matches = domains.map((d) => `*://*.${d}/*`); // "*." cubre también el dominio sin subdominio
  if (matches.length) {
    await upsertScript({ id: SCRIPT_ID, matches, js: ["redact.js", "content.js"], css: ["content.css"], runAt: "document_idle" });
  } else if ((await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] })).length) {
    await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] });
  }

  // Detector automático en todos los demás sitios.
  await upsertScript({ id: DETECTOR_ID, matches: ["http://*/*", "https://*/*"],
    ...(matches.length ? { excludeMatches: matches } : {}), js: ["detector.js"], runAt: "document_idle" });

  console.log(`[Gobernanza IA] Catálogo aplicado: ${catalog.tools.length} herramientas, ${domains.length} dominios`);
}

async function allowTool(toolId, tabId) {
  await ready;
  const tool = catalog.byId.get(toolId);
  if (tool) await allowDomains(tabId, tool.domains);
}

function allowDomains(tabId, domains) {
  return chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [ALLOW_BASE + tabId],
    addRules: [{
      id: ALLOW_BASE + tabId,
      priority: 2,
      action: { type: "allow" },
      condition: { requestDomains: domains, resourceTypes: ["main_frame"], tabIds: [tabId] },
    }],
  });
}

function revokeTab(tabId) {
  chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [ALLOW_BASE + tabId] }).catch(() => {});
}

// Las sincronizaciones van en fila: dos a la vez intentarían registrar el mismo content script.
const resync = () => (ready = ready.then(syncCatalog, syncCatalog));

// Si llega un catálogo nuevo o se detecta un sitio, se vuelve a aplicar.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.detected) resync();
});

// ------------------------------------------------------------------ detección automática
// Sitios que no están en el catálogo pero se comportan como herramientas de IA. Cada señal suma puntos por
// pestaña y sitio; al llegar a DETECT_THRESHOLD el sitio queda en storage.local.detected
// { host: { first, last, score, signals } }, entra al catálogo como "auto:<host>" (con advertencia previa y
// registro de prompts desde la próxima entrada) y se reporta a la consola.
// Con DETECT_THRESHOLD = 2 basta UNA caja de chat de IA clara (chat-input vale 2), o dos señales ligeras
// juntas (p. ej. mención de IA + streaming). Una sola señal ligera (solo keywords o solo sse) nunca basta,
// para no marcar cualquier blog que hable de IA. Sube el umbral a 3 si prefieres menos falsos positivos.
const AI_SIGNALS = {
  api: 3,           // la página llama directo a una API de IA conocida (background, webRequest)
  "chat-input": 2,  // caja de escritura grande con texto de ayuda de chat de IA (detector.js)
  sse: 1,           // respuestas en streaming (text/event-stream), como las de los chats (background, webRequest)
  keywords: 1,      // el título o la descripción hablan de IA (detector.js)
};
const DETECT_THRESHOLD = 2;

const AI_API_URLS = [
  "api.openai.com", "api.anthropic.com", "generativelanguage.googleapis.com", "api.mistral.ai",
  "api.cohere.ai", "api.cohere.com", "api.groq.com", "openrouter.ai", "api.together.xyz", "api.deepseek.com",
  "api.perplexity.ai", "api.replicate.com", "api-inference.huggingface.co", "router.huggingface.co",
  "api.fireworks.ai", "api.x.ai", "api.elevenlabs.io", "api.stability.ai",
].map((h) => `*://${h}/*`).concat("*://*.openai.azure.com/*");

function addSignal(tabId, pageUrl, signal) {
  if (!(signal in AI_SIGNALS)) return;
  return serial(async () => {
    await ready;
    let host;
    try {
      const u = new URL(pageUrl);
      if (u.protocol !== "https:" && u.protocol !== "http:") return;
      host = u.hostname.toLowerCase().replace(/^www\./, "");
    } catch {
      return;
    }
    if (!isPublicHost(host) || isIgnored(host) || detectAI(pageUrl)) return;
    const { detected = {} } = await chrome.storage.local.get("detected");
    if (detected[host]) return;

    // Las señales se acumulan por pestaña y se reinician al cambiar de sitio.
    const key = `sig${tabId}`;
    let s = (await chrome.storage.session.get(key))[key];
    if (s?.host !== host) s = { host, signals: [] };
    if (s.signals.includes(signal)) return;
    s.signals.push(signal);
    await chrome.storage.session.set({ [key]: s });

    const score = s.signals.reduce((n, x) => n + AI_SIGNALS[x], 0);
    if (score >= DETECT_THRESHOLD) await markDetected(tabId, host, s.signals, score, detected);
  });
}

/** Marca un sitio como IA detectada. Se llama dentro de serial(). */
async function markDetected(tabId, host, signals, score, detected) {
  const now = new Date().toISOString();
  const entry = { first: now, last: now, score, signals };
  detected[host] = entry;
  // La pestaña actual ya está dentro: se le da permiso para que la regla nueva no la mande a la advertencia
  // a mitad de uso. La próxima entrada sí pasa por la advertencia.
  await allowDomains(tabId, [host]).catch(() => {});
  await chrome.storage.local.set({ detected }); // dispara resync: entra al catálogo

  const tool = { id: `auto:${host}`, name: host, category: "detectada", domains: [host] };
  await chrome.storage.session.set({ [`tab${tabId}`]: tool.id });
  await recordVisit({ tool, domain: host });
  setBadge(tabId, { tool });
  reportDetection(host, entry);
  notifyTab(tabId, host);
  console.log(`[Gobernanza IA] IA detectada en ${host} (${signals.join(", ")}; ${score} puntos)`);
}

// En la pestaña donde se detectó: aviso inmediato y registro de prompts sin esperar a recargar.
async function notifyTab(tabId, host) {
  try {
    await chrome.scripting.insertCSS({ target: { tabId }, files: ["content.css"] });
    await chrome.scripting.executeScript({ target: { tabId }, files: ["redact.js", "content.js"] });
    await chrome.scripting.executeScript({ target: { tabId }, func: showDetectedNotice, args: [host] });
  } catch {
    // La pestaña se cerró o cambió de sitio.
  }
}

// Se ejecuta DENTRO de la página: debe ser autocontenida. Va en shadow DOM para que los estilos del sitio
// no la desarmen. Mientras está abierta, no se puede escribir en la página.
function showDetectedNotice(host) {
  const ID = "cognitive-gobernanza-ia-detectada";
  if (document.getElementById(ID)) return;
  const wrap = document.createElement("div");
  wrap.id = ID;
  const root = wrap.attachShadow({ mode: "closed" });
  root.innerHTML = `
    <style>
      .bg { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center; justify-content: center;
        padding: 16px; background: rgba(0,0,0,.6); font: 15px/1.5 system-ui, "Segoe UI", sans-serif; color: #1f2328; }
      .card { max-width: 480px; width: 100%; background: #fff; border-top: 6px solid #d93025; border-radius: 10px;
        padding: 24px 26px; box-shadow: 0 10px 40px rgba(0,0,0,.35); box-sizing: border-box; }
      h1 { font-size: 20px; color: #d93025; margin: 0 0 8px; }
      p { margin: 0 0 8px; } ul { margin: 0 0 18px; padding-left: 20px; } li { margin: 2px 0; }
      .host { font-weight: 600; margin-bottom: 12px; }
      .actions { display: flex; justify-content: flex-end; }
      button { font: 600 14px/1 system-ui, "Segoe UI", sans-serif; padding: 10px 16px; border-radius: 6px; cursor: pointer;
        background: #d93025; border: 1px solid #d93025; color: #fff; }
    </style>
    <div class="bg"><div class="card" role="alertdialog" aria-modal="true">
      <h1>Este sitio parece ser una herramienta de IA</h1>
      <p class="host"></p>
      <p>Lo que escribas o subas aquí sale de la empresa y puede quedar guardado por el proveedor.</p>
      <p><strong>No ingreses:</strong></p>
      <ul>
        <li>Datos personales de clientes o empleados</li>
        <li>Contraseñas, claves o credenciales</li>
        <li>Información financiera, contratos o documentos confidenciales</li>
        <li>Código fuente o datos internos de la empresa</li>
      </ul>
      <div class="actions"><button type="button">Entendido</button></div>
    </div></div>`;
  root.querySelector(".host").textContent = host;
  const button = root.querySelector("button");
  const block = (e) => {
    if (e.composedPath().includes(wrap)) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    button.focus();
  };
  button.addEventListener("click", () => {
    wrap.remove();
    window.removeEventListener("keydown", block, true);
  });
  window.addEventListener("keydown", block, true);
  (document.body || document.documentElement).appendChild(wrap);
  button.focus();
}

// Llamadas directas a APIs de IA desde la página.
chrome.webRequest.onBeforeRequest.addListener((d) => {
  if (d.tabId < 0) return;
  chrome.tabs.get(d.tabId).then((tab) => tab.url && addSignal(d.tabId, tab.url, "api")).catch(() => {});
}, { urls: AI_API_URLS });

// Respuestas en streaming de la ventana principal.
chrome.webRequest.onHeadersReceived.addListener((d) => {
  if (d.tabId < 0 || d.frameId !== 0) return;
  const type = d.responseHeaders?.find((h) => h.name.toLowerCase() === "content-type")?.value ?? "";
  if (!type.includes("text/event-stream")) return;
  chrome.tabs.get(d.tabId).then((tab) => tab.url && addSignal(d.tabId, tab.url, "sse")).catch(() => {});
}, { urls: ["http://*/*", "https://*/*"], types: ["xmlhttprequest"] }, ["responseHeaders"]);

chrome.alarms.onAlarm.addListener((a) => { if (a.name === "upload") flushOutbox(); });

chrome.runtime.onInstalled.addListener(() => {
  resync();
  flushOutbox();
  chrome.alarms.create("upload", { periodInMinutes: UPLOAD_RETRY_MIN });
});
chrome.runtime.onStartup.addListener(flushOutbox);
