/*
  Catálogo local de herramientas de IA.
  Cada herramienta tiene un id fijo, nombre, categoría y los dominios por los que se entra a ella.
  Un dominio cubre también sus subdominios (p. ej. "chatgpt.com" cubre "auth.chatgpt.com").
  Varios dominios de la misma herramienta cuentan como UNA sola (chat.openai.com redirige a chatgpt.com).
  Es solo la lista INCLUIDA de respaldo: la vigente la resuelve catalog.js (descargada de la consola si hay).
  Agregar dominios aquí ya no requiere tocar manifest.json.
*/
export const CATEGORIES = {
  chatbot: "Chatbot", imagen: "Imagen", video: "Video", audio: "Audio",
  codigo: "Código", escritura: "Escritura", productividad: "Productividad",
  detectada: "Detectada (automática)",
};

export const AI_TOOLS = [
  // Chatbots y asistentes
  // Se incluye el dominio raíz del vendor (openai.com, anthropic.com…) además del dominio del chat, porque
  // la página de inicio suele tener una caja desde la que el texto pasa al chat real (hueco a cubrir).
  { id: "chatgpt", name: "ChatGPT", category: "chatbot", domains: ["chatgpt.com", "chat.openai.com", "openai.com"] },
  { id: "claude", name: "Claude", category: "chatbot", domains: ["claude.ai", "anthropic.com"] },
  { id: "gemini", name: "Gemini", category: "chatbot", domains: ["gemini.google.com"] },
  { id: "ai-studio", name: "Google AI Studio", category: "chatbot", domains: ["aistudio.google.com"] },
  { id: "copilot", name: "Microsoft Copilot", category: "chatbot", domains: ["copilot.microsoft.com"] },
  { id: "m365-copilot", name: "Microsoft 365 Copilot", category: "chatbot", domains: ["m365.cloud.microsoft"] },
  { id: "perplexity", name: "Perplexity", category: "chatbot", domains: ["perplexity.ai"] },
  // deepseek.com incluye la caja de chat de la página de inicio (desde donde el texto pasa al chat real),
  // por eso se cubre el dominio raíz además del subdominio del chat.
  { id: "deepseek", name: "DeepSeek", category: "chatbot", domains: ["chat.deepseek.com", "deepseek.com"] },
  { id: "meta-ai", name: "Meta AI", category: "chatbot", domains: ["meta.ai"] },
  { id: "grok", name: "Grok", category: "chatbot", domains: ["grok.com", "x.ai"] },
  { id: "mistral", name: "Le Chat (Mistral)", category: "chatbot", domains: ["chat.mistral.ai", "mistral.ai"] },
  { id: "poe", name: "Poe", category: "chatbot", domains: ["poe.com"] },
  { id: "character-ai", name: "Character.AI", category: "chatbot", domains: ["character.ai"] },
  { id: "pi", name: "Pi", category: "chatbot", domains: ["pi.ai"] },
  { id: "huggingface", name: "Hugging Face", category: "chatbot", domains: ["huggingface.co"] },
  { id: "qwen", name: "Qwen Chat", category: "chatbot", domains: ["chat.qwen.ai"] },
  { id: "kimi", name: "Kimi", category: "chatbot", domains: ["kimi.com"] },
  { id: "you", name: "You.com", category: "chatbot", domains: ["you.com"] },
  { id: "monica", name: "Monica", category: "chatbot", domains: ["monica.im"] },
  { id: "merlin", name: "Merlin", category: "chatbot", domains: ["getmerlin.in"] },

  // Imagen
  { id: "midjourney", name: "Midjourney", category: "imagen", domains: ["midjourney.com"] },
  { id: "leonardo", name: "Leonardo.Ai", category: "imagen", domains: ["leonardo.ai"] },
  { id: "ideogram", name: "Ideogram", category: "imagen", domains: ["ideogram.ai"] },
  { id: "firefly", name: "Adobe Firefly", category: "imagen", domains: ["firefly.adobe.com"] },
  { id: "playground", name: "Playground", category: "imagen", domains: ["playgroundai.com"] },
  { id: "dreamstudio", name: "DreamStudio", category: "imagen", domains: ["dreamstudio.ai"] },
  { id: "stability", name: "Stability AI", category: "imagen", domains: ["stability.ai"] },
  { id: "krea", name: "Krea", category: "imagen", domains: ["krea.ai"] },
  { id: "civitai", name: "Civitai", category: "imagen", domains: ["civitai.com"] },
  { id: "nightcafe", name: "NightCafe", category: "imagen", domains: ["nightcafe.studio"] },
  { id: "craiyon", name: "Craiyon", category: "imagen", domains: ["craiyon.com"] },
  { id: "lexica", name: "Lexica", category: "imagen", domains: ["lexica.art"] },
  { id: "recraft", name: "Recraft", category: "imagen", domains: ["recraft.ai"] },

  // Video
  { id: "runway", name: "Runway", category: "video", domains: ["runwayml.com"] },
  { id: "pika", name: "Pika", category: "video", domains: ["pika.art"] },
  { id: "sora", name: "Sora", category: "video", domains: ["sora.com"] },
  { id: "luma", name: "Luma AI", category: "video", domains: ["lumalabs.ai"] },
  { id: "heygen", name: "HeyGen", category: "video", domains: ["heygen.com"] },
  { id: "synthesia", name: "Synthesia", category: "video", domains: ["synthesia.io"] },
  { id: "kling", name: "Kling AI", category: "video", domains: ["klingai.com"] },
  { id: "hailuo", name: "Hailuo AI", category: "video", domains: ["hailuoai.video"] },
  { id: "invideo", name: "InVideo", category: "video", domains: ["invideo.io"] },
  { id: "descript", name: "Descript", category: "video", domains: ["descript.com"] },

  // Audio y reuniones
  { id: "elevenlabs", name: "ElevenLabs", category: "audio", domains: ["elevenlabs.io"] },
  { id: "suno", name: "Suno", category: "audio", domains: ["suno.com"] },
  { id: "udio", name: "Udio", category: "audio", domains: ["udio.com"] },
  { id: "murf", name: "Murf AI", category: "audio", domains: ["murf.ai"] },
  { id: "playht", name: "PlayHT", category: "audio", domains: ["play.ht"] },
  { id: "otter", name: "Otter.ai", category: "audio", domains: ["otter.ai"] },
  { id: "fireflies", name: "Fireflies.ai", category: "audio", domains: ["fireflies.ai"] },
  { id: "fathom", name: "Fathom", category: "audio", domains: ["fathom.video"] },
  { id: "read-ai", name: "Read AI", category: "audio", domains: ["read.ai"] },
  { id: "tldv", name: "tl;dv", category: "audio", domains: ["tldv.io"] },

  // Código
  { id: "cursor", name: "Cursor", category: "codigo", domains: ["cursor.com"] },
  { id: "replit", name: "Replit", category: "codigo", domains: ["replit.com"] },
  { id: "v0", name: "v0", category: "codigo", domains: ["v0.dev", "v0.app"] },
  { id: "lovable", name: "Lovable", category: "codigo", domains: ["lovable.dev"] },
  { id: "bolt", name: "Bolt", category: "codigo", domains: ["bolt.new"] },
  { id: "windsurf", name: "Windsurf (Codeium)", category: "codigo", domains: ["windsurf.com", "codeium.com"] },
  { id: "tabnine", name: "Tabnine", category: "codigo", domains: ["tabnine.com"] },
  { id: "phind", name: "Phind", category: "codigo", domains: ["phind.com"] },

  // Escritura
  { id: "quillbot", name: "QuillBot", category: "escritura", domains: ["quillbot.com"] },
  { id: "jasper", name: "Jasper", category: "escritura", domains: ["jasper.ai"] },
  { id: "deepl", name: "DeepL", category: "escritura", domains: ["deepl.com"] },
  { id: "copy-ai", name: "Copy.ai", category: "escritura", domains: ["copy.ai"] },
  { id: "writesonic", name: "Writesonic", category: "escritura", domains: ["writesonic.com"] },
  { id: "rytr", name: "Rytr", category: "escritura", domains: ["rytr.me"] },
  { id: "grammarly", name: "Grammarly", category: "escritura", domains: ["grammarly.com"] },
  { id: "wordtune", name: "Wordtune", category: "escritura", domains: ["wordtune.com"] },

  // Productividad
  { id: "gamma", name: "Gamma", category: "productividad", domains: ["gamma.app"] },
  { id: "beautiful-ai", name: "Beautiful.ai", category: "productividad", domains: ["beautiful.ai"] },
  { id: "tome", name: "Tome", category: "productividad", domains: ["tome.app"] },
  { id: "notebooklm", name: "NotebookLM", category: "productividad", domains: ["notebooklm.google.com"] },
  { id: "n8n", name: "n8n", category: "productividad", domains: ["n8n.cloud"] },
];

export const TOOLS_BY_ID = new Map(AI_TOOLS.map((t) => [t.id, t]));
export const TOOL_BY_DOMAIN = new Map(AI_TOOLS.flatMap((t) => t.domains.map((d) => [d, t])));
