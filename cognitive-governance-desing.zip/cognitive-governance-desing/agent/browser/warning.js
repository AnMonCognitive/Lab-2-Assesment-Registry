/*
  Gobernanza IA · página de advertencia previa

  La regla de redirección (background.js) trae aquí la navegación a un sitio de IA antes de que cargue.
  La dirección original viene después del "#". Al aceptar, se pide al background que deje pasar la
  herramienta y se continúa a esa dirección; al volver, se regresa a la página anterior o se cierra la pestaña.
*/
import { getCatalog, indexCatalog } from "./catalog.js";

const dest = location.hash.slice(1);
// Solo se continúa a direcciones del catálogo: esta página no debe servir para mandar a cualquier sitio.
const tool = indexCatalog((await getCatalog()).tools).findTool(dest)?.tool;

document.getElementById("tool").textContent = tool ? `Herramienta: ${tool.name}` : "Herramienta desconocida";
document.getElementById("dest").textContent = tool ? new URL(dest).hostname : "";

const ok = document.getElementById("ok");
ok.disabled = !tool;
ok.focus();
ok.addEventListener("click", async () => {
  ok.disabled = true;
  await chrome.runtime.sendMessage({ type: "allowTool", toolId: tool.id });
  location.replace(dest);
});

document.getElementById("leave").addEventListener("click", async () => {
  if (history.length > 1) return history.back();
  const tab = await chrome.tabs.getCurrent();
  if (tab) chrome.tabs.remove(tab.id);
});
