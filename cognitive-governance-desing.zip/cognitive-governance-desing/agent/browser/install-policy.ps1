<#
  Configura la extensión de uso web de IA · Lab 2 en Chrome y Edge por política (requiere administrador).

  Pensado para correr en cada equipo desde Intune, GPO o el instalador de TI (como SYSTEM o administrador).
  Escribe la configuración administrada (URL, token y nombre del equipo) que la extensión lee de
  chrome.storage.managed; con -ForceInstall, además fuerza la instalación de la extensión.

  Ejemplo:
    powershell -ExecutionPolicy Bypass -File install-policy.ps1 -ExtensionId abcdefghijklmnopabcdefghijklmnop `
      -ServerUrl https://consola.midominio.com -Token lab2_xxx -ForceInstall

  -ForceInstall usa por defecto la tienda de cada navegador (la extensión debe estar publicada ahí, aunque sea
  como "no listada"). Para una extensión alojada por la empresa, pasa -UpdateUrl con la URL de su update.xml.
  Desinstalar:  install-policy.ps1 -ExtensionId ... -Remove
#>
param(
  [Parameter(Mandatory = $true)][ValidatePattern('^[a-p]{32}$')][string]$ExtensionId,
  [string]$ServerUrl,
  [string]$Token,
  [string]$Area,
  [string[]]$Browsers = @('chrome', 'edge'),
  [switch]$ForceInstall,
  [string]$UpdateUrl,
  [switch]$Remove
)
$ErrorActionPreference = 'Stop'

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(
  [Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) { throw 'Ejecuta este script como administrador (las políticas viven en HKLM).' }
if (-not $Remove -and (-not $ServerUrl -or -not $Token)) { throw 'Faltan -ServerUrl y -Token.' }

$targets = @{
  chrome = @{ Root = 'HKLM:\SOFTWARE\Policies\Google\Chrome'; Store = 'https://clients2.google.com/service/update2/crx' }
  edge   = @{ Root = 'HKLM:\SOFTWARE\Policies\Microsoft\Edge'; Store = 'https://edge.microsoft.com/extensionwebstorebase/v1/crx' }
}

foreach ($b in $Browsers) {
  $t = $targets[$b.ToLower()]
  if (-not $t) { Write-Warning "Navegador no soportado: $b"; continue }
  $policyKey = Join-Path $t.Root "3rdparty\extensions\$ExtensionId\policy"
  $forceKey = Join-Path $t.Root 'ExtensionInstallForcelist'

  # Quita la entrada previa de esta extensión en la lista de instalación forzada (si la hay).
  if (Test-Path $forceKey) {
    (Get-Item $forceKey).Property | Where-Object {
      (Get-ItemPropertyValue $forceKey $_) -like "$ExtensionId;*"
    } | ForEach-Object { Remove-ItemProperty $forceKey -Name $_ }
  }

  if ($Remove) {
    Remove-Item (Join-Path $t.Root "3rdparty\extensions\$ExtensionId") -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "$b`: política de la extensión eliminada."
    continue
  }

  New-Item -Path $policyKey -Force | Out-Null
  Set-ItemProperty $policyKey -Name serverUrl -Value $ServerUrl
  Set-ItemProperty $policyKey -Name token -Value $Token
  # Mismo nombre que reporta el agente de Windows: así la consola une ambos reportes en un solo equipo.
  Set-ItemProperty $policyKey -Name hostname -Value $env:COMPUTERNAME
  if ($Area) { Set-ItemProperty $policyKey -Name area -Value $Area }

  if ($ForceInstall) {
    New-Item -Path $forceKey -Force | Out-Null
    $used = @((Get-Item $forceKey).Property | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ })
    $next = 1
    while ($used -contains $next) { $next++ }
    $url = if ($UpdateUrl) { $UpdateUrl } else { $t.Store }
    Set-ItemProperty $forceKey -Name "$next" -Value "$ExtensionId;$url"
  }
  Write-Host "$b`: configurada para $env:COMPUTERNAME$(if ($ForceInstall) { ' (instalación forzada)' })."
}
Write-Host 'Reinicia el navegador o abre chrome://policy (edge://policy) y pulsa "Volver a cargar políticas".'
