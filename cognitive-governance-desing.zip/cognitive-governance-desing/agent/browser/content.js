/*
  Gobernanza IA · protección de prompts (content script)

  Corre SOLO en los dominios de herramientas de IA del catálogo (lo registra syncCatalog en background.js).
  Función: al ENVIAR, revisar el prompt para proteger a la persona de compartir datos sensibles con la IA.
  Si detecta datos sensibles, avisa antes de enviar y deja decidir (revisar / quitar datos / enviar igual).

  Qué sale de la página: SOLO los mensajes que contenían datos sensibles (o que pasaron por la advertencia)
  se mandan a la extensión, y ya enmascarados ([EMAIL], [TARJETA]…). Un mensaje sin datos sensibles se revisa
  en la propia página y NO se transmite ni se guarda.

  Transparencia (obligatoria): mientras este script esté activo, SIEMPRE se muestra en la página un aviso de
  que la empresa revisa los mensajes y registra solo los que llevan datos sensibles. El cumplimiento de la
  organización depende de que sus empleados reciban el aviso de privacidad y den su consentimiento; este
  banner es la parte visible de ese aviso y no debe quitarse.

  Lo que NO se captura: campos de contraseña, ni lo que se escribe y se borra sin enviar.
  Datos sensibles (correos, tarjetas, CURP, contraseñas, claves de API…): se reemplazan por una etiqueta
  ([EMAIL], [TARJETA], …) antes de mandar el texto a la extensión (redact.js, que se carga antes que este).
*/
(() => {
  const NOTICE_ID = "cognitive-gobernanza-ia-aviso";
  const SENT_FLAG = "__cognitiveSent"; // marca para no registrar dos veces el mismo envío (Enter + clic)

  // --- Aviso visible permanente ------------------------------------------------
  function ensureNotice() {
    if (document.getElementById(NOTICE_ID)) return;
    const bar = document.createElement("div");
    bar.id = NOTICE_ID;
    bar.setAttribute("role", "status");
    bar.textContent =
      "Gobernanza IA · Tu empresa revisa tus mensajes para protegerte y registra solo los que contengan datos sensibles.";
    (document.body || document.documentElement).appendChild(bar);
  }
  ensureNotice();
  // Las apps de IA re-renderizan y pueden quitar el banner: se vuelve a poner si desaparece.
  new MutationObserver(ensureNotice).observe(document.documentElement, { childList: true, subtree: true });

  // --- Lectura del texto del prompt --------------------------------------------
  // Campo donde se escribe: un <textarea>, un <input type=text/search>, o un editor contenteditable
  // (ChatGPT y Claude usan ProseMirror). NUNCA un campo de contraseña.
  function readField(node) {
    if (!node) return "";
    const tag = node.tagName;
    if (tag === "TEXTAREA") return node.value ?? "";
    if (tag === "INPUT") {
      if (node.type === "password" || node.type === "email" || node.type === "tel") return "";
      return (node.type === "text" || node.type === "search" || !node.type) ? (node.value ?? "") : "";
    }
    if (node.isContentEditable) return (node.innerText ?? "").trim();
    return "";
  }

  // El campo activo en el momento del envío, o el editor visible más probable como respaldo.
  function currentFieldNode() {
    const a = document.activeElement;
    if (readField(a)) return a;
    // Respaldo: el contenteditable o textarea visible más grande de la página.
    const editors = [...document.querySelectorAll('textarea, [contenteditable="true"], [contenteditable=""]')]
      .filter((n) => n.offsetParent !== null && n.getBoundingClientRect().width > 120);
    editors.sort((x, y) => y.getBoundingClientRect().width - x.getBoundingClientRect().width);
    return editors[0] ?? null;
  }
  const currentField = () => readField(currentFieldNode());

  // Reemplaza el texto del campo de forma que la app se entere (React, ProseMirror, Lexical…).
  function replaceText(node, text) {
    if (node.tagName === "TEXTAREA" || node.tagName === "INPUT") {
      const proto = node.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      Object.getOwnPropertyDescriptor(proto, "value").set.call(node, text);
      node.dispatchEvent(new Event("input", { bubbles: true }));
      return;
    }
    node.focus();
    const sel = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(node);
    sel.removeAllRanges();
    sel.addRange(range);
    document.execCommand("insertText", false, text);
  }

  // Evita registrar dos veces el mismo envío: Enter + clic en el botón, o un botón de otro formulario
  // que lea el texto que quedó en el editor. No se repite el mismo texto dentro de esta ventana.
  let lastText = "";
  let lastAt = 0;
  const DEDUP_MS = 4000;

  function record(text) {
    const prompt = (text || "").replace(/\s+$/g, "");
    if (!prompt) return;
    const now = Date.now();
    if (prompt === lastText && now - lastAt < DEDUP_MS) return;
    lastText = prompt;
    lastAt = now;
    // Los datos sensibles se ocultan AQUÍ, antes de que el texto salga de la página (redact.js).
    const { text: safe, found } = globalThis.GobernanzaRedact.redact(prompt);
    // Si el envío pasó por la advertencia, se registra qué decidió la persona y qué datos tenía el mensaje.
    const decision = pending;
    pending = null;
    // Protección, no archivo: si el mensaje no lleva datos sensibles y no pasó por la advertencia, se revisó
    // en la página y no hay nada que proteger: NO se transmite a la extensión (y por tanto no se guarda).
    if (!decision && !Object.keys(found).length) return;
    try {
      chrome.runtime.sendMessage({ type: "prompt", host: location.hostname, text: safe,
        sensitive: decision ? { ...decision.found, ...found } : found, decision: decision?.decision });
    } catch {
      // El service worker puede estar dormido; sendMessage lo despierta. Si falla, no se reintenta aquí.
    }
  }

  // --- Advertencia de datos sensibles antes de enviar ---------------------------
  // Si el mensaje tiene datos sensibles, se frena el envío ANTES de que la app lo procese y se pregunta qué
  // hacer. Al decidir, se vuelve a disparar el envío con `bypass` activo para no volver a frenarlo.
  const WARN_ID = "cognitive-gobernanza-ia-sensibles";
  let bypass = false;
  let pending = null; // { decision: "enviado" | "ocultado", found } para el próximo record()

  const LABELS = {
    EMAIL: "correo electrónico", "TELÉFONO": "teléfono", TARJETA: "tarjeta bancaria", CLABE: "CLABE",
    IBAN: "IBAN", CURP: "CURP", RFC: "RFC", NSS: "NSS", SSN: "SSN", "CONTRASEÑA": "contraseña",
    CLAVE_API: "clave de API", TOKEN: "token de acceso", CLAVE_PRIVADA: "clave privada", IP: "dirección IP",
    CONFIDENCIAL: "dato confidencial de la empresa",
  };

  const SEND_RE = /(enviar|send|submit)/i;
  const looksLikeSend = (btn) => {
    const label = `${btn.getAttribute("aria-label") || ""} ${btn.getAttribute("title") || ""} ${btn.dataset.testid || ""} ${btn.type || ""}`;
    return SEND_RE.test(label) || btn.type === "submit" || !!btn.closest("form");
  };

  // Botón de enviar cercano al campo (subiendo unos niveles), para reenviar de forma confiable.
  function findSendButton(field) {
    let node = field;
    for (let i = 0; i < 8 && node; i++, node = node.parentElement) {
      const btn = [...node.querySelectorAll('button, [role="button"], input[type="submit"]')]
        .find((b) => !b.disabled && (b.type === "submit" ||
          SEND_RE.test(`${b.getAttribute("aria-label") || ""} ${b.getAttribute("title") || ""} ${b.dataset.testid || ""}`)));
      if (btn) return btn;
    }
    return null;
  }

  // Vuelve a enviar sin frenar: por el botón si se conoce, si no, con un Enter en el campo.
  function resend(field, button) {
    bypass = true;
    try {
      const btn = button ?? findSendButton(field);
      if (btn) btn.click();
      else {
        field.focus();
        field.dispatchEvent(new KeyboardEvent("keydown",
          { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true }));
      }
    } finally {
      bypass = false;
    }
  }

  /** Devuelve true si frenó el envío para mostrar la advertencia. */
  function guard(e, field, button) {
    if (bypass) return false;
    if (document.getElementById(WARN_ID)) return stop(e); // ya hay una advertencia abierta
    if (!field) return false;
    const text = readField(field);
    const { text: safe, found } = globalThis.GobernanzaRedact.redact(text);
    if (!Object.keys(found).length) return false;
    stop(e);
    showSensitiveWarning(found, {
      edit: () => field.focus(),
      redact: () => {
        replaceText(field, safe);
        pending = { decision: "ocultado", found };
        // La app necesita un momento para tomar el texto nuevo antes de enviar.
        setTimeout(() => resend(field, button), 150);
      },
      send: () => {
        pending = { decision: "enviado", found };
        resend(field, button);
      },
    });
    return true;
  }

  function stop(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    return true;
  }

  // Ventana de advertencia. Va en shadow DOM para que los estilos del sitio no la desarmen.
  function showSensitiveWarning(found, actions) {
    const wrap = document.createElement("div");
    wrap.id = WARN_ID;
    const root = wrap.attachShadow({ mode: "closed" });
    root.innerHTML = `
      <style>
        .bg { position: fixed; inset: 0; z-index: 2147483647; display: flex; align-items: center; justify-content: center;
          padding: 16px; background: rgba(0,0,0,.6); font: 15px/1.5 system-ui, "Segoe UI", sans-serif; color: #1f2328; }
        .card { max-width: 500px; width: 100%; background: #fff; border-top: 6px solid #d93025; border-radius: 10px;
          padding: 24px 26px; box-shadow: 0 10px 40px rgba(0,0,0,.35); box-sizing: border-box; }
        h1 { font-size: 20px; color: #d93025; margin: 0 0 8px; }
        p { margin: 0 0 10px; } ul { margin: 0 0 14px; padding-left: 20px; } li { margin: 2px 0; font-weight: 600; }
        .actions { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; margin-top: 16px; }
        button { font: 600 14px/1 system-ui, "Segoe UI", sans-serif; padding: 10px 14px; border-radius: 6px; cursor: pointer;
          border: 1px solid #c4c8cc; background: #fff; color: #1f2328; }
        button.primary { background: #d93025; border-color: #d93025; color: #fff; }
        button.link { border-color: transparent; color: #5f6368; text-decoration: underline; }
      </style>
      <div class="bg"><div class="card" role="alertdialog" aria-modal="true" aria-labelledby="t">
        <h1 id="t">Tu mensaje tiene datos sensibles</h1>
        <p>Estás por enviar a una herramienta de IA externa:</p>
        <ul></ul>
        <p>Una vez enviados, salen de la empresa y pueden quedar guardados por el proveedor.</p>
        <div class="actions">
          <button type="button" class="link" data-a="send">Enviar de todos modos</button>
          <button type="button" data-a="redact">Quitar datos y enviar</button>
          <button type="button" class="primary" data-a="edit">Revisar mensaje</button>
        </div>
      </div></div>`;
    root.querySelector("ul").append(...Object.entries(found).map(([tag, n]) => {
      const li = document.createElement("li");
      li.textContent = `${LABELS[tag] ?? tag.toLowerCase()}${n > 1 ? ` (${n})` : ""}`;
      return li;
    }));

    // Mientras está abierta, el teclado no llega a la página (ni otro Enter que envíe).
    const block = (e) => {
      if (e.composedPath().includes(wrap)) {
        if (e.key === "Escape") close("edit");
        return;
      }
      e.preventDefault();
      e.stopImmediatePropagation();
    };
    function close(action) {
      wrap.remove();
      window.removeEventListener("keydown", block, true);
      actions[action]();
    }
    for (const b of root.querySelectorAll("button")) b.addEventListener("click", () => close(b.dataset.a));
    window.addEventListener("keydown", block, true);
    (document.body || document.documentElement).appendChild(wrap);
    root.querySelector('[data-a="edit"]').focus();
  }

  // --- Disparadores de envío ---------------------------------------------------
  // Van en window y en captura para correr ANTES que los de la app y poder frenar el envío.
  // 1) Enter sin Shift dentro de un campo de escritura (el patrón de ChatGPT, Claude, Gemini…).
  window.addEventListener("keydown", (e) => {
    if (e.key !== "Enter" || e.shiftKey || e.isComposing) return;
    const t = e.target;
    if (!(t && (t.tagName === "TEXTAREA" || t.isContentEditable || t.tagName === "INPUT"))) return;
    const field = readField(t) ? t : currentFieldNode();
    if (guard(e, field, null)) return;
    const text = readField(field);
    // Se lee ANTES de que la app limpie el campo; se registra en el próximo tick.
    setTimeout(() => record(text), 0);
  }, true);

  // 2) Clic en el botón de enviar. Se reconoce por aria-label/título/tipo, sin depender de un sitio.
  window.addEventListener("click", (e) => {
    const btn = e.target.closest?.('button, [role="button"], input[type="submit"]');
    if (!btn || !looksLikeSend(btn)) return;
    const field = currentFieldNode();
    if (guard(e, field, btn)) return;
    const text = readField(field);
    setTimeout(() => record(text), 0);
  }, true);
})();
