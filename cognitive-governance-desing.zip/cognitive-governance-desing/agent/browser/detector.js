/*
  Gobernanza IA · detector automático de sitios de IA (content script)

  Corre en los sitios que NO están en el catálogo (lo registra syncCatalog en background.js), solo en la
  ventana principal. Busca señales de que la página es una herramienta de IA y se las manda al background,
  que suma los puntos y decide (ver AI_SIGNALS en background.js).

  Lo que mira: el título y las meta descripciones de la página, y el texto de ayuda (placeholder,
  aria-label) de los campos de escritura. NUNCA lee lo que la persona escribe ni el contenido de la página.
*/
(() => {
  if (window.top !== window) return;

  // Textos de ayuda típicos de la caja de un chat de IA.
  const PROMPT_RE = new RegExp([
    "ask (me )?anything", "ask a question", "ask [\\w.-]+ ?ai\\b", "message (chatgpt|claude|gemini|copilot|grok|[\\w.-]+ ?ai)\\b",
    "(enter|type|write) (a |your )?prompt", "describe (what|the image|the video|your idea|an image)",
    "what (do you want|would you like) to (create|build|make|know|generate)", "how can i help",
    "chat with (ai|[\\w.-]+ ?ai)\\b", "start a (new )?chat",
    "pregunta (lo que (sea|quieras)|cualquier cosa)", "escribe (tu|un) prompt", "en qué puedo ayudarte",
    "describe lo que (quieres|deseas)", "qué quieres (crear|generar)", "habla con (la )?ia",
  ].join("|"), "i");

  // Menciones de IA en el título o la descripción de la página.
  const AI_TEXT_RE = /\b(ai|ia) ?(chat|chatbot|assistant|asistente|agent|agente|generator|generador|writer|image|video|art)\b|\bchatbot\b|\bgpt\b|\bllm\b|inteligencia artificial|artificial intelligence|generative ai|ia generativa/i;

  const sent = new Set();
  function report(signal) {
    if (sent.has(signal)) return;
    sent.add(signal);
    try {
      chrome.runtime.sendMessage({ type: "aiSignal", signal }).catch(() => {});
    } catch {
      // La extensión se recargó: el contexto ya no es válido.
    }
  }

  function check() {
    const meta = [document.title, ...['meta[name="description"]', 'meta[property="og:title"]',
      'meta[property="og:description"]', 'meta[name="application-name"]']
      .map((s) => document.querySelector(s)?.getAttribute("content") || "")].join(" ");
    if (AI_TEXT_RE.test(meta)) report("keywords");

    const fields = document.querySelectorAll(
      'textarea, [contenteditable="true"], [contenteditable="plaintext-only"], [contenteditable=""], input[type="text"], input:not([type])');
    for (const n of fields) {
      const hint = [n.getAttribute("placeholder"), n.getAttribute("aria-label"), n.getAttribute("data-placeholder"),
        // Editores tipo ProseMirror (ChatGPT, Claude) ponen el placeholder en un hijo.
        n.querySelector?.("[data-placeholder]")?.getAttribute("data-placeholder")].filter(Boolean).join(" ");
      if (!hint || !PROMPT_RE.test(hint)) continue;
      // Solo cajas visibles y de tamaño razonable: descarta buscadores chicos y widgets de soporte.
      if (n.offsetParent === null || n.getBoundingClientRect().width < 220) continue;
      report("chat-input");
      break;
    }
  }

  // Las apps de una sola página (SPA) dibujan la caja de chat tarde, o tras navegar sin recargar: se revisa
  // al cargar, varias veces más, al volver a la pestaña, y cuando el usuario enfoca un campo (justo antes de
  // escribir). check() es idempotente: report() no repite una señal ya enviada, así que re-revisar es barato.
  let lastCheck = 0;
  const maybeCheck = () => { const now = Date.now(); if (now - lastCheck < 800) return; lastCheck = now; check(); };
  check();
  setTimeout(check, 3000);
  setTimeout(check, 8000);
  setTimeout(check, 15000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden) maybeCheck(); });
  window.addEventListener("focusin", maybeCheck, true);
})();
