/*
  Página de la extensión (se abre con el ícono o en una pestaña). Solo LEE el almacenamiento local:
    inventory: { toolId: { first, last, days, visits, domains } }   -> vista "Inventario"
    usage:     { día: { toolId: { visits } } }                       -> vista "Por día"
  Se actualiza sola cuando background.js cuenta una visita nueva.
*/
import { CATEGORIES } from "./ai_domains.js";
import { getCatalog, indexCatalog } from "./catalog.js";

const $ = (id) => document.getElementById(id);
const catLabel = (c) => CATEGORIES[c] ?? c ?? "Sin categoría";
// Catálogo vigente; se recarga en cada render() por si la consola mandó uno nuevo.
let toolsById = new Map();
// Si un id ya no está en el catálogo (o es un dato viejo por dominio), se muestra tal cual.
const toolInfo = (id) => toolsById.get(id) ?? { id, name: id, category: null };

let view = "inventory";
let selectedDay = null;

function localDay(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function shortDate(day) {
  const [y, m, d] = day.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("es-MX", { day: "numeric", month: "short", year: "numeric" });
}

function dayLabel(day) {
  if (day === localDay()) return "Hoy";
  if (day === localDay(new Date(Date.now() - 86400000))) return "Ayer";
  const [y, m, d] = day.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString("es-MX", { weekday: "short", day: "numeric", month: "short" });
}

// Los datos se insertan como texto, nunca como HTML.
function el(tag, attrs = {}, ...children) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
  for (const c of children) if (c != null) n.append(c);
  return n;
}

// ------------------------------------------------------------------ inventario

function inventoryRows(inventory) {
  return Object.entries(inventory).map(([id, v]) => {
    const t = toolInfo(id);
    return { id, name: t.name, category: t.category, ...v };
  }).sort((a, b) => b.last.localeCompare(a.last) || b.visits - a.visits);
}

function renderInventory(inventory) {
  const all = inventoryRows(inventory);
  const cats = [...new Set(all.map((r) => r.category))];

  // Filtro de categoría (conserva la selección)
  const sel = $("i-cat");
  const chosen = sel.value;
  sel.replaceChildren(el("option", { value: "" }, "Todas las categorías"),
    ...cats.sort().map((c) => el("option", { value: c ?? "" }, catLabel(c))));
  sel.value = cats.includes(chosen) ? chosen : "";
  const rows = sel.value ? all.filter((r) => r.category === sel.value) : all;

  $("i-tools").textContent = all.length;
  $("i-cats").textContent = cats.length;
  const first = all.map((r) => r.first).sort()[0];
  $("i-since").textContent = first ? shortDate(first) : "—";

  $("i-rows").replaceChildren(...rows.map((r) => el("tr", {},
    el("td", { class: "tool" }, r.name, el("span", { class: "dom" }, (r.domains ?? []).join(", "))),
    el("td", {}, el("span", { class: "cat-tag" }, catLabel(r.category))),
    el("td", { class: "date" }, shortDate(r.first)),
    el("td", { class: "date" }, r.last === localDay() ? "Hoy" : shortDate(r.last)),
    el("td", { class: "num" }, String(r.days)),
    el("td", { class: "num" }, String(r.visits)))));
  $("i-empty").hidden = all.length > 0;
  $("i-rows").closest(".scroll").hidden = all.length === 0;
  $("export").disabled = all.length === 0;
}

async function exportCsv() {
  const { inventory = {} } = await chrome.storage.local.get("inventory");
  const q = (s) => `"${String(s ?? "").replace(/"/g, '""')}"`;
  const lines = [["herramienta", "id", "categoria", "dominios", "primera_vez", "ultima_vez", "dias", "visitas"].join(",")];
  for (const r of inventoryRows(inventory)) {
    lines.push([q(r.name), q(r.id), q(catLabel(r.category)), q((r.domains ?? []).join(" ")),
      r.first, r.last, r.days, r.visits].join(","));
  }
  // BOM para que Excel abra bien los acentos
  const blob = new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
  const a = el("a", { href: URL.createObjectURL(blob), download: `inventario-ia-${localDay()}.csv` });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ------------------------------------------------------------------ por día

function renderDaily(usage) {
  const today = localDay();
  const days = [...new Set([today, ...Object.keys(usage)])].sort().reverse();
  if (!selectedDay || !days.includes(selectedDay)) selectedDay = today;

  $("days").replaceChildren(...days.map((day) => {
    const b = el("button", { "aria-pressed": String(day === selectedDay) }, dayLabel(day));
    b.addEventListener("click", () => { selectedDay = day; render(); });
    return b;
  }));

  const rows = Object.entries(usage[selectedDay] ?? {})
    .map(([id, v]) => ({ ...toolInfo(id), visits: v.visits ?? 0 }))
    .sort((a, b) => b.visits - a.visits || a.name.localeCompare(b.name));

  const byCat = new Map();
  for (const r of rows) byCat.set(r.category, (byCat.get(r.category) ?? 0) + r.visits);
  $("k-visits").textContent = rows.reduce((s, r) => s + r.visits, 0);
  $("k-tools").textContent = rows.length;
  $("k-cats").textContent = byCat.size;

  const max = Math.max(1, ...byCat.values());
  $("by-cat").replaceChildren(...[...byCat].sort((a, b) => b[1] - a[1]).map(([cat, n]) => {
    const fill = el("div", { class: "fill" });
    fill.style.width = `${(n / max) * 100}%`;
    return el("div", { class: "cat" },
      el("span", { class: "name" }, catLabel(cat)), el("div", { class: "track" }, fill), el("span", { class: "n" }, String(n)));
  }));

  $("rows").replaceChildren(...rows.map((r) => el("tr", {},
    el("td", {}, r.name),
    el("td", {}, el("span", { class: "cat-tag" }, catLabel(r.category))),
    el("td", { class: "num" }, String(r.visits)))));
  $("empty").hidden = rows.length > 0;
  $("rows").closest("table").hidden = rows.length === 0;
}

// ------------------------------------------------------------------ prompts

function fmtTime(iso) {
  const d = new Date(iso);
  return d.toLocaleString("es-MX", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}

// { EMAIL: 1, TARJETA: 2 } -> "email, tarjeta ×2"
const sensitiveLabel = (s) => Object.entries(s ?? {})
  .map(([tag, n]) => `${tag.toLowerCase().replace(/_/g, " ")}${n > 1 ? ` ×${n}` : ""}`).join(", ");

const DECISIONS = {
  enviado: "Se le advirtió y lo envió de todos modos",
  ocultado: "Se le advirtió y quitó los datos antes de enviar",
};

function renderPrompts(prompts) {
  const all = [...prompts].sort((a, b) => b.time.localeCompare(a.time));

  const sel = $("p-tool");
  const chosen = sel.value;
  const ids = [...new Set(all.map((p) => p.toolId))];
  sel.replaceChildren(el("option", { value: "" }, "Todas las herramientas"),
    ...ids.map((id) => ({ id, name: toolInfo(id).name })).sort((a, b) => a.name.localeCompare(b.name))
      .map((t) => el("option", { value: t.id }, t.name)));
  sel.value = ids.includes(chosen) ? chosen : "";
  const rows = sel.value ? all.filter((p) => p.toolId === sel.value) : all;

  $("p-count").textContent = all.length;
  $("p-tools").textContent = ids.length;
  $("p-days").textContent = new Set(all.map((p) => p.day)).size;

  $("p-list").replaceChildren(...rows.map((p) => el("li", {},
    el("div", { class: "meta" }, el("b", {}, toolInfo(p.toolId).name), fmtTime(p.time)),
    p.sensitive ? el("div", { class: "sensitive" }, `Datos sensibles ocultos: ${sensitiveLabel(p.sensitive)}`) : null,
    p.decision ? el("div", { class: "sensitive" }, DECISIONS[p.decision]) : null,
    el("div", { class: "text" }, p.text))));
  $("p-empty").hidden = all.length > 0;
  $("p-list").closest(".scroll").hidden = all.length === 0;
  $("export-prompts").disabled = all.length === 0;
}

async function exportPrompts() {
  const { prompts = [] } = await chrome.storage.local.get("prompts");
  const q = (s) => `"${String(s ?? "").replace(/"/g, '""')}"`;
  const lines = [["fecha_hora", "herramienta", "id", "caracteres", "datos_ocultos", "advertencia", "prompt"].join(",")];
  for (const p of [...prompts].sort((a, b) => a.time.localeCompare(b.time))) {
    lines.push([q(p.time), q(toolInfo(p.toolId).name), q(p.toolId), p.text.length, q(sensitiveLabel(p.sensitive)), q(DECISIONS[p.decision] ?? ""),
      q(p.text)].join(","));
  }
  const blob = new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
  const a = el("a", { href: URL.createObjectURL(blob), download: `prompts-ia-${localDay()}.csv` });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// ------------------------------------------------------------------ general

async function render() {
  const { usage = {}, inventory = {}, prompts = [] } = await chrome.storage.local.get(["usage", "inventory", "prompts"]);
  toolsById = indexCatalog((await getCatalog()).tools).byId;
  for (const b of document.querySelectorAll(".views button")) b.setAttribute("aria-selected", String(b.dataset.view === view));
  $("view-inventory").hidden = view !== "inventory";
  $("view-daily").hidden = view !== "daily";
  $("view-prompts").hidden = view !== "prompts";
  $("view-terms").hidden = view !== "terms";
  $("view-conexion").hidden = view !== "conexion";
  renderInventory(inventory);
  renderDaily(usage);
  renderPrompts(prompts);
}

for (const b of document.querySelectorAll(".views button")) {
  b.addEventListener("click", () => { view = b.dataset.view; if (view === "terms") loadTermsEditor(); else if (view === "conexion") loadConn(); render(); });
}
$("i-cat").addEventListener("change", render);
$("export").addEventListener("click", exportCsv);
$("p-tool").addEventListener("change", render);
$("export-prompts").addEventListener("click", exportPrompts);

// Borrar: el primer clic pide confirmación en el mismo botón (sin ventanas emergentes).
let confirmTimer = null;
$("clear").addEventListener("click", async () => {
  const b = $("clear");
  if (!b.classList.contains("confirm")) {
    b.classList.add("confirm");
    b.textContent = "¿Seguro? Clic otra vez";
    confirmTimer = setTimeout(() => { b.classList.remove("confirm"); b.textContent = "Borrar todo"; }, 3000);
    return;
  }
  clearTimeout(confirmTimer);
  await chrome.storage.local.remove(["usage", "inventory", "prompts"]);
  b.classList.remove("confirm");
  b.textContent = "Borrar todo";
});

$("open-tab").addEventListener("click", () => {
  chrome.tabs.create({ url: chrome.runtime.getURL("popup.html?tab=1") });
  window.close();
});

if (new URLSearchParams(location.search).has("tab")) document.body.classList.add("tab");

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.usage || changes.inventory || changes.prompts || changes.catalog || changes.detected)) render();
});

// ------------------------------------------------------------------ términos de la empresa
// Editor sencillo (uno por línea) que escribe en storage.local.orgTerms; redact.js lo recoge al instante.
// Si la organización fija los términos por política (storage.managed), se muestran en modo lectura.
const termsText = $("terms-text");
let termsManaged = false;

const parseTerms = (raw) => raw.split(/\r?\n/).map((s) => s.trim()).filter(Boolean)
  .filter((t, i, a) => a.indexOf(t) === i);

function updateTermsCount() {
  const n = parseTerms(termsText.value).length;
  $("terms-count").textContent = `${n} término${n === 1 ? "" : "s"}`;
}

async function loadTermsEditor() {
  let managed = null;
  try { managed = (await chrome.storage.managed.get("orgTerms"))?.orgTerms ?? null; } catch { /* sin política */ }
  termsManaged = Array.isArray(managed) && managed.length > 0;
  let terms;
  if (termsManaged) {
    terms = managed;
  } else {
    const { orgTerms = [] } = await chrome.storage.local.get("orgTerms");
    terms = Array.isArray(orgTerms) ? orgTerms : [];
  }
  termsText.value = terms.join("\n");
  termsText.disabled = termsManaged;
  $("terms-save").disabled = termsManaged;
  $("terms-reset").disabled = termsManaged;
  $("terms-managed").hidden = !termsManaged;
  $("terms-status").textContent = "";
  updateTermsCount();
}

termsText.addEventListener("input", () => { updateTermsCount(); $("terms-status").textContent = ""; });
$("terms-reset").addEventListener("click", loadTermsEditor);
$("terms-save").addEventListener("click", async () => {
  if (termsManaged) return;
  const list = parseTerms(termsText.value);
  await chrome.storage.local.set({ orgTerms: list });
  termsText.value = list.join("\n");
  updateTermsCount();
  $("terms-status").textContent = `Guardado · ${list.length} término${list.length === 1 ? "" : "s"} activo${list.length === 1 ? "" : "s"}.`;
});

// ------------------------------------------------------------------ conexión (auto-enrolamiento con el token)
// Formulario para conectar el navegador con la consola sin tocar la consola de admin: el usuario pega el token.
// Si la organización lo fija por política (storage.managed), se muestra en modo lectura y manda la política.
let connManaged = false;

function setConnStatus(text, kind) {
  const s = $("conn-status");
  s.textContent = text;
  s.className = kind ? `note ${kind}` : "note";
}

const connValues = () => ({
  serverUrl: $("c-server").value.trim().replace(/\/+$/, ""),
  token: $("c-token").value.trim(),
  hostname: $("c-host").value.trim(),
});

async function loadConn() {
  let m = {};
  try { m = await chrome.storage.managed.get(["serverUrl", "token", "hostname"]); } catch { /* sin política */ }
  connManaged = Boolean(m.serverUrl || m.token || m.hostname);
  const { config = {} } = await chrome.storage.local.get("config");
  $("c-server").value = m.serverUrl || config.serverUrl || "";
  $("c-token").value = m.token || config.token || "";
  $("c-host").value = m.hostname || config.hostname || "";
  for (const id of ["c-server", "c-token", "c-host"]) $(id).disabled = connManaged;
  $("conn-save").disabled = connManaged;
  $("conn-managed").hidden = !connManaged;
  const ready = $("c-server").value && $("c-token").value && $("c-host").value;
  setConnStatus(connManaged ? "Configurado por tu organización." : (ready ? "Conectado." : "Sin configurar."), ready ? "ok" : null);
}

$("conn-save").addEventListener("click", async () => {
  if (connManaged) return;
  const c = connValues();
  if (!c.serverUrl || !c.token || !c.hostname) return setConnStatus("Faltan datos: URL, token y nombre del equipo.", "fail");
  await chrome.storage.local.set({ config: c });
  setConnStatus("Guardado. Los datos sensibles se enviarán a la consola.", "ok");
});

$("conn-test").addEventListener("click", async () => {
  const c = connValues();
  if (!c.serverUrl || !c.token) return setConnStatus("Pon la URL y el token para probar.", "fail");
  setConnStatus("Probando…", null);
  try {
    const r = await fetch(c.serverUrl + "/api/agent/web-domains", { headers: { Authorization: `Bearer ${c.token}` } });
    if (r.ok) setConnStatus("Conexión correcta ✓", "ok");
    else if (r.status === 401) setConnStatus("Token inválido o revocado (401).", "fail");
    else setConnStatus(`La consola respondió ${r.status}.`, "fail");
  } catch {
    setConnStatus("No se pudo conectar. Revisa la URL y que la consola esté arriba.", "fail");
  }
});

render();
loadTermsEditor();
