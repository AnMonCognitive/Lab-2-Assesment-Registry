# Arquitectura y decisiones — Cognitive Governance Platform

Documento de arquitectura y registro de decisiones (ADR) del proyecto. Explica **por qué** el sistema está hecho
así, no solo cómo. Última actualización: octubre 2026.

---

## Visión de arquitectura

```
          INPUT (equipos)                   PROCESO (servidor)              OUTPUT (consola)
┌──────────────────────────────┐      ┌──────────────────────────┐    ┌────────────────────────┐
│ Extensión navegador (DLP) ────┼──┐   │  Caddy (HTTPS, enruta)   │    │ Seguridad: datos        │
│ Agente Windows (inventario) ──┼──┼──►│  FastAPI (ingesta+API)   │──► │   sensibles, alertas    │
│ DNS (dominios, opcional) ─────┼──┘   │  PostgreSQL (multi-tenant)│    │ TI: inventario          │
└──────────────────────────────┘      │  Bedrock (assessment)     │    │ Dirección: agregados    │
    dato real ─► IA externa (riesgo)   └──────────────────────────┘    └────────────────────────┘
    evento enmascarado ─► servidor
```

**Estilo:** sistema distribuido, multi-tenant, con tres colectores independientes (extensión, agente, DNS) que
alimentan un cerebro central agnóstico a la fuente. Cada colector reintenta ante fallos; el central aísla por
organización.

**Stack:** FastAPI + SQLAlchemy + PostgreSQL · React + Vite + Tailwind · Extensión Manifest V3 · Docker + Caddy ·
Amazon Bedrock (modo simulado por defecto).

---

## Registro de decisiones (ADR)

Cada decisión: **Contexto → Decisión → Consecuencias → Estado.**

### ADR-01 · DLP de contenido, no solo inventario de metadatos
- **Contexto:** el diseño preliminar (Lab 2) solo contaba dominios y minutos ("nunca contenido"). Al presentar la
  extensión que revisa el contenido, el cliente la aprobó porque aporta más valor y porque Lab 2 vivía de datos de
  semilla fijos.
- **Decisión:** el producto captura el **contenido** del mensaje cuando trae datos sensibles (enmascarado), además
  del inventario.
- **Consecuencias:** mucho más valor (previene fuga real), pero sube el peso legal/privacidad y obliga a endurecer
  seguridad (RLS, acceso restringido). Cambia el principio "nunca contenido" de Lab 2.
- **Estado:** adoptada e implementada.

### ADR-02 · Enmascarado en el cliente, antes de enviar
- **Contexto:** si el servidor recibiera el dato crudo, la empresa se volvería un nuevo punto de acumulación de
  secretos.
- **Decisión:** `redact.js` enmascara en la propia página (`[EMAIL]`, `[TARJETA]`, `[CONFIDENCIAL]`…) **antes** de
  que el texto salga del navegador. El valor real nunca llega al servidor.
- **Consecuencias:** privacidad fuerte y mejor argumento de venta. El enmascarado depende de patrones (regex +
  validaciones como Luhn/CLABE); puede dejar pasar texto libre no estructurado (se asume como límite conocido).
- **Estado:** adoptada e implementada.

### ADR-03 · Minimización: solo se guarda lo sensible
- **Contexto:** guardar todos los prompts sería vigilancia masiva y un riesgo enorme.
- **Decisión:** un mensaje sin datos sensibles se revisa en la página y **se descarta**; solo se transmite y guarda
  si traía datos sensibles o pasó por la advertencia. Retención de 90 días.
- **Consecuencias:** menos dato almacenado, menor exposición, cumplimiento más defendible. Se pierde "telemetría"
  de uso de texto no sensible (aceptable).
- **Estado:** adoptada e implementada.

### ADR-04 · Multi-tenant: equipo→org por token, cuenta→org por `org_id`
- **Contexto:** un producto para muchas empresas exige aislamiento estricto entre clientes.
- **Decisión:** toda tabla de cliente lleva `org_id`. El **token de agente** determina la organización de cada
  equipo; `ConsoleUser.org_id` determina la de cada cuenta de consola. La API filtra siempre por organización.
- **Consecuencias:** aislamiento claro y simple. Requiere RLS en producción como segunda barrera (si falta un
  filtro, hay fuga entre clientes).
- **Estado:** adoptada; RLS **pendiente** de activar.

### ADR-05 · Identidad del equipo por hostname
- **Contexto:** el agente de Windows y la extensión reportan del mismo equipo y deben unirse.
- **Decisión:** se unen por `hostname`. Como el navegador no puede leer `%COMPUTERNAME%`, el hostname llega por
  política (`install-policy.ps1`) o lo escribe el usuario en el auto-enrolamiento.
- **Consecuencias:** unión simple sin instalar identificadores. En auto-enrolamiento manual el usuario debe poner un
  nombre consistente para que se una con el agente.
- **Estado:** adoptada e implementada.

### ADR-06 · Reutilizar Lab 2 como base
- **Contexto:** existía un central (Lab 2) ya maduro: multi-tenant, agente Windows, catálogo, assessment, Docker.
- **Decisión:** construir **sobre** Lab 2 (agregar la capa DLP) en vez de reescribir; la extensión reemplaza al
  prototipo de navegador metadata-only.
- **Consecuencias:** ahorro de semanas. Hay que respetar sus patrones y arrastrar sus pendientes (Entra, RLS,
  migraciones).
- **Estado:** adoptada e implementada.

### ADR-07 · El canal escritorio es responsabilidad del cliente
- **Contexto:** la extensión no puede ver apps nativas de IA (ChatGPT desktop, etc.).
- **Decisión:** el producto **no** construye un proxy. El escritorio se cierra con controles del cliente: bloquear
  los apps por AppLocker/Intune (forzar uso web, donde la extensión protege) y DNS para inventario. El producto
  entrega listas y guía.
- **Consecuencias:** evita construir un proxy TLS frágil e invasivo. Queda un hueco de contenido en escritorio que
  se cubre por política, no por código. Se declara como alcance.
- **Estado:** adoptada (guía + listas entregadas).

### ADR-08 · No construir DNS/proxy propio; infra del cliente
- **Contexto:** producto para muchas empresas; no se debe operar DNS de nadie.
- **Decisión:** cada empresa corre su propio DNS (self-host como AdGuard/Pi-hole, o un tercero — su elección). No se
  escribe un resolver desde cero (riesgo de seguridad); se reutiliza software probado. El proxy con inspección TLS
  se descarta por privacidad (descifraría todo el tráfico).
- **Consecuencias:** cero dependencia de terceros para el producto; la cobertura de escritorio por contenido queda
  fuera salvo que el cliente meta un CASB.
- **Estado:** adoptada.

### ADR-09 · Entrega confiable: idempotencia + outbox
- **Contexto:** la red falla; no se deben perder ni duplicar eventos.
- **Decisión:** cada evento lleva un `event_id`; el servidor rechaza duplicados (`UniqueConstraint(org_id,
  event_id)`). La extensión usa patrón **outbox**: guarda local, envía, y solo borra al confirmarse (200); si falla,
  reintenta por alarma.
- **Consecuencias:** sin pérdida ni duplicados. El dato vive brevemente en `storage.local` del navegador (buffer).
- **Estado:** adoptada e implementada.

### ADR-10 · Configuración: política (zero-touch) + auto-enrolamiento (popup)
- **Contexto:** configurar cada equipo no debe requerir entrar a la consola de admin.
- **Decisión:** dos caminos. **Política** (GPO/Intune) empuja URL+token+hostname a toda la flota. **Auto-enrolamiento**:
  el usuario pega el token en la pestaña "Conexión" del popup. La política, si existe, manda y bloquea el formulario.
- **Consecuencias:** estandarizable para flotas y flexible para equipos sueltos. El token debe entregarse por un
  canal seguro.
- **Estado:** adoptada e implementada.

### ADR-11 · Token hasheado; nada de secretos en el código
- **Decisión:** del token de agente solo se guarda el hash (se muestra una vez al crearlo). La extensión no trae el
  token ni la URL hardcodeados: llegan por `managed storage` o el popup.
- **Consecuencias:** si se filtra el `.zip` de la extensión, no hay secretos dentro.
- **Estado:** adoptada e implementada.

### ADR-12 · Roles con mínimo privilegio
- **Decisión:** Seguridad ve el contenido sensible; TI ve inventario; **Dirección solo agregados por área, sin
  nombres ni contenido**. El personal de Cognitive opera varias organizaciones.
- **Consecuencias:** el dato más sensible lo ve el menor número de personas. Requiere disciplina al agregar vistas.
- **Estado:** adoptada e implementada (endpoint de datos sensibles restringido a Seguridad/Cognitive).

### ADR-13 · Aviso/cancelación de descargas de apps de IA
- **Contexto:** parte del canal escritorio sí es alcanzable desde el navegador: la **descarga** del instalador.
- **Decisión:** la extensión detecta la descarga de un instalador de IA (por nombre o dominio del catálogo), la
  **pausa** y deja al usuario cancelar o continuar.
- **Consecuencias:** cubre el momento "voy a instalar" sin proxy. No cubre USB ni apps ya instaladas (eso es
  AppLocker).
- **Estado:** adoptada e implementada.

### ADR-14 · Datos dinámicos, no semilla
- **Contexto:** Lab 2 vivía de datos ficticios fijos.
- **Decisión:** el camino principal es `DATA_MODE=real`: el tablero arranca vacío y se llena con lo que reportan los
  equipos. La semilla queda como modo demo separado.
- **Consecuencias:** producto real; la demo puede usar semilla como escenario + captura en vivo.
- **Estado:** en progreso (modo real existe; falta volver dinámicos el catálogo y las preguntas del assessment).

### ADR-15 · Migraciones con Alembic (no `create_all` en producción)
- **Contexto:** `create_all` solo crea tablas que faltan; nunca modifica una ya existente. En un cliente con
  datos reales, un cambio de esquema (p. ej. agregar una columna) no se aplicaría y rompería la app.
- **Decisión:** el esquema de producción lo gobierna **Alembic**. Hay un historial versionado
  (`0001_baseline` → `0002_password_hash`) que se aplica con `alembic upgrade head` desde el entrypoint del
  contenedor antes de arrancar la API. En modo demo se mantiene `create_all` (base desechable).
- **Consecuencias:** cambios de esquema sin perder datos y con vuelta atrás (`downgrade`); todos los clientes
  siguen el mismo historial. Cada cambio de modelo exige generar su migración. Una base creada antes con
  `create_all` se adopta con `alembic stamp 0001_baseline` y luego `upgrade head`.
- **Estado:** adoptada e implementada.

### ADR-16 · Login con contraseña propia detrás de una interfaz de autenticación
- **Contexto:** la consola necesitaba acceso seguro para el 20-nov sin sumar infraestructura ni depender de
  terceros. Entra ID es un tercero; Keycloak es un proyecto en sí mismo.
- **Decisión:** `AUTH_MODE=password`: correo + contraseña con hash **bcrypt** sobre el `ConsoleUser` existente.
  Toda la validación pasa por una única función `authenticate()`, de modo que mañana Keycloak/Entra (SSO) se
  enchufan ahí sin tocar routers ni la pantalla de login. Se guarda solo el hash; las contraseñas temporales se
  muestran una vez (como el token de agente).
- **Consecuencias:** cierra la seguridad de acceso ya, sin terceros ni infraestructura nueva. No da SSO (eso
  queda para la fase enterprise). `dev` (selector de roles, sin contraseña) se conserva solo para demo.
- **Estado:** adoptada e implementada.

---

## Deudas técnicas y pendientes (conscientes)

| Tema | Hoy | Objetivo |
| --- | --- | --- |
| Autenticación de consola | `AUTH_MODE=password` (correo + contraseña, hash bcrypt) o `dev` para demo | SSO opcional (Keycloak/Entra) detrás de la misma interfaz `authenticate()` |
| Aislamiento multi-tenant | Solo filtro por `org_id` en la API | Activar RLS en PostgreSQL |
| Esquema de base | Migraciones con Alembic en modo real; `create_all` solo en demo | — (resuelto) |
| Catálogo y preguntas | YAML / código | Editables desde la consola, versionados |
| Captura de la extensión | Probada en ChatGPT/Claude | Validar en los 5 chatbots top; es mantenimiento continuo |
| Almacenamiento en claro | `storage.local` (buffer temporal) | Cifrado en reposo en el servidor |

---

## Modelos de amenaza y qué cubre cada capa

- **Fuga accidental por navegador** → la extensión (aviso + enmascarado). *Cubierto.*
- **Apps de IA de escritorio** → bloqueo por endpoint del cliente + aviso de descarga de la extensión. *Cubierto por capas.*
- **Evasión deliberada de un insider** (celular, foto a la pantalla) → **política interna + RRHH**, no es alcance técnico.
- **Fuga entre organizaciones** → `org_id` + RLS (pendiente). 
- **Robo del token** → hash en reposo + entrega segura + revocación desde la consola.
