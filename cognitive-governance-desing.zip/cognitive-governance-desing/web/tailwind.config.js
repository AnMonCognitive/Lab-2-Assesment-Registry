/**
 * Sistema visual de Cognitive (Figma "IA-Gobernanza"): barra lateral negra, fondo gris claro,
 * rojo de marca para acción y estado activo; verde / naranja / rojo como colores oficiales de estado.
 * Los nombres de token anteriores (navy, cream, accent, data, ink) se conservan y apuntan a la paleta nueva,
 * para que todas las vistas tomen el estilo sin reescribir clases.
 */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // Superficie oscura (barra lateral, login)
        navy: { DEFAULT: "#000000", 700: "#1C1C1C", 500: "#3A3A3A" },
        // Fondo, tarjetas y líneas
        cream: { DEFAULT: "#F4F4F4", card: "#FFFFFF", line: "#E4E4E4" },
        // Rojo de marca
        accent: { DEFAULT: "#EC3A3F", dark: "#C9252B", tint: "#FDECEC" },
        // "data" = estado positivo / aprobado (verde oficial)
        data: { DEFAULT: "#178A66", tint: "#E4F7F0", soft: "#B9B9C3" },
        ink: { DEFAULT: "#141414", 2: "#3F3F46", 3: "#6B6B73" },
        ok: { DEFAULT: "#21D299", line: "#44C398", text: "#147A5A", tint: "#E4F7F0" },
        warn: { DEFAULT: "#EC9022", line: "#E68E2D", text: "#9A5608", tint: "#FDF1E2" },
        bad: { DEFAULT: "#EC3A3F", line: "#D84345", text: "#C9252B", tint: "#FDECEC" },
        labs: { DEFAULT: "#5F2977", tint: "#F3ECF6", line: "#8A55A3" },
      },
      fontFamily: {
        display: ["Poppins", "Arial", "sans-serif"],
        sans: ["Poppins", "Arial", "sans-serif"],
        mono: ["Poppins", "Arial", "sans-serif"],
      },
      backgroundImage: {
        brand: "linear-gradient(90deg, #F2A33A 0%, #EC3A3F 50%, #7B2C8F 100%)",
      },
      boxShadow: {
        glow: "0 0 0 1px #EC3A3F, 0 4px 14px rgba(236, 58, 63, 0.28)",
        "glow-sm": "0 2px 10px rgba(236, 58, 63, 0.35)",
      },
    },
  },
  plugins: [],
};
