import { createContext, useContext, useEffect, useState } from "react";
import { BrowserRouter, Navigate, NavLink, Route, Routes } from "react-router-dom";
import { api, Org, setApiOrg, User } from "./api";
import ChangePassword from "./components/ChangePassword";
import { ICONS } from "./components/icons";
import Alerts from "./pages/Alerts";
import Areas from "./pages/Areas";
import AssessmentPage from "./pages/Assessment";
import Catalog from "./pages/Catalog";
import Devices from "./pages/Devices";
import Login from "./pages/Login";
import Operations from "./pages/Operations";
import SensitiveEvents from "./pages/SensitiveEvents";
import Summary from "./pages/Summary";
import Systems from "./pages/Systems";
import Tools from "./pages/Tools";

type Session = { user: User; org: Org | null; orgs: Org[]; setOrg: (o: Org) => void; logout: () => void };
const Ctx = createContext<Session | null>(null);
export const useSession = () => useContext(Ctx)!;

const SEES_PEOPLE = ["admin_cognitive", "consultor", "cliente_admin_ti", "cliente_seguridad"];

const NAV = [
  { to: "/resumen", label: "Resumen", icon: "resumen", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/herramientas", label: "Herramientas de IA", icon: "herramientas", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/dispositivos", label: "Dispositivos", icon: "dispositivos", show: (u: User) => SEES_PEOPLE.includes(u.role) },
  { to: "/datos-sensibles", label: "Datos sensibles", icon: "datos", show: (u: User) => ["admin_cognitive", "consultor", "cliente_seguridad"].includes(u.role) },
  { to: "/areas", label: "Áreas", icon: "areas", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/sistemas", label: "Sistemas de IA propios", icon: "sistemas", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/alertas", label: "Alertas", icon: "alertas", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/assessment", label: "Readiness Assessment", icon: "assessment", show: (u: User) => u.role !== "analista_catalogo" },
  { to: "/catalogo", label: "Catálogo y Labs", icon: "catalogo", show: (u: User) => u.is_cognitive, internal: true },
  { to: "/operacion", label: "Operación", icon: "operacion", show: (u: User) => ["admin_cognitive", "consultor"].includes(u.role), internal: true },
];

function Brand({ compact }: { compact?: boolean }) {
  return (
    <div>
      <img src="/brand/cognitive-mark.png" alt="Cognitive" className="h-[18px] w-auto" />
      {!compact && <>
        <p className="text-[9.5px] font-medium tracking-[0.2em] text-white/70 mt-2.5">COGNITIVE · LAB 2</p>
        <p className="font-display font-semibold text-[15px] leading-tight text-white">Governance Platform</p>
      </>}
    </div>
  );
}

/** Ítems del menú. `rail` = barra contraída (tablet): solo ícono, el activo en círculo rojo. */
function NavItems({ user, rail, onNavigate }: { user: User; rail?: boolean; onNavigate?: () => void }) {
  return (
    <nav className={`flex-1 py-4 space-y-1 ${rail ? "px-2 flex flex-col items-center" : "px-3"}`}>
      {NAV.filter((n) => n.show(user)).map((n, i, arr) => (
        <div key={n.to} className={rail ? "w-full flex flex-col items-center" : ""}>
          {n.internal && !arr[i - 1]?.internal && (rail
            ? <span className="block w-6 h-px bg-white/20 my-3" />
            : <p className="px-4 pt-5 pb-2 text-[9.5px] font-medium tracking-[0.2em] text-white/50">INTERNO COGNITIVE</p>)}
          <NavLink to={n.to} onClick={onNavigate} title={rail ? n.label : undefined} className={({ isActive }) => rail
            ? `group relative flex h-10 w-10 items-center justify-center rounded-full transition ${isActive ? "bg-accent text-white" : "text-white/70 hover:text-white"}`
            : `group relative flex items-center rounded-full px-4 py-2.5 text-[13px] transition ${isActive ? "bg-accent text-white font-medium" : "text-white/75 hover:text-white"}`}>
            {({ isActive }) => <>
              {!isActive && <span className={`absolute top-1/2 -translate-y-1/2 h-3.5 w-[3px] rounded-full bg-gradient-to-b from-[#F2A33A] via-[#EC3A3F] to-[#7B2C8F] opacity-0 group-hover:opacity-100 transition ${rail ? "-left-0.5" : "left-1.5"}`} />}
              {rail ? ICONS[n.icon] : n.label}
            </>}
          </NavLink>
        </div>
      ))}
    </nav>
  );
}

function UserFooter({ user, logout }: { user: User; logout: () => void }) {
  return (
    <div className="px-5 py-5 border-t border-white/15 text-xs">
      <p className="font-semibold text-white">{user.name}</p>
      <p className="text-white/60 mt-0.5">{user.role_label}</p>
      <button onClick={logout} className="mt-1 block text-white/60 hover:text-white">Cerrar sesión</button>
      <ChangePassword />
    </div>
  );
}

function Shell({ s }: { s: Session }) {
  const { user, org, orgs, setOrg, logout } = s;
  const home = user.role === "analista_catalogo" ? "/catalogo" : "/resumen";
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <div className="min-h-screen flex">
      {/* Escritorio: barra completa · Tablet: barra contraída con íconos */}
      <aside className="hidden md:flex lg:hidden w-16 shrink-0 bg-navy flex-col items-center no-print sticky top-0 h-screen">
        <div className="pt-6 pb-2"><img src="/brand/cognitive-mark.png" alt="Cognitive" className="h-4 w-auto" /></div>
        <NavItems user={user} rail />
        <button onClick={logout} title="Cerrar sesión" className="mb-5 text-white/60 hover:text-white text-[10px]">Salir</button>
      </aside>
      <aside className="hidden lg:flex w-60 shrink-0 bg-navy flex-col no-print sticky top-0 h-screen overflow-y-auto">
        <div className="px-5 pt-6 pb-4"><Brand /></div>
        <NavItems user={user} />
        <UserFooter user={user} logout={logout} />
      </aside>

      <div className="flex-1 min-w-0">
        {/* Móvil: barra superior negra con botón de menú */}
        <div className="md:hidden bg-navy text-white flex items-center justify-between px-4 py-3 no-print">
          <div className="flex items-center gap-3">
            <img src="/brand/cognitive-mark.png" alt="Cognitive" className="h-4 w-auto" />
            <div><p className="text-[9px] tracking-[0.2em] text-white/70">COGNITIVE · LAB 2</p><p className="text-sm font-semibold leading-tight">Governance Platform</p></div>
          </div>
          <button onClick={() => setMenuOpen(true)} aria-label="Abrir menú" className="h-9 w-9 rounded-full border border-white/30 flex items-center justify-center">{ICONS.menu}</button>
        </div>
        {menuOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-navy flex flex-col no-print">
            <div className="flex items-center justify-between px-5 pt-5"><Brand /><button onClick={() => setMenuOpen(false)} aria-label="Cerrar menú" className="text-white">{ICONS.close}</button></div>
            <NavItems user={user} onNavigate={() => setMenuOpen(false)} />
            <UserFooter user={user} logout={logout} />
          </div>
        )}

        <header className="min-h-14 border-b border-cream-line bg-white flex flex-wrap items-center justify-between gap-2 px-4 md:px-8 py-2.5 no-print">
          <div className="flex items-center gap-3 text-[13px]">
            <span className="text-ink-2">Organización:</span>
            {user.is_cognitive && orgs.length > 0 ? (
              <select className="input w-60 py-1.5" value={org?.id ?? ""} onChange={(e) => setOrg(orgs.find((o) => o.id === Number(e.target.value))!)}>
                {orgs.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
              </select>
            ) : <span className="font-semibold">{org?.name ?? "Catálogo global"}</span>}
          </div>
          <span className="text-[10.5px] tracking-[0.12em] text-ink-2">{user.data_mode === "real" ? "VERSIÓN PRELIMINAR · DATOS REALES" : "VERSIÓN PRELIMINAR · DATOS FICTICIOS"}</span>
        </header>
        <main className="p-4 md:p-8 max-w-[1400px]" key={org?.id ?? 0}>
          <Routes>
            <Route path="/resumen" element={<Summary />} />
            <Route path="/herramientas" element={<Tools />} />
            <Route path="/dispositivos" element={<Devices />} />
            <Route path="/datos-sensibles" element={<SensitiveEvents />} />
            <Route path="/areas" element={<Areas />} />
            <Route path="/sistemas" element={<Systems />} />
            <Route path="/alertas" element={<Alerts />} />
            <Route path="/assessment" element={<AssessmentPage />} />
            <Route path="/catalogo" element={<Catalog />} />
            <Route path="/operacion" element={<Operations />} />
            <Route path="*" element={<Navigate to={home} replace />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null | undefined>(undefined);
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [org, setOrgState] = useState<Org | null>(null);

  const setOrg = (o: Org | null) => {
    setApiOrg(o && user?.is_cognitive ? o.id : null);
    setOrgState(o);
  };

  useEffect(() => { api<User>("/api/auth/me").then(setUser).catch(() => setUser(null)); }, []);

  useEffect(() => {
    if (!user) return;
    api<Org[]>("/api/orgs").then((list) => {
      setOrgs(list);
      const first = list.find((o) => o.kind === "cliente") ?? list[0] ?? null;
      setApiOrg(first && user.is_cognitive ? first.id : null);
      setOrgState(first);
    });
  }, [user]);

  if (user === undefined) return null;
  if (!user) return <Login onLogin={setUser} />;
  if (user.role !== "analista_catalogo" && !org) return null;

  const logout = () => api("/api/auth/logout", { method: "POST" }).finally(() => { setApiOrg(null); setUser(null); });
  const s: Session = { user, org, orgs, setOrg, logout };
  return (
    <Ctx.Provider value={s}>
      <BrowserRouter>
        <Shell s={s} />
      </BrowserRouter>
    </Ctx.Provider>
  );
}
