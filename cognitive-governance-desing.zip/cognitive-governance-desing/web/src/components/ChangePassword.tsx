import { FormEvent, useEffect, useState } from "react";
import { api } from "../api";

/** Botón + panel para que el usuario con sesión cambie su contraseña. Solo se muestra en AUTH_MODE=password. */
export default function ChangePassword() {
  const [enabled, setEnabled] = useState(false);
  const [open, setOpen] = useState(false);
  const [cur, setCur] = useState("");
  const [next, setNext] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api<{ auth_mode: string }>("/api/auth/mode").then((m) => setEnabled(m.auth_mode === "password")).catch(() => {});
  }, []);

  if (!enabled) return null;

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setMsg(null); setBusy(true);
    api("/api/auth/change-password", { method: "POST", json: { current_password: cur, new_password: next } })
      .then(() => { setMsg({ ok: true, text: "Contraseña actualizada." }); setCur(""); setNext(""); })
      .catch((err) => setMsg({ ok: false, text: err.message }))
      .finally(() => setBusy(false));
  };

  return (
    <>
      <button onClick={() => { setOpen(true); setMsg(null); }} className="mt-1 block text-white/60 hover:text-white">
        Cambiar contraseña
      </button>
      {open && (
        <div className="fixed inset-0 z-50 bg-navy/60 flex items-center justify-center p-4 no-print" onClick={() => setOpen(false)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={submit}
            className="bg-cream-card text-ink rounded-xl border border-cream-line w-full max-w-sm p-6">
            <h3 className="font-display text-lg font-bold">Cambiar contraseña</h3>
            <p className="text-xs text-ink-3 mt-1 mb-4">Si entraste con una contraseña temporal, cámbiala aquí.</p>
            <label className="block text-sm font-medium mb-1">Contraseña actual</label>
            <input type="password" required value={cur} onChange={(e) => setCur(e.target.value)}
              className="input mb-3" autoComplete="current-password" />
            <label className="block text-sm font-medium mb-1">Nueva contraseña</label>
            <input type="password" required value={next} onChange={(e) => setNext(e.target.value)}
              className="input mb-4" autoComplete="new-password" />
            {msg && <p className={`text-sm mb-3 ${msg.ok ? "text-ok-text" : "text-accent-dark"}`}>{msg.text}</p>}
            <div className="flex gap-2 justify-end">
              <button type="button" onClick={() => setOpen(false)} className="btn-ghost">Cerrar</button>
              <button type="submit" disabled={busy} className="btn-primary">{busy ? "Guardando…" : "Guardar"}</button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
