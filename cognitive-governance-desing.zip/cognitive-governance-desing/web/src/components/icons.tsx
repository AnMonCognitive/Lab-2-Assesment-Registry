/** Íconos de línea para la navegación (barra contraída y menú móvil). 20×20, trazo actual. */
import { ReactNode } from "react";

const I = ({ children }: { children: ReactNode }) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    {children}
  </svg>
);

export const ICONS: Record<string, ReactNode> = {
  resumen: <I><rect x="4" y="4" width="6.5" height="6.5" rx="1" /><rect x="13.5" y="4" width="6.5" height="4" rx="1" /><rect x="13.5" y="11" width="6.5" height="9" rx="1" /><rect x="4" y="13.5" width="6.5" height="6.5" rx="1" /></I>,
  herramientas: <I><path d="M14.5 6.5a3.5 3.5 0 0 0 4.6 4.6L20 12l-8 8-3-3 8-8-.9-.9a3.5 3.5 0 0 0-1.6-1.6Z" /><path d="m4 4 6 6M4 4l1.5 4L8 5.5Z" /></I>,
  dispositivos: <I><rect x="3" y="5" width="13" height="10" rx="1" /><path d="M2 19h11" /><rect x="17" y="9" width="5" height="10" rx="1" /></I>,
  datos: <I><path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6Z" /><path d="M9.5 12h5M12 9.5v5" /></I>,
  areas: <I><circle cx="12" cy="8" r="2.5" /><circle cx="5.5" cy="10" r="2" /><circle cx="18.5" cy="10" r="2" /><path d="M7.5 18a4.5 4.5 0 0 1 9 0M2 18a3.5 3.5 0 0 1 4.5-3.3M22 18a3.5 3.5 0 0 0-4.5-3.3" /></I>,
  sistemas: <I><circle cx="12" cy="12" r="2.5" /><circle cx="5" cy="6" r="2" /><circle cx="19" cy="6" r="2" /><circle cx="5" cy="18" r="2" /><circle cx="19" cy="18" r="2" /><path d="m6.6 7.3 3.6 3M17.4 7.3l-3.6 3M6.6 16.7l3.6-3M17.4 16.7l-3.6-3" /></I>,
  alertas: <I><path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15Z" /><path d="M10 20.5a2 2 0 0 0 4 0" /></I>,
  assessment: <I><rect x="3.5" y="4.5" width="17" height="15" rx="1.5" /><path d="M7 9h5M7 13h4M7 16.5h3" /><path d="m14 13.5 1.6 1.6 3-3.2" /></I>,
  catalogo: <I><path d="M9.5 3.5h5M10.5 3.5v6L5 19a1 1 0 0 0 .9 1.5h12.2A1 1 0 0 0 19 19l-5.5-9.5v-6" /><path d="M7.5 15h9" /></I>,
  operacion: <I><path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1" /><path d="M15 4v4M9 10v4M17 16v4" /></I>,
  menu: <I><path d="M4 7h16M4 12h16M4 17h16" /></I>,
  close: <I><path d="m6 6 12 12M18 6 6 18" /></I>,
  eye: <I><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z" /><circle cx="12" cy="12" r="3" /></I>,
  eyeOff: <I><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.6 6.6A17 17 0 0 0 2 12s3.6 7 10 7a9.6 9.6 0 0 0 5.4-1.6" /><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" /></I>,
  warn: <I><path d="M12 4 2.5 20h19Z" /><path d="M12 10v4.5M12 17.5v.01" /></I>,
};
