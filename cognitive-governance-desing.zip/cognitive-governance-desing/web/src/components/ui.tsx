import { ReactNode, useEffect, useState } from "react";

/* ------------------------------------------------------------------ colores oficiales de estado */
export const STATUS_LABEL: Record<string, string> = { aprobada: "Aprobada", en_revision: "En revisión", no_aprobada: "No aprobada" };
export const STATUS_COLOR: Record<string, string> = { aprobada: "#21D299", en_revision: "#EC9022", no_aprobada: "#EC3A3F" };
export const CHART = { grid: "#E4E4E4", axis: "#6B6B73", ok: "#21D299", warn: "#EC9022", bad: "#EC3A3F", labs: "#5F2977", neutral: "#B9B9C3" };

type Tone = "ok" | "warn" | "bad" | "labs" | "neutral" | "ink";
const TONE_BORDER: Record<Tone, string> = {
  ok: "border-ok-line text-ink", warn: "border-warn-line text-ink", bad: "border-bad-line text-ink",
  labs: "border-labs text-labs", neutral: "border-[#B5B5BD] text-ink-2", ink: "border-ink text-ink",
};
const TONE_BAR: Record<Tone, string> = { ok: "bg-ok-line", warn: "bg-warn-line", bad: "bg-bad-line", labs: "bg-labs", neutral: "bg-[#B5B5BD]", ink: "bg-ink" };

/** Chip: cápsula con borde de color, sin relleno, texto en mayúsculas. */
export function Chip({ tone, children, dashed }: { tone: Tone; children: ReactNode; dashed?: boolean }) {
  return (
    <span className={`inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-full border-[1.5px] ${dashed ? "border-dashed" : ""} bg-white px-2.5 py-[3px] text-[10px] font-semibold uppercase tracking-[0.1em] ${TONE_BORDER[tone]}`}>
      {children}
    </span>
  );
}

/* ------------------------------------------------------------------ encabezados */
export function PageHeader({ eyebrow, title, children, subtitle }: { eyebrow: string; title: string; children?: ReactNode; subtitle?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
      <div className="min-w-0">
        <p className="eyebrow mb-2">{eyebrow}</p>
        <h1 className="font-display text-[28px] leading-tight font-bold tracking-[-0.01em]">{title}</h1>
        {subtitle && <p className="text-sm text-ink-2 mt-2">{subtitle}</p>}
      </div>
      <div className="flex gap-2 no-print">{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ tarjetas */
export function Card({ title, children, className = "", action, variant = "base" }:
  { title?: string; children: ReactNode; className?: string; action?: ReactNode; variant?: "base" | "alert" }) {
  return (
    <section className={`${variant === "alert" ? "card-alert" : "card"} p-5 ${className}`}>
      {title && (
        <div className="flex items-center justify-between gap-3 mb-4">
          <h2 className="font-display font-semibold text-[15px]">{title}</h2>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

/** Tarjeta de contenido generado por IA: borde discontinuo morado con banda "Borrador IA". */
export function AiCard({ note = "Ficha de Cognitive Labs · preliminar, sin revisar", children, className = "" }:
  { note?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`card-ai ${className}`}>
      <div className="flex items-center gap-3 bg-labs-tint px-3 py-2 border-b border-dashed border-labs-line">
        <AiDraftChip />
        <p className="text-[11px] text-ink-2 leading-snug">{note}</p>
      </div>
      <div className="p-4">{children}</div>
    </section>
  );
}

export function AiDraftChip({ label = "Borrador IA" }: { label?: string }) {
  return <Chip tone="labs"><Orb size={12} />{label}</Chip>;
}

/** Orbe de Cognitive Labs (marca del contenido de IA). Se usa como instancia; no se recolorea. */
export function Orb({ size = 14 }: { size?: number }) {
  return <img src="/brand/orb.png" alt="" aria-hidden width={size} height={size} className="inline-block shrink-0" style={{ width: size, height: size }} />;
}

/* ------------------------------------------------------------------ KPIs */
export function Kpi({ label, value, hint, highlight, hero }:
  { label: string; value: ReactNode; hint?: string; highlight?: boolean; hero?: boolean }) {
  return (
    <div className={`rounded-xl p-4 bg-white border ${highlight ? "border-accent shadow-[0_4px_16px_rgba(236,58,63,0.18)]" : "border-cream-line"}`}>
      <p className="text-xs text-ink-2 leading-snug">{label}</p>
      <p className={`font-display font-bold mt-1 tabular-nums tracking-tight ${hero || highlight ? "text-[44px] leading-[1.05]" : "text-[28px] leading-tight"}`}>{value}</p>
      {hint && <p className="text-xs text-ink-3 mt-1">{hint}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ indicadores */
const RISK_TONE: Record<string, Tone> = { bajo: "ok", medio: "warn", alto: "bad" };
const STATUS_TONE: Record<string, Tone> = { aprobada: "ok", en_revision: "warn", no_aprobada: "bad" };
const VERDICT_TONE: Record<string, Tone> = { adoptar: "ok", esperar: "warn", descartar: "bad" };
const SEV_TONE: Record<string, Tone> = { baja: "ok", media: "warn", alta: "bad" };

/** Riesgo en tablas: franja redondeada del color oficial + texto. */
export function RiskBadge({ risk, chip }: { risk: string; chip?: boolean }) {
  const tone = RISK_TONE[risk] ?? "neutral";
  if (chip) return <Chip tone={tone}>Riesgo {risk}</Chip>;
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap shrink-0 text-[10px] font-semibold uppercase tracking-[0.1em]">
      <span className={`h-3.5 w-[3px] rounded-full ${TONE_BAR[tone]}`} />Riesgo {risk}
    </span>
  );
}

export function StatusBadge({ status }: { status: string }) {
  return <Chip tone={STATUS_TONE[status] ?? "neutral"}>{STATUS_LABEL[status] ?? status}</Chip>;
}

/** Veredicto de Labs: orbe + veredicto en mayúsculas con línea del color oficial debajo. `compact` = cápsula. */
export function VerdictBadge({ verdict, compact }: { verdict: string; compact?: boolean }) {
  const key = (verdict ?? "").toLowerCase();
  const tone = VERDICT_TONE[key] ?? "neutral";
  if (compact) return <Chip tone={tone}>{verdict}</Chip>;
  return (
    <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
      <Orb size={13} />
      <span className="relative text-[10px] font-semibold uppercase tracking-[0.1em] pb-[3px]">
        {verdict}
        <span className={`absolute left-0 right-0 bottom-0 h-[2px] rounded-full ${TONE_BAR[tone]}`} />
      </span>
    </span>
  );
}

export function SeverityChip({ severity }: { severity: string }) {
  return <Chip tone={SEV_TONE[severity] ?? "neutral"} dashed={severity !== "alta"}>{severity}</Chip>;
}

/** Fila de alerta: franja de severidad a la izquierda, título y nivel. */
export function AlertLine({ title, severity }: { title: ReactNode; severity: string }) {
  return (
    <div className="flex gap-3">
      <span className={`w-[3px] rounded-full shrink-0 ${TONE_BAR[SEV_TONE[severity] ?? "neutral"]}`} />
      <span className="text-sm">{title}<span className="block text-xs text-ink-3">Severidad {severity}</span></span>
    </div>
  );
}

/** Filtro en píldora con contador. El activo se rellena con tinta. */
export function FilterPill({ active, label, count, onClick }: { active: boolean; label: string; count?: number; onClick: () => void }) {
  return (
    <button onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-full border-[1.5px] px-3.5 py-1.5 text-xs font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-2
        ${active ? "bg-ink border-ink text-white" : "bg-white border-[#B5B5BD] text-ink hover:border-ink"}`}>
      {label}{count != null && <span className={`font-normal ${active ? "text-white/70" : "text-ink-3"}`}>{count}</span>}
    </button>
  );
}

/** Control de decisión: tres opciones en una cápsula; la elegida se rellena con su color oficial. */
export function DecisionControl({ value, onChange, disabled }: { value?: string; onChange: (v: string) => void; disabled?: boolean }) {
  const opts: [string, string, string][] = [
    ["aprobada", "Aprobar", "bg-ok text-ink"], ["en_revision", "En revisión", "bg-warn text-ink"], ["no_aprobada", "No aprobar", "bg-bad text-white"],
  ];
  return (
    <div className="inline-flex rounded-full border border-[#B5B5BD] bg-white p-1 gap-1" role="radiogroup">
      {opts.map(([v, label, on]) => (
        <button key={v} role="radio" aria-checked={value === v} disabled={disabled} onClick={() => value !== v && onChange(v)}
          className={`rounded-full px-4 py-1.5 text-xs font-semibold transition disabled:cursor-wait focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink
            ${value === v ? on : "text-ink-2 hover:text-ink"}`}>
          {label}
        </button>
      ))}
    </div>
  );
}

/** Escala 0–5 del assessment: seis círculos; el elegido en negro. */
export function ScoreScale({ value, onChange, readOnly }: { value: number | null | undefined; onChange?: (v: number) => void; readOnly?: boolean }) {
  return (
    <div className="flex gap-1.5 shrink-0">
      {[0, 1, 2, 3, 4, 5].map((n) => (
        <button key={n} type="button" disabled={readOnly} onClick={() => onChange?.(n)} aria-pressed={value === n}
          className={`h-7 w-7 rounded-full border text-xs tabular-nums transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink focus-visible:ring-offset-1
            ${value === n ? "bg-ink border-ink text-white font-semibold" : "bg-white border-[#9A9AA2] text-ink"} ${readOnly ? "cursor-default" : "hover:border-ink"}`}>
          {n}
        </button>
      ))}
    </div>
  );
}

/** Fila de dato: etiqueta a la izquierda, valor a la derecha (envuelve si es largo). */
export function DataRow({ k, v }: { k: string; v: ReactNode }) {
  return (
    <div className="grid grid-cols-[minmax(0,10rem)_1fr] gap-4 text-sm py-1">
      <span className="text-ink-3">{k}</span><span className="text-ink min-w-0 break-words">{v}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ estados */
export function Loading() {
  return <p className="text-ink-3 text-sm py-10 text-center">Cargando…</p>;
}

export function ErrorBox({ error }: { error: unknown }) {
  return <div className="card-alert p-4 text-accent-dark text-sm">{String((error as Error)?.message ?? error)}</div>;
}

/** Hook simple para cargar datos de la API y recargarlos. */
export function useLoad<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let alive = true;
    setError(null);
    fn().then((d) => alive && setData(d)).catch((e) => alive && setError(e));
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);
  return { data, error, reload: () => setTick((t) => t + 1) };
}

/** Cajón lateral: se abre a la derecha con el fondo atenuado. Cabecera con etiqueta, título, subtítulo y Cerrar. */
export function Drawer({ open, onClose, children, label, title, subtitle }:
  { open: boolean; onClose: () => void; children: ReactNode; label?: string; title?: string; subtitle?: string }) {
  useEffect(() => {
    if (!open) return;
    const esc = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", esc);
    return () => window.removeEventListener("keydown", esc);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-40 flex justify-end no-print" onClick={onClose}>
      <div className="absolute inset-0 bg-black/45" />
      <aside role="dialog" aria-modal className="relative w-full max-w-xl h-full overflow-y-auto bg-white rounded-l-2xl shadow-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="px-7 pt-6">
          <div className="flex items-start justify-between gap-4">
            <p className="text-[10.5px] font-semibold uppercase tracking-[0.18em] text-ink-2 pt-2">{label ?? ""}</p>
            <button className="btn-ghost py-1 px-3 text-xs" onClick={onClose}>Cerrar</button>
          </div>
          {title && <h2 className="font-display text-[28px] font-bold leading-tight tracking-tight mt-2">{title}</h2>}
          {subtitle && <p className="text-sm text-ink-2">{subtitle}</p>}
        </div>
        <div className="px-7 pb-8 pt-4">{children}</div>
      </aside>
    </div>
  );
}
