import { useState } from "react";
import ReactMarkdown from "react-markdown";
import { PolarAngleAxis, PolarGrid, PolarRadiusAxis, Radar, RadarChart, ResponsiveContainer } from "recharts";
import { api, fmtDate } from "../api";
import { CHART, Card, ErrorBox, FilterPill, Loading, PageHeader, ScoreScale, useLoad } from "../components/ui";

export default function AssessmentPage() {
  const { data, error, reload } = useLoad<any>(() => api("/api/assessment"), []);
  const report = useLoad<any>(() => api("/api/assessment/report").catch(() => null), [data?.report_generated_at]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<"diagnostico" | "reporte">("diagnostico");

  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;

  const radar = data.dimensions.map((d: any) => ({ dim: d.dimension, score: d.promedio ?? 0 }));
  const answered = data.dimensions.filter((d: any) => d.promedio != null).length;
  const generate = async () => {
    setBusy(true); setErr("");
    try { await api("/api/assessment/report", { method: "POST" }); reload(); setTab("reporte"); }
    catch (e: any) { setErr(e.message); }
    finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader eyebrow="Readiness Assessment" title="¿Qué tan lista está la empresa para la IA?">
        {data.can_edit && <button className="btn-accent" disabled={busy || answered === 0} onClick={generate}>{busy ? "Redactando con IA…" : "Generar reporte con IA"}</button>}
        {report.data && tab === "reporte" && <button className="btn-ghost" onClick={() => window.print()}>Imprimir / PDF</button>}
      </PageHeader>
      {err && <p className="text-accent-dark text-sm mb-4">{err}</p>}

      <div className="flex gap-2 mb-5 no-print">
        <FilterPill active={tab === "diagnostico"} label="Diagnóstico" onClick={() => setTab("diagnostico")} />
        {report.data
          ? <FilterPill active={tab === "reporte"} label="Reporte" onClick={() => setTab("reporte")} />
          : <span className="inline-flex items-center rounded-full border-[1.5px] border-cream-line px-3.5 py-1.5 text-xs font-semibold text-ink-3" title="Genera el reporte primero">Reporte</span>}
      </div>

      {tab === "diagnostico" && (
        <>
          <div className="grid lg:grid-cols-3 gap-5 mb-5">
            <Card title="Madurez por dimensión" className="lg:col-span-2">
              {answered === 0 ? <p className="text-sm text-ink-3 py-16 text-center">Aún no hay respuestas. El consultor de Cognitive llena el cuestionario con el cliente.</p> : (
                <div className="h-80">
                  <ResponsiveContainer>
                    <RadarChart data={radar} outerRadius="75%">
                      <PolarGrid stroke={CHART.grid} />
                      <PolarAngleAxis dataKey="dim" tick={{ fontSize: 12, fill: CHART.axis, fontFamily: "Poppins" }} />
                      <PolarRadiusAxis domain={[0, 5]} tickCount={6} tick={false} axisLine={false} />
                      <Radar dataKey="score" stroke={CHART.labs} fill={CHART.labs} fillOpacity={0.95} strokeWidth={1.5} dot={{ r: 3, fill: "#fff", stroke: CHART.labs, strokeWidth: 1.5 }} />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </Card>
            <Card title="Puntaje">
              <p className="font-display text-[44px] leading-none font-bold tracking-tight">{data.maturity != null ? data.maturity.toFixed(1) : "—"}<span className="text-lg font-medium text-ink-2"> / 5</span></p>
              <p className="text-xs text-ink-3 mt-2">{answered} de 9 dimensiones respondidas</p>
              <ul className="mt-4 space-y-1 text-[13px]">
                {[...data.dimensions].filter((d: any) => d.promedio != null).sort((a: any, b: any) => a.promedio - b.promedio).map((d: any, i: number) => (
                  <li key={d.dimension} className={`flex justify-between items-center rounded-md px-3 py-1.5 ${i < 3 ? "bg-warn-tint font-semibold" : ""}`}>
                    <span className="flex items-center gap-2">{i < 3 ? <span className="h-1.5 w-1.5 rounded-full bg-warn" /> : <span className="w-1.5" />}{d.dimension}</span>
                    <span className="tabular-nums">{d.promedio.toFixed(1)}</span>
                  </li>
                ))}
              </ul>
              <p className="text-xs text-ink-3 mt-3">En naranja, las 3 brechas prioritarias.</p>
            </Card>
          </div>
          <div className="space-y-4">
            {data.questions.map((g: any) => (
              <Card key={g.dimension} title={g.dimension}>
                <div className="space-y-4">
                  {g.items.map((q: any) => <Question key={q.id} q={q} editable={data.can_edit} onSaved={reload} />)}
                </div>
              </Card>
            ))}
          </div>
        </>
      )}

      {tab === "reporte" && report.data && (
        <div className="card p-8 max-w-4xl">
          <p className="text-xs text-ink-3 mb-4 no-print">
            Generado {fmtDate(report.data.generated_at)} · modo {report.data.mode === "bedrock" ? "Claude en Amazon Bedrock" : "simulado (sin Bedrock)"} ·
            borrador para revisión del consultor
          </p>
          {report.data.mode !== "bedrock" && (
            <div className="rounded-md bg-warn-tint px-4 py-2.5 mb-5 text-xs flex items-center gap-2 no-print">
              <span className="h-1.5 w-1.5 rounded-full bg-warn" />Borrador generado en modo simulado (sin Bedrock). Revisar antes de entregar.
            </div>
          )}
          <div className="markdown"><ReactMarkdown>{report.data.markdown}</ReactMarkdown></div>
        </div>
      )}
    </>
  );
}

function Question({ q, editable, onSaved }: { q: any; editable: boolean; onSaved: () => void }) {
  const [score, setScore] = useState<number | null>(q.score);
  const [evidence, setEvidence] = useState(q.evidence ?? "");
  const dirty = score !== q.score || evidence !== (q.evidence ?? "");
  const save = () => api(`/api/assessment/answers/${q.id}`, { method: "PUT", json: { score, evidence: evidence || null } }).then(onSaved);
  return (
    <div className="flex flex-col md:flex-row md:items-start gap-3 border-b border-cream-line pb-4 last:border-0 last:pb-0">
      <div className="flex-1 min-w-0">
        <p className="text-[13px] font-semibold">{q.question}</p>
        {editable
          ? <textarea className="input mt-2 text-xs" rows={2} placeholder="Evidencia (qué se observó)" value={evidence} onChange={(e) => setEvidence(e.target.value)} />
          : <p className="text-xs text-ink-2 mt-1">{q.evidence ?? "Sin evidencia registrada"}</p>}
      </div>
      <div className="flex items-center gap-3 md:pl-4">
        <ScoreScale value={score} readOnly={!editable} onChange={setScore} />
        {editable && dirty && <button className="btn-primary px-5 py-1.5 text-xs" onClick={save}>Guardar</button>}
      </div>
    </div>
  );
}
