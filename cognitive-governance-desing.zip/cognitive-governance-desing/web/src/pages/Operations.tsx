import { useState } from "react";
import { api, fmtDate } from "../api";
import { useSession } from "../App";
import { Card, ErrorBox, Kpi, Loading, PageHeader, useLoad } from "../components/ui";
import { AccessCard, AgentCard } from "./Setup";

export default function Operations() {
  const { user } = useSession();
  const usage = useLoad<any>(() => api("/api/admin/llm-usage"), []);
  const audit = useLoad<any[]>(() => (user.role === "admin_cognitive" ? api("/api/admin/audit") : Promise.resolve([])), []);
  const [msg, setMsg] = useState("");
  const isAdmin = user.role === "admin_cognitive";

  if (usage.error) return <ErrorBox error={usage.error} />;
  if (!usage.data) return <Loading />;
  const u = usage.data;
  const tokens = u.calls.reduce((s: number, c: any) => s + c.input_tokens + c.output_tokens, 0);

  const sync = () => api("/api/admin/fleet-sync", { method: "POST" })
    .then((r) => setMsg(`Fleet: ${r.equipos} equipos, ${r.detecciones} detecciones, ${r.desconocidos} desconocidos`))
    .catch((e) => setMsg(e.message));
  const reset = () => confirmReset() && api("/api/admin/reset-demo", { method: "POST" }).then(() => window.location.reload());

  return (
    <>
      <PageHeader eyebrow="Interno Cognitive" title="Operación">
        {isAdmin && <button className="btn-ghost" onClick={sync}>Sincronizar con Fleet</button>}
        {isAdmin && user.data_mode !== "real" && <button className="btn-ghost" onClick={reset}>Reiniciar datos de demo</button>}
      </PageHeader>
      {msg && <div className="card p-3 mb-4 text-sm">{msg}</div>}

      <AgentCard />
      {isAdmin && <AccessCard />}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Kpi label="Modo de IA" value={u.mode === "bedrock" ? "Bedrock" : "Simulado"} hint={u.mode === "bedrock" ? "Claude en Amazon Bedrock" : "Sin llamadas a AWS"} />
        <Kpi label="Llamadas registradas" value={u.calls.length} />
        <Kpi label="Tokens" value={tokens.toLocaleString("es-MX")} />
        <Kpi label="Costo acumulado" value={`$${u.total_cost_usd.toFixed(2)}`} hint={`Tope diario ${u.daily_budget_usd} USD`} />
      </div>

      <Card title="Consumo de IA (semilla del Agent Monitor)" className="mb-5">
        <table className="tbl">
          <thead><tr><th>Fecha</th><th>Tarea</th><th>Modelo</th><th>Modo</th><th className="text-right">Entrada</th><th className="text-right">Salida</th><th className="text-right">Costo USD</th><th className="text-right">Latencia</th></tr></thead>
          <tbody>
            {u.calls.map((c: any, i: number) => (
              <tr key={i}>
                <td className="text-xs">{fmtDate(c.at)}</td><td>{c.task}</td><td className="font-mono text-xs">{c.model}</td><td>{c.mode}</td>
                <td className="text-right tabular-nums">{c.input_tokens}</td><td className="text-right tabular-nums">{c.output_tokens}</td>
                <td className="text-right tabular-nums">{c.cost_usd.toFixed(4)}</td><td className="text-right tabular-nums">{c.latency_ms} ms</td>
              </tr>
            ))}
            {u.calls.length === 0 && <tr><td colSpan={8} className="text-ink-3 text-center py-6">Aún no hay llamadas. Clasifica un desconocido o genera un reporte.</td></tr>}
          </tbody>
        </table>
      </Card>

      {isAdmin && (
        <Card title="Bitácora de accesos">
          <table className="tbl">
            <thead><tr><th>Fecha</th><th>Usuario</th><th>Acción</th><th>Objeto</th></tr></thead>
            <tbody>
              {(audit.data ?? []).slice(0, 50).map((r, i) => (
                <tr key={i}><td className="text-xs">{fmtDate(r.at)}</td><td>{r.user}</td><td className="font-mono text-xs">{r.action}</td><td className="text-xs text-ink-3">{r.object ?? "—"}</td></tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </>
  );
}

function confirmReset() {
  return window.confirm("Se borrarán los cambios y se volverán a generar los datos de demo. ¿Continuar?");
}
