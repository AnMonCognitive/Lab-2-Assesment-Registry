import { useMemo, useState } from "react";
import { api, fmtDate } from "../api";
import { Chip, ErrorBox, Loading, PageHeader, useLoad } from "../components/ui";

const AGENT: Record<string, [string, "ok" | "warn" | "neutral"]> = {
  activo: ["Activo", "ok"],
  sin_reportar: ["Sin reportar", "warn"],
  pendiente: ["Pendiente de instalar", "neutral"],
};

export default function Devices() {
  const { data, error } = useLoad<any[]>(() => api("/api/devices"), []);
  const [q, setQ] = useState("");
  const [onlyRisk, setOnlyRisk] = useState(false);
  const rows = useMemo(() => (data ?? []).filter((d) =>
    (!onlyRisk || d.unapproved > 0) && `${d.hostname} ${d.person} ${d.area} ${d.tools.join(" ")}`.toLowerCase().includes(q.toLowerCase())),
  [data, q, onlyRisk]);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const pending = data.filter((d) => d.agent_status === "pendiente").length;

  return (
    <>
      <PageHeader eyebrow="Registry · Inventario" title="Dispositivos" />
      {pending > 0 && (
        <div className="card p-4 mb-4 text-sm flex gap-3"><span className="w-[3px] rounded-full bg-warn-line shrink-0" /><span>
          {pending} equipos esperan el agente. Genera un token en <b>Operación → Agente de inventario</b> e instala el agente
          (<span className="font-mono">agent/windows/install.ps1</span>); los equipos y sus herramientas aparecerán aquí.
        </span></div>
      )}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <input className="input max-w-sm" placeholder="Buscar equipo, persona, área o herramienta" value={q} onChange={(e) => setQ(e.target.value)} />
        <label className="text-sm flex items-center gap-2"><input type="checkbox" className="h-4 w-4 accent-[#EC3A3F]" checked={onlyRisk} onChange={(e) => setOnlyRisk(e.target.checked)} /> Solo con IA no aprobada</label>
        <span className="ml-auto text-sm text-ink-3">{rows.length} de {data.length} equipos</span>
      </div>
      <div className="overflow-x-auto rounded-lg border border-cream-line">
        <table className="tbl">
          <thead><tr><th>Equipo</th><th>Persona</th><th>Área</th><th>Sistema</th><th>Agente</th><th>Última conexión</th><th>Herramientas de IA</th></tr></thead>
          <tbody>
            {rows.map((d) => {
              const [label, tone] = AGENT[d.agent_status] ?? [d.agent_status, "neutral"];
              return (
                <tr key={d.id}>
                  <td className="text-xs font-medium whitespace-nowrap">{d.hostname}</td>
                  <td>{d.person}</td>
                  <td className="text-ink-2">{d.area}</td>
                  <td className="text-ink-2">{d.os}</td>
                  <td><Chip tone={tone}>{label}</Chip></td>
                  <td className="text-xs text-ink-3">{fmtDate(d.last_seen)}</td>
                  <td className="text-xs">
                    {d.tools.length ? d.tools.join(", ") : <span className="text-ink-3">—</span>}
                    {d.unapproved > 0 && <span className="flex items-center gap-1.5 mt-1 font-semibold"><span className="h-1.5 w-1.5 rounded-full bg-bad" />{d.unapproved} no aprobada(s)</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}
