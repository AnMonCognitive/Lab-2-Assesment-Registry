import { api, fmtDate } from "../api";
import { useSession } from "../App";
import { ErrorBox, Loading, PageHeader, SeverityChip, useLoad } from "../components/ui";

const TYPE: Record<string, string> = {
  ia_no_aprobada: "IA no aprobada", extension_nueva: "Extensión nueva", sistema_sin_dueno: "Sistema sin dueño", oauth_amplio: "Permisos OAuth amplios", ia_riesgo_alto: "IA de riesgo alto",
};
const STRIPE: Record<string, string> = { alta: "bg-bad", media: "bg-warn", baja: "bg-ok" };
const CAN_ACT = ["admin_cognitive", "consultor", "cliente_seguridad"];

export default function Alerts() {
  const { user } = useSession();
  const { data, error, reload } = useLoad<any[]>(() => api("/api/alerts"), []);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const act = (id: number, status: string) => api(`/api/alerts/${id}`, { method: "PATCH", json: { status } }).then(reload);
  const canAct = CAN_ACT.includes(user.role);

  return (
    <>
      <PageHeader eyebrow="Gobierno" title="Alertas" />
      <p className="text-sm text-ink-2 -mt-3 mb-5">La plataforma avisa y recomienda; el bloqueo lo hace TI con las herramientas que la empresa ya tiene.</p>
      <div className="space-y-3">
        {data.map((a) => (
          <div key={a.id} className={`card p-4 pl-5 flex flex-wrap md:flex-nowrap gap-4 items-start relative overflow-hidden ${a.status !== "abierta" ? "opacity-60" : ""}`}>
            <span className={`absolute left-2 top-3 bottom-3 w-[3px] rounded-full ${STRIPE[a.severity] ?? "bg-ink-3"}`} />
            <span className="shrink-0 pt-0.5"><SeverityChip severity={a.severity} /></span>
            <div className="flex-1 min-w-0">
              <p className="font-semibold">{a.title}</p>
              <p className="text-sm text-ink-2 mt-0.5">{a.detail}</p>
              <p className="text-xs text-ink-3 mt-1">{TYPE[a.type] ?? a.type} · {fmtDate(a.created_at)} · {a.status}</p>
            </div>
            {canAct && a.status === "abierta" && (
              <div className="flex gap-2 shrink-0">
                <button className="btn-ghost" onClick={() => act(a.id, "atendida")}>Atendida</button>
                <button className="btn-text" onClick={() => act(a.id, "descartada")}>Descartar</button>
              </div>
            )}
            {canAct && a.status !== "abierta" && <button className="btn-ghost shrink-0" onClick={() => act(a.id, "abierta")}>Reabrir</button>}
          </div>
        ))}
      </div>
    </>
  );
}
