import { useMemo, useState } from "react";
import { api, fmtDate } from "../api";
import { ErrorBox, Kpi, Loading, PageHeader, useLoad } from "../components/ui";

type Ev = {
  id: number; time: string; day: string; host: string; tool: string;
  sensitive: Record<string, number>; decision: string | null; text: string;
  browser: string; person: string | null; hostname: string | null; area: string | null;
};

const DECISION: Record<string, [string, string]> = {
  enviado: ["Enviado de todos modos", "bg-accent-tint text-accent-dark"],
  ocultado: ["Ocultó los datos", "bg-data-tint text-data"],
};

const sensitiveLabel = (s: Record<string, number>) =>
  Object.entries(s || {})
    .map(([tag, n]) => `${tag.toLowerCase().replace(/_/g, " ")}${n > 1 ? ` ×${n}` : ""}`)
    .join(", ");

export default function SensitiveEvents() {
  const { data, error } = useLoad<Ev[]>(() => api("/api/prompt-events"), []);
  const [q, setQ] = useState("");
  const [onlySent, setOnlySent] = useState(false);

  const rows = useMemo(() => (data ?? []).filter((e) =>
    (!onlySent || e.decision === "enviado") &&
    `${e.hostname} ${e.person} ${e.area} ${e.tool} ${sensitiveLabel(e.sensitive)} ${e.text}`
      .toLowerCase().includes(q.toLowerCase())),
  [data, q, onlySent]);

  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;

  const sent = data.filter((e) => e.decision === "enviado").length;
  const hidden = data.filter((e) => e.decision === "ocultado").length;
  const people = new Set(data.map((e) => e.person).filter(Boolean)).size;

  return (
    <>
      <PageHeader eyebrow="Seguridad · DLP" title="Datos sensibles" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        <Kpi label="Eventos" value={data.length} />
        <Kpi label="Enviados de todos modos" value={sent} highlight={sent > 0} hint="datos que salieron a la IA" />
        <Kpi label="Datos ocultados a tiempo" value={hidden} hint="se quitaron antes de enviar" />
        <Kpi label="Personas" value={people} />
      </div>

      <div className="flex items-center gap-3 mb-4">
        <input className="input max-w-sm" placeholder="Buscar persona, equipo, herramienta o tipo de dato"
               value={q} onChange={(e) => setQ(e.target.value)} />
        <label className="text-sm flex items-center gap-2">
          <input type="checkbox" checked={onlySent} onChange={(e) => setOnlySent(e.target.checked)} />
          Solo "enviados de todos modos"
        </label>
        <span className="ml-auto text-sm text-ink-3">{rows.length} de {data.length} eventos</span>
      </div>

      {data.length === 0 ? (
        <div className="card p-6 text-sm text-ink-3">
          Aún no hay eventos. Cuando alguien intente enviar datos sensibles a una herramienta de IA desde el navegador
          con la extensión instalada, aparecerán aquí (texto ya enmascarado).
        </div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>Fecha y hora</th><th>Persona</th><th>Equipo</th><th>Área</th><th>Herramienta</th>
                <th>Datos detectados</th><th>Decisión</th><th>Mensaje (enmascarado)</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((e) => {
                const [label, cls] = e.decision ? (DECISION[e.decision] ?? [e.decision, ""]) : ["Detectado", "bg-white border border-cream-line text-ink-2"];
                return (
                  <tr key={e.id}>
                    <td className="text-xs text-ink-3 whitespace-nowrap">{fmtDate(e.time)}</td>
                    <td>{e.person ?? <span className="text-ink-3">—</span>}</td>
                    <td className="font-mono text-xs whitespace-nowrap">{e.hostname ?? "—"}</td>
                    <td className="text-ink-2">{e.area ?? "—"}</td>
                    <td className="whitespace-nowrap">{e.tool}</td>
                    <td className="text-xs font-medium text-accent-dark">{sensitiveLabel(e.sensitive) || "—"}</td>
                    <td><span className={`rounded-full px-2 py-0.5 text-xs whitespace-nowrap ${cls}`}>{label}</span></td>
                    <td className="text-xs text-ink-2 max-w-sm"><span className="line-clamp-2 break-words">{e.text}</span></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
