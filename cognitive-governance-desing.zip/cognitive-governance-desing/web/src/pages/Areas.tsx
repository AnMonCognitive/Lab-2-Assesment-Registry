import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api } from "../api";
import { CHART, Card, ErrorBox, Loading, PageHeader, useLoad } from "../components/ui";

const axis = { fontSize: 12, fill: CHART.axis, fontFamily: "Poppins" };

export default function Areas() {
  const { data, error } = useLoad<any[]>(() => api("/api/areas"), []);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const rows = data.map((a) => ({ ...a, aprobada: a.using_ai - a.unapproved }));
  return (
    <>
      <PageHeader eyebrow="Registry · Inventario" title="Uso de IA por área" />
      <Card title="Personas que usan IA, por área">
        <div style={{ height: 60 + rows.length * 48 }}>
          <ResponsiveContainer>
            <BarChart data={rows} layout="vertical" margin={{ left: 40, right: 24 }}>
              <CartesianGrid horizontal={false} stroke={CHART.grid} />
              <XAxis type="number" tick={axis} tickLine={false} axisLine={false} allowDecimals={false} />
              <YAxis type="category" dataKey="area" tick={axis} tickLine={false} axisLine={false} width={120} />
              <Tooltip />
              <Legend iconType="circle" wrapperStyle={{ fontSize: 12, fontFamily: "Poppins" }} />
              <Bar dataKey="aprobada" name="Solo IA aprobada o en revisión" stackId="a" fill={CHART.ok} />
              <Bar dataKey="unapproved" name="Con al menos una IA no aprobada" stackId="a" fill={CHART.bad} radius={[0, 3, 3, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <p className="text-xs text-ink-3 mt-2">Vista agregada: Dirección del cliente ve esta información sin nombres de personas.</p>
      </Card>
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4 mt-5">
        {data.map((a) => (
          <div key={a.area} className="card p-4">
            <p className="font-display font-semibold">{a.area}</p>
            <p className="text-sm text-ink-2 mt-1">{a.using_ai} de {a.people} personas usan IA</p>
            <p className={`text-sm flex items-center gap-2 mt-1 ${a.unapproved ? "font-semibold" : "text-ink-3"}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${a.unapproved ? "bg-bad" : "bg-ok"}`} />{a.unapproved} con IA no aprobada
            </p>
            <p className="text-xs text-ink-3 mt-2">Más usada: {a.top_tool ?? "—"}</p>
          </div>
        ))}
      </div>
    </>
  );
}
