import { Link } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { api, fmtDay } from "../api";
import { useSession } from "../App";
import { AlertLine, CHART, Card, ErrorBox, Kpi, Loading, PageHeader, RiskBadge, STATUS_COLOR, StatusBadge, useLoad } from "../components/ui";

const axis = { fontSize: 11, fill: CHART.axis, fontFamily: "Poppins" };

export default function Summary() {
  const { org } = useSession();
  const { data, error } = useLoad(() => api("/api/summary"), []);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const k = data.kpis;
  const trend = data.trend.map((t: any) => ({ ...t, label: fmtDay(t.week) }));

  return (
    <>
      <PageHeader eyebrow={`Resumen · ${org?.name}`} title="¿Qué tan expuestos estamos y qué atendemos primero?" />

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-5 items-stretch">
        <Kpi label="Equipos con agente activo" value={`${k.coverage_pct}%`} hint={`${k.devices} equipos inventariados`} />
        <Kpi label="Herramientas de IA detectadas" value={k.tools_detected} hint={`${k.high_risk_tools} de riesgo alto`} />
        <Kpi label="Herramientas aprobadas" value={`${k.approved_pct}%`} hint={`${data.status_counts.aprobada} de ${k.tools_detected}`} />
        <Kpi label="Personas con IA no aprobada" value={k.people_unapproved} hint={`de ${k.people_using_ai} que usan IA`} highlight />
        <Kpi label="Madurez (assessment)" value={k.maturity != null ? k.maturity.toFixed(1) : "—"} hint="escala de 0 a 5" />
      </div>

      <div className="grid lg:grid-cols-3 gap-5 mb-5">
        <Card title="Herramientas detectadas por estado, semanal" className="lg:col-span-2">
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={trend} margin={{ left: -20, right: 8 }}>
                <CartesianGrid vertical={false} stroke={CHART.grid} />
                <XAxis dataKey="label" tick={axis} tickLine={false} axisLine={false} />
                <YAxis tick={axis} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 12, fontFamily: "Poppins" }} />
                <Bar dataKey="aprobadas" name="Aprobadas" stackId="s" fill={STATUS_COLOR.aprobada} />
                <Bar dataKey="en_revision" name="En revisión" stackId="s" fill={STATUS_COLOR.en_revision} />
                <Bar dataKey="no_aprobadas" name="No aprobadas" stackId="s" fill={STATUS_COLOR.no_aprobada} radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Atender primero" action={<Link to="/alertas" className="btn-text text-xs py-0">Ver alertas →</Link>}>
          <ul className="space-y-4">
            {data.attention.map((a: any) => (
              <li key={a.id}><AlertLine title={a.title} severity={a.severity} /></li>
            ))}
            {data.attention.length === 0 && <li className="text-sm text-ink-3">Sin alertas abiertas.</li>}
          </ul>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <Card title="Uso de IA por área" className="lg:col-span-2">
          <div className="overflow-x-auto"><table className="tbl">
            <thead><tr><th>Área</th><th>Personas</th><th>Usan IA</th><th>Con IA no aprobada</th><th>Herramienta más usada</th></tr></thead>
            <tbody>
              {data.by_area.map((a: any) => (
                <tr key={a.area}>
                  <td className="font-medium">{a.area}</td>
                  <td className="tabular-nums">{a.people}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-24 rounded-full bg-cream-line overflow-hidden">
                        <div className="h-full bg-ok" style={{ width: `${a.people ? (100 * a.using_ai) / a.people : 0}%` }} />
                      </div>
                      <span className="tabular-nums text-xs">{a.using_ai}</span>
                    </div>
                  </td>
                  <td className={`tabular-nums ${a.unapproved ? "text-accent-dark font-semibold" : ""}`}>{a.unapproved}</td>
                  <td className="text-ink-2">{a.top_tool ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table></div>
          <p className="text-xs text-ink-3 mt-3">Agregado por área: esta vista no muestra nombres de personas.</p>
        </Card>

        <Card title="Personas con IA no aprobada">
          <div className="h-40">
            <ResponsiveContainer>
              <LineChart data={trend} margin={{ left: -24, right: 8, top: 8 }}>
                <CartesianGrid vertical={false} stroke={CHART.grid} />
                <XAxis dataKey="label" tick={axis} tickLine={false} axisLine={false} interval={3} />
                <YAxis tick={axis} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip />
                <Line dataKey="personas_no_aprobada" name="Personas" stroke={CHART.bad} strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs font-semibold mt-5 mb-2">Herramientas más usadas</p>
          <ul className="space-y-2.5 text-sm">
            {data.top_tools.slice(0, 5).map((t: any) => (
              <li key={t.id} className="flex items-center justify-between gap-2">
                <span className="truncate">{t.name} <span className="text-ink-3 text-xs">· {t.people} personas</span></span>
                <span className="flex gap-1 shrink-0"><StatusBadge status={t.status} /></span>
              </li>
            ))}
          </ul>
          {data.top_tools.some((t: any) => t.risk === "alto") && (
            <p className="text-xs text-ink-3 mt-3 flex items-center gap-1">Incluye herramientas con <RiskBadge risk="alto" /></p>
          )}
        </Card>
      </div>
    </>
  );
}
