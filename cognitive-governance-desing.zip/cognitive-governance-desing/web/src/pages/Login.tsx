import { FormEvent, ReactNode, useEffect, useState } from "react";
import { api, User } from "../api";
import { ICONS } from "../components/icons";

type Mode = { auth_mode: string; data_mode: string };

/** Pantalla de acceso: panel de marca (negro) + panel de formulario (claro). */
export default function Login({ onLogin }: { onLogin: (u: User) => void }) {
  const [mode, setMode] = useState<Mode | null>(null);
  const [error, setError] = useState("");
  const [view, setView] = useState<"login" | "registro">("login");

  useEffect(() => {
    api<Mode>("/api/auth/mode").then(setMode).catch(() => setError("No se pudo conectar con la API"));
  }, []);

  const real = mode?.data_mode === "real";
  const footnote = mode?.auth_mode === "dev"
    ? (real ? "Versión preliminar · datos reales" : "Versión preliminar · todos los datos son ficticios")
    : "Acceso protegido con Microsoft Entra ID y verificación de dos pasos (MFA)";

  return (
    <div className="min-h-screen grid lg:grid-cols-[1.5fr_1fr]">
      <div className="bg-navy text-white px-8 py-8 lg:px-14 lg:py-10 flex flex-col justify-between gap-10 min-h-[320px]">
        <img src="/brand/cognitive-logo.png" alt="Cognitive" className="h-6 w-auto self-start" />
        <div>
          <p className="inline-flex items-center gap-2.5 text-[10px] font-medium tracking-[0.2em] text-white/70 before:block before:h-[2px] before:w-6 before:rounded-full before:bg-brand">
            COGNITIVE AI LAB · LAB 2
          </p>
          <h1 className="font-display text-4xl lg:text-[56px] font-bold mt-5 leading-[1.05] tracking-tight">Readiness<br />Assessment +<br />Registry</h1>
          <p className="text-white/75 text-sm lg:text-base mt-5 max-w-lg">Qué IA se usa en la empresa, quién la usa, con qué riesgo, y qué tan lista está la organización.</p>
        </div>
        <p className="text-[11px] text-white/50">{footnote}</p>
      </div>

      <div className="bg-cream px-6 py-10 lg:px-10 flex flex-col justify-center">
        <div className="w-full max-w-md mx-auto">
          {mode?.auth_mode === "password"
            ? (view === "login"
              ? <PasswordLogin onLogin={onLogin} error={error} setError={setError} onRegister={() => { setError(""); setView("registro"); }} />
              : <Register onBack={() => { setError(""); setView("login"); }} />)
            : mode?.auth_mode === "dev"
              ? <DevLogin onLogin={onLogin} real={real} error={error} setError={setError} />
              : mode?.auth_mode === "entra"
                ? <EntraLogin />
                : <p className="text-sm text-ink-3">{error || "Cargando…"}</p>}
        </div>
      </div>
    </div>
  );
}

function Heading({ eyebrow, title, children }: { eyebrow: string; title: string; children?: ReactNode }) {
  return (
    <div className="mb-6">
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="font-display text-[26px] font-bold mt-2 leading-tight tracking-tight">{title}</h2>
      {children && <p className="text-[13px] text-ink-2 mt-2">{children}</p>}
    </div>
  );
}

function MicrosoftButton({ label }: { label: string }) {
  return (
    <button type="button" disabled title="Pendiente: Microsoft Entra ID" className="btn-ghost w-full">
      {label} <span className="font-normal text-ink-3">(pendiente)</span>
    </button>
  );
}

const Or = () => <p className="text-center text-xs text-ink-3 my-4">o</p>;

function PasswordInput({ value, onChange, placeholder, autoComplete }:
  { value: string; onChange: (v: string) => void; placeholder?: string; autoComplete: string }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <input type={show ? "text" : "password"} required value={value} onChange={(e) => onChange(e.target.value)}
        className="input pr-10" placeholder={placeholder} autoComplete={autoComplete} />
      <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? "Ocultar contraseña" : "Mostrar contraseña"}
        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-ink-3 hover:text-ink [&>svg]:h-[18px] [&>svg]:w-[18px]">
        {show ? ICONS.eyeOff : ICONS.eye}
      </button>
    </div>
  );
}

// -------------------------------------------------- correo + contraseña
function PasswordLogin({ onLogin, error, setError, onRegister }:
  { onLogin: (u: User) => void; error: string; setError: (s: string) => void; onRegister: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [forgot, setForgot] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setError(""); setBusy(true);
    api<User>("/api/auth/login", { method: "POST", json: { email: email.trim(), password } })
      .then(onLogin)
      .catch((err) => setError(err.message))
      .finally(() => setBusy(false));
  };

  return (
    <form onSubmit={submit}>
      <Heading eyebrow="Iniciar sesión" title="Accede a tu cuenta">Entra con tu cuenta de Microsoft o con tu correo y contraseña.</Heading>
      <MicrosoftButton label="Acceder con Microsoft" />
      <Or />
      <label className="label" htmlFor="email">Correo</label>
      <input id="email" type="email" autoFocus required value={email} onChange={(e) => setEmail(e.target.value)}
        className="input mb-4" placeholder="nombre@empresa.com" autoComplete="username" />
      <label className="label">Contraseña</label>
      <PasswordInput value={password} onChange={setPassword} placeholder="Tu contraseña" autoComplete="current-password" />
      <div className="text-right mt-2 mb-5">
        <button type="button" onClick={() => setForgot((f) => !f)} className="text-xs underline underline-offset-2 text-ink-2 hover:text-ink">¿Olvidaste tu contraseña?</button>
        {forgot && <p className="text-xs text-ink-2 mt-1 text-left">Pide al administrador de la consola que te asigne una contraseña temporal (Operación → Usuarios).</p>}
      </div>
      <button type="submit" disabled={busy} className="btn-primary w-full">{busy ? "Entrando…" : "Acceder"}</button>
      {error && <p className="text-accent-dark text-sm mt-4">{error}</p>}
      <p className="text-center text-xs text-ink-2 mt-5">¿No tienes cuenta? <button type="button" onClick={onRegister} className="font-semibold text-ink underline underline-offset-2">Crear cuenta</button></p>
    </form>
  );
}

// -------------------------------------------------- registro (solicitud de acceso)
function Register({ onBack }: { onBack: () => void }) {
  const [f, setF] = useState({ name: "", email: "", org: "", password: "", confirm: "", terms: false });
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const set = (k: keyof typeof f, v: string | boolean) => setF((x) => ({ ...x, [k]: v }));
  const MIN = 10; // igual que PASSWORD_MIN_LEN por defecto en la API

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (f.password.length < MIN) return setMsg({ ok: false, text: `La contraseña debe tener al menos ${MIN} caracteres.` });
    if (f.password !== f.confirm) return setMsg({ ok: false, text: "Las contraseñas no coinciden." });
    // La API todavía no tiene alta autoservicio: las cuentas las crea el administrador en Operación.
    setMsg({ ok: true, text: "El registro en línea aún no está activo. Pide al administrador de Cognitive que cree tu cuenta con este correo; recibirás una contraseña temporal." });
  };

  return (
    <form onSubmit={submit}>
      <Heading eyebrow="Crear cuenta" title="Registra tu cuenta">Completa tus datos para solicitar acceso a la plataforma.</Heading>
      <MicrosoftButton label="Registrarse con Microsoft" />
      <Or />
      <div className="space-y-3.5">
        <label className="block"><span className="label">Nombre completo</span>
          <input required className="input" placeholder="Nombre y apellidos" value={f.name} onChange={(e) => set("name", e.target.value)} autoComplete="name" /></label>
        <label className="block"><span className="label">Correo de trabajo</span>
          <input required type="email" className="input" placeholder="nombre@empresa.com" value={f.email} onChange={(e) => set("email", e.target.value)} autoComplete="email" /></label>
        <label className="block"><span className="label">Organización</span>
          <input required className="input" placeholder="Nombre de tu organización" value={f.org} onChange={(e) => set("org", e.target.value)} autoComplete="organization" /></label>
        <label className="block"><span className="label">Contraseña</span>
          <PasswordInput value={f.password} onChange={(v) => set("password", v)} placeholder={`Mínimo ${MIN} caracteres`} autoComplete="new-password" /></label>
        <label className="block"><span className="label">Confirmar contraseña</span>
          <PasswordInput value={f.confirm} onChange={(v) => set("confirm", v)} placeholder="Repite tu contraseña" autoComplete="new-password" /></label>
        <label className="flex items-center gap-2.5 text-xs">
          <input type="checkbox" required checked={f.terms} onChange={(e) => set("terms", e.target.checked)} className="h-4 w-4 accent-[#EC3A3F]" />
          Acepto los términos de uso y el aviso de privacidad
        </label>
      </div>
      <button type="submit" className="btn-primary w-full mt-5">Crear cuenta</button>
      {msg && <p className={`text-sm mt-4 ${msg.ok ? "text-ink-2" : "text-accent-dark"}`}>{msg.text}</p>}
      <p className="text-center text-xs text-ink-2 mt-5">¿Ya tienes una cuenta? <button type="button" onClick={onBack} className="font-semibold text-ink underline underline-offset-2">Iniciar sesión</button></p>
    </form>
  );
}

// -------------------------------------------------- selector de roles (solo desarrollo/demo)
function DevLogin({ onLogin, real, error, setError }:
  { onLogin: (u: User) => void; real: boolean; error: string; setError: (s: string) => void }) {
  const [users, setUsers] = useState<User[]>([]);
  useEffect(() => {
    api<User[]>("/api/auth/dev-users").then(setUsers).catch(() => setError("No se pudo conectar con la API"));
  }, []);

  const login = (email: string) =>
    api<User>("/api/auth/login", { method: "POST", json: { email } }).then(onLogin).catch((e) => setError(e.message));

  return (
    <>
      <Heading eyebrow="Iniciar sesión" title={real ? "Elige tu usuario" : "Elige un usuario de prueba"}>
        En producción el acceso es con tu cuenta de Microsoft (Entra ID + MFA). Aquí cada usuario representa un rol, para mostrar qué ve cada quién.
      </Heading>
      <MicrosoftButton label="Acceder con Microsoft" />
      <div className="space-y-2.5 mt-5">
        {users.map((u) => (
          <button key={u.id} onClick={() => login(u.email)}
            className="group relative w-full text-left bg-white border border-cream-line rounded-lg pl-4 pr-3 py-3 flex items-center justify-between gap-3 overflow-hidden transition hover:border-[#CFCFD4] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ink">
            <span className="absolute left-0 top-0 bottom-0 w-[3px] bg-gradient-to-b from-[#F2A33A] via-[#EC3A3F] to-[#7B2C8F] opacity-0 group-hover:opacity-100 transition" />
            <span className="min-w-0">
              <span className="font-semibold text-[13px] block">{u.role_label}</span>
              <span className="text-xs text-ink-2">{u.email} · {u.org_name}</span>
            </span>
            <span className="shrink-0 rounded-md border border-ink/70 bg-white px-3 py-1 text-xs font-semibold transition group-hover:bg-accent group-hover:border-accent group-hover:text-white group-hover:shadow-glow-sm">Acceder</span>
          </button>
        ))}
      </div>
      {error && <p className="text-accent-dark text-sm mt-4">{error}</p>}
    </>
  );
}

// -------------------------------------------------- Entra ID (pendiente)
function EntraLogin() {
  return (
    <>
      <Heading eyebrow="Iniciar sesión" title="Accede con Microsoft">El acceso de esta organización es con su cuenta de Microsoft (Entra ID + MFA).</Heading>
      <MicrosoftButton label="Acceder con Microsoft" />
    </>
  );
}
