import { useMemo, useState } from "react";
import { api, fmtDate } from "../api";
import { AiCard, DataRow, DecisionControl, Drawer, ErrorBox, FilterPill, Loading, PageHeader, RiskBadge, StatusBadge, VerdictBadge, useLoad } from "../components/ui";

const FILTERS = [["todas", "Todas"], ["no_aprobada", "No aprobadas"], ["en_revision", "En revisión"], ["aprobada", "Aprobadas"]];

export default function Tools() {
  const { data, error, reload } = useLoad<any[]>(() => api("/api/tools"), []);
  const [filter, setFilter] = useState("todas");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<number | null>(null);

  const rows = useMemo(() => (data ?? []).filter((r) =>
    (filter === "todas" || r.status === filter) && `${r.name} ${r.vendor} ${r.category}`.toLowerCase().includes(q.toLowerCase())), [data, filter, q]);

  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  return (
    <>
      <PageHeader eyebrow="Registry · Inventario" title="Herramientas de IA detectadas" />
      <div className="flex flex-wrap items-center gap-2 mb-4">
        {FILTERS.map(([k, label]) => (
          <FilterPill key={k} active={k === filter} onClick={() => setFilter(k)} label={label}
            count={k === "todas" ? data.length : data.filter((r) => r.status === k).length} />
        ))}
        <input className="input max-w-xs md:ml-3" placeholder="Buscar herramienta, proveedor o categoría" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="overflow-x-auto rounded-lg border border-cream-line">
        <table className="tbl">
          <thead><tr><th>Herramienta</th><th>Categoría</th><th>Estado</th><th>Riesgo</th><th>Veredicto Labs</th><th className="text-right">Perso&shy;nas</th><th className="text-right">Equipos</th><th>Áreas</th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} className="row" onClick={() => setOpen(r.id)}>
                <td><span className="font-medium">{r.name}</span><span className="block text-xs text-ink-3">{r.vendor}</span></td>
                <td className="text-ink-2 text-xs">{r.category}</td>
                <td><StatusBadge status={r.status} /></td>
                <td><RiskBadge risk={r.risk} /></td>
                <td><VerdictBadge verdict={r.verdict} /></td>
                <td className="text-right tabular-nums">{r.people}</td>
                <td className="text-right tabular-nums">{r.devices}</td>
                <td className="text-xs text-ink-3 max-w-[220px]">{r.areas.join(", ")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Drawer open={open != null} onClose={() => setOpen(null)}
        label={data.find((r) => r.id === open)?.category} title={data.find((r) => r.id === open)?.name} subtitle={data.find((r) => r.id === open)?.vendor}>
        {open != null && <ToolDetail id={open} onChanged={reload} />}
      </Drawer>
    </>
  );
}

function ToolDetail({ id, onChanged }: { id: number; onChanged: () => void }) {
  const { data, error, reload } = useLoad<any>(() => api(`/api/tools/${id}`), [id]);
  const [busy, setBusy] = useState(false);
  if (error) return <ErrorBox error={error} />;
  if (!data) return <Loading />;
  const t = data.tool, o = data.org;

  const setStatus = async (status: string) => {
    setBusy(true);
    try { await api(`/api/tools/${id}/status`, { method: "PATCH", json: { status } }); reload(); onChanged(); }
    finally { setBusy(false); }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3 -mt-1">{o && <StatusBadge status={o.status} />}<RiskBadge risk={t.risk} /></div>

      {data.can_decide && (
        <div>
          <p className="text-sm font-semibold mb-2">Decisión de la empresa</p>
          <DecisionControl value={o?.status} disabled={busy} onChange={setStatus} />
          <p className="text-xs text-ink-3 mt-2">La plataforma no bloquea: la decisión se aplica con las herramientas de TI de la empresa.</p>
        </div>
      )}

      <AiCard note={t.reviewed ? "Ficha de Cognitive Labs · revisada por un analista" : "Ficha de Cognitive Labs · preliminar, sin revisar"}>
        <DataRow k="Veredicto" v={<VerdictBadge verdict={t.verdict} />} />
        <DataRow k="Plan empresarial disponible" v={t.enterprise_plan ? "Sí" : "No o no confirmado"} />
        <DataRow k="¿Entrena con datos del cliente?" v={t.trains_on_data} />
        <DataRow k="Alternativa sugerida" v={t.alternative ?? "—"} />
        {t.notes && <p className="text-sm text-ink-2 pt-2">{t.notes}</p>}
      </AiCard>

      {o && (
        <div className="text-sm">
          <p className="font-semibold">Uso en la empresa</p>
          <p className="text-ink-2 text-xs mt-0.5">{o.people} personas · {o.devices} equipos · desde {fmtDate(o.first_seen)}</p>
          <div className="overflow-x-auto mt-3">
            <table className="tbl">
              <thead><tr>{data.sees_people && <th>Persona</th>}{data.sees_people && <th>Equipo</th>}<th>Área</th><th>Firma detectada</th></tr></thead>
              <tbody>
                {data.usage.map((u: any, i: number) => (
                  <tr key={i}>
                    {data.sees_people && <td>{u.person}</td>}
                    {data.sees_people && <td className="text-xs whitespace-nowrap">{u.hostname}</td>}
                    <td>{u.area}</td>
                    <td className="text-xs text-ink-3">{u.signature}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!data.sees_people && <p className="text-xs text-ink-3 mt-2">Tu rol ve el uso agregado por área, sin nombres.</p>}
        </div>
      )}
    </div>
  );
}
